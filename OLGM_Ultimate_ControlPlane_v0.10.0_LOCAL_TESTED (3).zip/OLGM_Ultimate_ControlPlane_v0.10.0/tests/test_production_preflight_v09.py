"""S10 production negative tests and local recovery drill (no external claims)."""
import json
import os
import sqlite3
from pathlib import Path

import pytest
from olgm.audit import AuditChain
from olgm.canti import CANTI
from olgm.meaning_space import MeaningSpace
from olgm.otfa import OTFA
from olgm.observer import DisabledBackend
from olgm.pipeline import IntegratedRuntime
from olgm.production import cli_allowed, preflight, sqlite_backup_restore_drill
from olgm.api import serve
from runtime import main


def rt(tmp_path):
    ms=MeaningSpace(str(tmp_path/'production_probe.db'))
    return IntegratedRuntime(ms,DisabledBackend(),AuditChain(ms.db_path),CANTI(ms.db_path),OTFA(ms))


def test_production_denies_dev_grants_even_with_token(tmp_path,monkeypatch,capsys):
    monkeypatch.setenv('OLGM_ENV','production')
    monkeypatch.setenv('OLGM_DB',str(tmp_path/'runtime.db'))
    assert main(['grant-dev','reason','agent.ask'])==3
    assert json.loads(capsys.readouterr().out)['status']=='DENIED'
    assert not (tmp_path/'runtime.db').exists(), 'denial should have zero DB effects'


@pytest.mark.parametrize('command',[
    'grant-dev','key-enroll-dev','canonical-init','g06-apply','g06-rollback',
    'selflearn-v2-cycle','thai-learn-approve','thai-code','approve','execute',
])
def test_sensitive_commands_deny_in_production(command):
    assert not cli_allowed(command,{'OLGM_ENV':'production'})
    assert cli_allowed(command,{'OLGM_ENV':'development'})


def test_prod_api_denies_weak_or_missing_tokens(tmp_path,monkeypatch):
    runtime=rt(tmp_path)
    monkeypatch.setenv('OLGM_ENV','production')
    with pytest.raises(PermissionError):
        serve(runtime.agent,host='127.0.0.1',port=0,integrated=runtime,admin_token=None)
    with pytest.raises(PermissionError):
        serve(runtime.agent,host='127.0.0.1',port=0,integrated=runtime,admin_token='a'*64)
    with pytest.raises(ValueError):
        serve(runtime.agent,host='0.0.0.0',port=0,integrated=runtime,admin_token='secure-token-with-sufficient-length-and-variety')


def test_backup_restore_drill_no_db_write(tmp_path):
    runtime=rt(tmp_path)
    db=Path(runtime.ms.db_path)
    before=db.read_bytes()
    report=sqlite_backup_restore_drill(db)
    assert report['status']=='PASS',report
    assert report['integrity']=='ok'
    assert report['snapshot_sha256']==report['restored_sha256']
    assert db.read_bytes()==before


def test_empty_or_unverifiable_db_not_accepted(tmp_path):
    assert sqlite_backup_restore_drill(tmp_path/'missing.db')['status']=='BLOCKED'
    bad=tmp_path/'broken.db';bad.write_bytes(b'not sqlite data')
    assert sqlite_backup_restore_drill(bad)['status']=='FAIL'


def test_preflight_fails_without_external_proofs(tmp_path):
    runtime=rt(tmp_path)
    env={'OLGM_ENV':'production','OLGM_HTTP_TOKEN':'TrueRandomisedProdSecret123!different-ABCD'}
    status=preflight(runtime,environ=env)
    assert status['production_approved'] is False
    assert status['status']=='BLOCKED'
    assert status['checks']['backup_restore_drill']['status']=='PASS'
    assert status['checks']['external_identity_verified']['status']=='NOT_TESTED'
    assert 'external_identity_verified' in status['blocking_checks']
    assert status['gate_s10']=='NOT_PASSED'


def test_preflight_marks_active_dev_grants_blocked(tmp_path):
    runtime=rt(tmp_path)
    runtime.canti.grant('reason','agent.ask','local_cli_operator',ttl=3600)
    status=preflight(runtime,environ={'OLGM_ENV':'production','OLGM_HTTP_TOKEN':'SecureUniqueKey_1234567890abcdefghijklmnop'})
    assert status['checks']['no_active_dev_grants']['status']=='BLOCKED'


def test_preflight_detects_database_corruption(tmp_path):
    runtime=rt(tmp_path)
    path=Path(runtime.ms.db_path)
    # Close idle connections (runtime helpers open context-scoped DBs) before tamper.
    with sqlite3.connect(str(path)) as db:
        db.execute('CREATE TABLE IF NOT EXISTS ordinary(x INTEGER)')
    # Minimal direct corruption: SQLite header is no longer valid.
    with path.open('r+b') as f:
        f.seek(0);f.write(b'BROKEN!!')
    outcome=preflight(runtime,environ={'OLGM_ENV':'production'})
    assert outcome['status']=='BLOCKED'
    assert outcome['checks']['database_integrity']['status']=='FAIL'


def test_prod_api_rejects_model_egress_and_mutation(tmp_path,monkeypatch):
    """Production endpoint restrictions tested with an ephemeral loopback socket."""
    import threading
    from http.server import ThreadingHTTPServer
    from unittest.mock import patch
    import requests

    runtime=rt(tmp_path)
    monkeypatch.setenv('OLGM_ENV','production')
    token='LongIndependentSecret_WithDifferentChars_1234567890'

    class StopWhenCreated(ThreadingHTTPServer):
        def serve_forever(self,poll_interval=0.5):
            self.timeout=0.15
            self.handle_request()

    # Serve one request per invocation to keep the test bounded and avoid leaks.
    with patch('olgm.api.ThreadingHTTPServer',StopWhenCreated):
        def one_request(path, body):
            # A socket bound to port 0 is dynamically assigned, so capture it.
            class CapturingServer(StopWhenCreated):
                def __init__(self,addr,handler):
                    super().__init__(addr,handler)
                    nonlocal_port.append(self.server_address[1])

            nonlocal_port=[]
            with patch('olgm.api.ThreadingHTTPServer',CapturingServer):
                thread=threading.Thread(target=serve,kwargs={'agent':runtime.agent,
                    'host':'127.0.0.1','port':0,'integrated':runtime,'admin_token':token},daemon=True)
                thread.start()
                import time
                until=time.monotonic()+3
                while not nonlocal_port and time.monotonic()<until:time.sleep(.01)
                assert nonlocal_port
                r=requests.post(f'http://127.0.0.1:{nonlocal_port[0]}{path}',
                                headers={'X-OLGM-Token':token},json=body,timeout=3)
                thread.join(timeout=3)
                assert not thread.is_alive()
                return r

        assert one_request('/api/process',{'q':'สวัสดี','enable_model':True}).status_code==403
        assert one_request('/api/observe',{'text':'hello'}).status_code==403
        assert one_request('/api/experience',{'trace_id':'x'}).status_code==403


def test_s10_gate_fails_closed_on_corrupted_db(tmp_path):
    from olgm.s10 import evaluate
    runtime=rt(tmp_path)
    db=Path(runtime.ms.db_path)
    with db.open('r+b') as f:
        f.seek(0);f.write(b'BROKEN!!')
    report=evaluate(runtime)
    assert report['overall']=='FAIL'
    assert report['counts']['failed']==report['counts']['required']==20
    assert report['release_authorized'] is False
