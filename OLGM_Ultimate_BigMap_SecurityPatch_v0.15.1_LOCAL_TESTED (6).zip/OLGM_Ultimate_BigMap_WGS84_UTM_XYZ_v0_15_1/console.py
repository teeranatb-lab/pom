"""OLGM Local UI console. Loopback only. Token login is not Origin authority.

Never bind this console to LAN/WAN without an independently audited identity/TLS gateway.
"""
from __future__ import annotations
import argparse, hashlib, hmac, json, mimetypes, os, re, secrets, sys, time, uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from runtime import build_runtime
from olgm.production import is_production
from olgm.ui.service import ConsoleService, MODULE_BY_KEY, GROUPS
from olgm.geopoints import GeoPointStore, point_info
from olgm.bigmap import BigMapMeaning

ROOT=Path(__file__).resolve().parent
STATIC=ROOT/'web'


def create_handler(service, token, port, admin_token=None):
    sessions={}
    geostore=GeoPointStore(service.db_path,audit=service.rt.audit)
    bigmap=BigMapMeaning(service.db_path,meaning_space=service.rt.ms,audit=service.rt.audit)
    origin=f'http://127.0.0.1:{port}'
    class UIHandler(BaseHTTPRequestHandler):
        server_version='OLGMConsole/0.15.1'
        def log_message(self, fmt, *args):
            # Do not log cookies, tokens or body data.
            sys.stderr.write('[OLGM UI] '+fmt % args+'\n')
        def headers_base(self):
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Referrer-Policy','no-referrer')
            self.send_header('X-Frame-Options','DENY')
            self.send_header('Cache-Control','no-store')
            self.send_header('Content-Security-Policy',"default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; font-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")
        def response(self,status,payload,extra=None):
            # Record unauthenticated denials, CSRF failures and API validation
            # errors that never reach the application's Agent or CANTI layer.
            guarded={'DENIED','NOT_IMPLEMENTED','INSUFFICIENT','REJECTED',
                     'ERROR','BAD_INPUT','BAD_REQUEST','LOGIN_REQUIRED','INTERNAL_ERROR'}
            state=payload.get('status','UNKNOWN') if isinstance(payload,dict) else 'UNKNOWN'
            if status >= 400 or state in guarded:
                reason=payload.get('reason','UNSPECIFIED') if isinstance(payload,dict) else 'UNSPECIFIED'
                if not isinstance(reason,str) or not re.fullmatch(r'[A-Za-z0-9_.:-]{1,80}',reason):
                    reason='REDACTED'
                try:
                    service.rt.audit.append(str(uuid.uuid4()),'HTTP_UI_OUTCOME',{
                        'method':self.command,
                        'route_sha256':hashlib.sha256(urlparse(self.path).path.encode()).hexdigest(),
                        'http_status':status,'result_status':state,'reason_code':reason})
                except Exception:
                    status,payload,extra=503,{'status':'SERVICE_UNAVAILABLE','reason':'AUDIT_UNAVAILABLE'},None
            b=json.dumps(payload,ensure_ascii=False,allow_nan=False,default=str).encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type','application/json; charset=utf-8')
            self.send_header('Content-Length',str(len(b)))
            self.headers_base()
            for k,v in (extra or {}).items():self.send_header(k,v)
            self.end_headers();self.wfile.write(b)
        def session(self):
            raw=self.headers.get('Cookie','')
            if len(raw)>4096:return None
            try:
                cookie=SimpleCookie();cookie.load(raw)
                sid=cookie.get('olgm_session').value if cookie.get('olgm_session') else ''
            except Exception:return None
            obj=sessions.get(sid)
            if not obj:return None
            if time.time()>obj['expires']:
                sessions.pop(sid,None);return None
            return obj
        def read_json(self):
            try:n=int(self.headers.get('Content-Length','0'))
            except ValueError:raise ValueError('invalid_content_length')
            if n<1 or n>65536:raise ValueError('body_length_must_be_1_to_65536')
            if not self.headers.get('Content-Type','').startswith('application/json'):
                raise ValueError('application_json_required')
            data=json.loads(self.rfile.read(n).decode('utf-8'))
            if not isinstance(data,dict):raise ValueError('object_required')
            return data
        def safe_reason(self,exception):
            # Never expose arbitrary exception strings, paths or provider secrets.
            if isinstance(exception,PermissionError):return 'ACCESS_DENIED'
            if isinstance(exception,KeyError):return 'RESOURCE_NOT_FOUND'
            if isinstance(exception,TypeError):return 'INVALID_INPUT_TYPE'
            return 'INVALID_REQUEST'
        def do_GET(self):
            path=urlparse(self.path).path
            if path in ('/','/index.html','/styles.css','/app.js'):
                name={'/':'index.html','/index.html':'index.html','/styles.css':'styles.css','/app.js':'app.js'}[path]
                b=(STATIC/name).read_bytes()
                self.send_response(200)
                self.send_header('Content-Type',mimetypes.guess_type(name)[0] or 'application/octet-stream')
                self.send_header('Content-Length',str(len(b)))
                self.headers_base();self.end_headers();self.wfile.write(b);return
            if path=='/health':return self.response(200,{'status':'ALIVE','scope':'local_loopback','authenticated':False,'production_certified':False})
            if not path.startswith('/api/ui/'):
                return self.response(404,{'status':'NOT_FOUND'})
            auth=self.session()
            if not auth:return self.response(401,{'status':'LOGIN_REQUIRED'})
            try:
                if path=='/api/ui/bootstrap':
                    data={'modules':list(MODULE_BY_KEY.values()),'groups':GROUPS,
                          'role':auth['role'],'user_id':auth['user_id'],
                          'origin_authority':False,'production_certified':False,
                          'build':'0.15.1-local','mode':'LOCAL_ONLY'}
                elif path=='/api/ui/overview':data=service.overview()
                elif path.startswith('/api/ui/module/'):
                    key=path.split('/')[-1]
                    data=service.module(key)
                elif path=='/api/ui/settings':
                    q=parse_qs(urlparse(self.path).query)
                    scope=q.get('scope',['user'])[0];scope_id=q.get('scope_id',[None])[0]
                    data=service.settings.view(auth['role'],auth['user_id'],scope,scope_id)
                elif path=='/api/ui/session':data={'role':auth['role'],'expires_at':auth['expires']}
                elif path=='/api/ui/gis-points':data=geostore.list()
                elif path=='/api/ui/bigmap/features':
                    features=bigmap.list_features(limit=1000)
                    features['features']=[f for f in features['features'] if f['classification'] in ('PUBLIC','INTERNAL')]
                    data=features
                elif path=='/api/ui/bigmap/links':
                    cid=parse_qs(urlparse(self.path).query).get('cid',[''])[0]
                    data=bigmap.features_for_cid(cid)
                    data['features']=[f for f in data['features'] if f['classification'] in ('PUBLIC','INTERNAL')]
                elif path=='/api/ui/bigmap/history':
                    fid=parse_qs(urlparse(self.path).query).get('feature_id',[''])[0]
                    feature=bigmap.get_feature(fid)
                    if not feature or feature['classification'] not in ('PUBLIC','INTERNAL'):raise PermissionError('feature_not_available')
                    data=bigmap.history(fid)
                elif path=='/api/ui/bigmap/nearby':
                    q=parse_qs(urlparse(self.path).query)
                    data=bigmap.nearby(float(q.get('lat',[''])[0]),float(q.get('lon',[''])[0]),float(q.get('radius_m',['500'])[0]))
                    allowed={f['feature_id'] for f in bigmap.list_features(limit=2000)['features'] if f['classification'] in ('PUBLIC','INTERNAL')}
                    data['matches']=[v for v in data['matches'] if v['feature_id'] in allowed]

                elif path=='/api/ui/gpt-skill-search':
                    query=parse_qs(urlparse(self.path).query).get('q',[''])[0]
                    data=service.gpt_skills.catalog(query=query,limit=100)
                elif path=='/api/ui/gpt-skill-match':
                    query=parse_qs(urlparse(self.path).query).get('q',[''])[0]
                    data=service.skill_match(query)
                else:return self.response(404,{'status':'NOT_FOUND'})
                return self.response(200,data)
            except (ValueError,TypeError,KeyError,PermissionError) as e:
                return self.response(403 if isinstance(e,PermissionError) else 400,
                                     {'status':'ERROR','reason':self.safe_reason(e)})
            except Exception as e:
                self.log_message('GET internal error %s',type(e).__name__)
                return self.response(500,{'status':'INTERNAL_ERROR','detail':'see_local_server_log'})
        def do_POST(self):
            path=urlparse(self.path).path
            if not path.startswith('/api/ui/'):return self.response(404,{'status':'NOT_FOUND'})
            if self.headers.get('Origin') not in (None,origin):
                return self.response(403,{'status':'DENIED','reason':'cross_origin_request'})
            if self.headers.get('X-OLGM-UI')!='local-console':
                return self.response(403,{'status':'DENIED','reason':'csrf_header_required'})
            try:body=self.read_json()
            except (ValueError,UnicodeError,json.JSONDecodeError):return self.response(400,{'status':'BAD_INPUT','reason':'INVALID_JSON_OR_FIELDS'})
            if path=='/api/ui/login':
                user_token=body.get('token','')
                if not isinstance(user_token,str):return self.response(401,{'status':'DENIED'})
                role=None
                if admin_token and hmac.compare_digest(user_token,admin_token):role='admin'
                elif hmac.compare_digest(user_token,token):role='operator'
                if role is None:return self.response(401,{'status':'DENIED'})
                sid=secrets.token_urlsafe(40)
                sessions[sid]={'role':role,'user_id':'local_console','expires':time.time()+3600}
                return self.response(200,{'status':'AUTHENTICATED','role':role,'origin_authority':False},
                         {'Set-Cookie':f'olgm_session={sid}; HttpOnly; Path=/; SameSite=Strict; Max-Age=3600'})
            auth=self.session()
            if not auth:return self.response(401,{'status':'LOGIN_REQUIRED'})
            if path=='/api/ui/logout':
                raw=self.headers.get('Cookie','')
                try:
                    cookie=SimpleCookie();cookie.load(raw)
                    item=cookie.get('olgm_session');sessions.pop(item.value if item else '',None)
                except Exception:pass
                return self.response(200,{'status':'LOGGED_OUT'},
                            {'Set-Cookie':'olgm_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'})
            try:
                if path=='/api/ui/thai-answer':
                    data=service.thai_answer(body.get('question',''))
                elif path=='/api/ui/code':
                    data=service.code(request=body.get('request',''),pattern=body.get('pattern',''),
                         key=body.get('key'),size=body.get('size',2),page=body.get('page',1),value=body.get('value'))
                elif path=='/api/ui/gis-latlon':
                    data=point_info(body.get('lat'),body.get('lon'))
                elif path=='/api/ui/gis-add-point':
                    data=geostore.add(body.get('label',''),body.get('lat'),body.get('lon'),auth['user_id'])
                elif path=='/api/ui/bigmap/add':
                    data=bigmap.add_feature(body.get('label',''),body.get('geometry'),
                         body.get('origin_ref','local-origin-declaration'),auth['user_id'],
                         source_ref=body.get('source_ref','local_console'),classification='INTERNAL',
                         vertical_crs=body.get('vertical_crs') or None)
                elif path=='/api/ui/bigmap/revise':
                    feature=bigmap.get_feature(body.get('feature_id',''))
                    if not feature or feature['classification'] not in ('PUBLIC','INTERNAL'):raise PermissionError('feature_not_available')
                    data=bigmap.revise_geometry(body.get('feature_id'),body.get('geometry'),
                         body.get('expected_revision'),body.get('reason',''),auth['user_id'],
                         vertical_crs=body.get('vertical_crs') or None)
                elif path=='/api/ui/bigmap/link':
                    feature=bigmap.get_feature(body.get('feature_id',''))
                    if not feature or feature['classification'] not in ('PUBLIC','INTERNAL'):raise PermissionError('feature_not_available')
                    data=bigmap.link_to_meaning(body.get('feature_id'),body.get('cid'),
                         body.get('relation_type','represents'),body.get('origin_ref','local-origin-declaration'),
                         auth['user_id'],evidence_ref=body.get('evidence_ref') or None)

                elif path=='/api/ui/gis-point':
                    from olgm.gis import BigMapGIS
                    lat,lon=body.get('lat'),body.get('lon')
                    if type(lat) not in (float,int) or type(lon) not in (float,int):raise ValueError('numeric_lat_lon_required')
                    from olgm.utm_wgs84 import to_utm
                    data=to_utm(lat,lon,body.get('z'),body.get('vertical_crs') or None)
                elif path=='/api/ui/gis-utm-inverse':
                    from olgm.utm_wgs84 import from_utm
                    data=from_utm(body.get('X'),body.get('Y'),body.get('utm_zone'),body.get('hemisphere','N'),
                                  body.get('Z'),body.get('vertical_crs') or None)
                elif path=='/api/ui/intent':
                    data=service.create_intent(body.get('statement',''),auth['user_id'],body.get('task_type','CHAT'))
                elif path=='/api/ui/settings/change':
                    data=service.settings.change(body.get('scope','user'),body.get('scope_id',auth['user_id']),
                       body.get('key'),body.get('value'),auth['user_id'],auth['role'],auth['user_id'],
                       body.get('reason',''),body.get('expected_revision',0))
                elif path=='/api/ui/settings/reset':
                    data=service.settings.reset(body.get('scope','user'),body.get('scope_id',auth['user_id']),
                       body.get('key'),auth['user_id'],auth['role'],auth['user_id'],
                       body.get('reason',''),body.get('expected_revision',0))
                elif path=='/api/ui/settings/rollback':
                    data=service.settings.rollback(body.get('seq'),auth['user_id'],auth['role'],auth['user_id'],
                       body.get('reason',''),body.get('expected_revision',0))
                elif path=='/api/ui/gpt-skill-propose':
                    data=service.skill_lesson_candidate(body,auth['user_id'])
                elif path=='/api/ui/resource':
                    if auth['role']!='admin':raise PermissionError('admin_console_token_required')
                    data=service.register_resource(body)
                elif path=='/api/ui/control-propose':
                    data=service.propose_control(body,auth['user_id'])
                else:return self.response(404,{'status':'NOT_FOUND'})
                return self.response(200,data)
            except (ValueError,TypeError,KeyError,PermissionError) as e:
                return self.response(403 if isinstance(e,PermissionError) else 400,
                                  {'status':'ERROR','reason':self.safe_reason(e)})
            except Exception as e:
                self.log_message('POST internal error %s',type(e).__name__)
                return self.response(500,{'status':'INTERNAL_ERROR','detail':'see_local_server_log'})
    return UIHandler


def serve_local(host='127.0.0.1',port=8787,token=None,admin_token=None):
    if host!='127.0.0.1':raise ValueError('UI binds to 127.0.0.1 only; LAN needs separate audited gateway')
    if is_production():raise PermissionError('Development console cannot serve production; deploy independently authenticated gateway after S-10 acceptance')
    token=token or secrets.token_urlsafe(32)
    admin_token=admin_token or secrets.token_urlsafe(32)
    if len(token)<32:raise ValueError('UI token must be at least 32 characters')
    if admin_token and (len(admin_token)<32 or hmac.compare_digest(admin_token,token)):
        raise ValueError('admin token must be distinct and at least 32 characters')
    runtime=build_runtime()
    service=ConsoleService(runtime.ms.db_path,runtime)
    http=ThreadingHTTPServer((host,port),create_handler(service,token,port,admin_token))
    http.daemon_threads=True
    print('\nOLGM Ultimate — LOCAL WEB CONSOLE',flush=True)
    print(f'URL: http://{host}:{port}/',flush=True)
    print('OPERATOR LOGIN TOKEN:',token,flush=True)
    print('ADMIN CONSOLE TOKEN:',admin_token,flush=True)
    print('Origin authority: NOT GRANTED; S-10: NOT PASSED',flush=True)
    print('Stop only this console: Ctrl+C',flush=True)
    try:http.serve_forever()
    finally:http.server_close()


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--port',type=int,default=8787)
    args=p.parse_args()
    serve_local(port=args.port,token=os.getenv('OLGM_UI_TOKEN'),admin_token=os.getenv('OLGM_UI_ADMIN_TOKEN'))
