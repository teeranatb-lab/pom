'use strict';
const $=(s)=>document.querySelector(s);
const esc=(s)=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const state={bootstrap:null,route:'overview',settings:null,settingCategory:'appearance',settingsScope:'user',settingsRole:'admin',role:'operator',lastAnswer:null,geoPoints:[],bigmapFeatures:[]};
const icons={overview:'◫',thai:'◎',intent:'⌖',meaning:'⬡',observer:'◉',otfa:'◇',origin:'♜',code:'⌘',selflearn:'✧',benchmarks:'▥',gis:'⌁',multimodal:'▣',control:'▤',computers:'▣',plugins:'♧',spaces:'▦',skills:'✦',queue:'☷',canti:'⌑',valueguard:'✧',s10:'✓',audit:'≋',models:'◈',backup:'↩',settings:'⚙'};
async function api(path,method='GET',payload){
 const req={method,credentials:'same-origin',headers:{'X-OLGM-UI':'local-console'}};
 if(method!=='GET'){req.headers['Content-Type']='application/json';req.body=JSON.stringify(payload??{});}
 const r=await fetch('/api/ui/'+path,req);const out=await r.json();
 if(!r.ok){if(r.status===401)$('#login-screen').classList.remove('hidden');throw Error(out.reason||out.status||'HTTP '+r.status);}
 return out;
}
function toast(msg,error=false){const n=document.createElement('div');n.className='toast'+(error?' error':'');n.textContent=msg;$('#toast-zone').append(n);setTimeout(()=>n.remove(),4900)}
function statePill(s){s=String(s||'UNKNOWN');let cls='warn';if(['PASS','LOCAL_AVAILABLE','PROTECTED_READ_ONLY','CONNECTED','VERIFIED','APPLIED'].includes(s))cls='good';if(['NOT_CONNECTED','NOT_PASSED','FAIL','DENIED','ERROR','OFFLINE'].includes(s))cls='bad';if(['DISABLED','NOT_TESTED','PARTIAL_NOT_LIVE_VERIFIED','CONFIGURED_NOT_TESTED'].includes(s))cls='warn';return `<span class="pill ${cls}">${esc(s.replaceAll('_',' '))}</span>`}
function heading(eyebrow,title,sub,actions=''){return `<div class="page-heading"><div><div class="eyebrow">${esc(eyebrow)}</div><h1>${esc(title)}</h1><p>${esc(sub)}</p></div><div class="heading-actions">${actions}</div></div>`}
function card(title,sub,body){return `<section class="card"><h2>${esc(title)}</h2><p class="card-sub">${esc(sub||'')}</p>${body||''}</section>`}
function moduleButton(m){return `<button class="module-card" data-route="${esc(m.key)}"><span class="module-mark">${esc(icons[m.key]||'◈')}</span><span class="module-info"><strong>${esc(m.title)}</strong><small>${esc(m.subtitle)}</small></span><span class="module-go">›</span></button>`}
function renderNav(){const b=state.bootstrap;if(!b)return;let html='';for(const [group,title] of Object.entries(b.groups)){const items=b.modules.filter(m=>m.group===group);html+=`<div class="nav-group-label">${esc(title)}</div>`;for(const m of items)html+=`<button class="nav-item${state.route===m.key?' active':''}" data-route="${esc(m.key)}"><span class="nav-icon">${esc(icons[m.key]||'◈')}</span><span>${esc(m.title)}</span></button>`;}$('#navigation').innerHTML=html}
function goto(route){if(!state.bootstrap?.modules.some(m=>m.key===route))route='overview';state.route=route;history.replaceState(null,'','#'+route);renderNav();$('#sidebar').classList.remove('open');$('#screen-overlay').classList.remove('open');const title=state.bootstrap.modules.find(m=>m.key===route)?.title||route;$('#breadcrumb').textContent=title;$('#page').innerHTML='<div class="empty-state">กำลังอ่านสถานะของระบบ...</div>';renderRoute(route).catch(e=>{$('#page').innerHTML=`<div class="error-view">ไม่สามารถอ่านข้อมูลโมดูลได้<br>${esc(e.message)}</div>`;toast(e.message,true)})}
function num(n){return n===null||n===undefined?'—':Number(n).toLocaleString('th-TH')}
function table(rows,limit=45){if(!rows||!rows.length)return `<div class="empty-state"><div style="font-size:28px">◌</div><b>ยังไม่มีรายการ</b><span>ระบบยังไม่มีข้อมูลที่บันทึกไว้ในเครื่องนี้ หรือรายการอยู่ใน Connector ที่ยังไม่เชื่อมต่อ</span></div>`;const cols=Object.keys(rows[0]).slice(0,8);return `<div class="data-table-wrap"><table class="data-table"><thead><tr>${cols.map(c=>`<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${rows.slice(0,limit).map(r=>`<tr>${cols.map(c=>`<td>${typeof r[c]==='object'?esc(JSON.stringify(r[c])):esc(r[c])}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`}
function errBanner(text){return `<div class="detail-banner"><strong>หมายเหตุด้านสิทธิ์และการรับรอง:</strong> ${esc(text)}</div>`}
async function renderRoute(route){if(route==='overview')return renderOverview();if(route==='settings')return renderSettings();return renderModule(route)}
async function renderOverview(){const [d]=await Promise.all([api('overview')]);const counts=d.counts;const show=['thai','meaning','code','control','skills','s10'];const con=['computers','plugins','spaces','models'];const modules=state.bootstrap.modules;$('#page').innerHTML=heading('SYSTEM OVERVIEW','สวัสดีจาก OLGM Ultimate','โครงสร้างอธิปไตยทางปัญญา · ทำงานบนเครื่อง Local · สถานะตามหลักฐานจริง',`<button class="secondary-btn" data-action="refresh">↻ รีเฟรช</button>`)+`
 <div class="hero"><div class="hero-copy"><span class="pill">◈ ORIGIN-LED GOVERNANCE</span><h2>หนึ่งศูนย์ควบคุม<br>ทุกมิติของความหมาย</h2><p>จากเจตนาและความสัมพันธ์ ไปสู่การพิสูจน์ การเรียนรู้ การสร้างโค้ด และการปฏิบัติงาน — โดยไม่ข้ามสิทธิ์หรือสร้างผลยืนยันที่ไม่มีหลักฐาน</p><div class="hero-actions"><button class="primary-btn" data-route="thai">เริ่มใช้งานผู้ช่วยไทย　→</button><button class="secondary-btn" data-route="control">ตรวจ Control Plane</button></div></div></div>
 <div class="metric-grid"><div class="card metric"><div class="metric-top">Meaning Cores <span class="metric-icon">⬡</span></div><div class="metric-number">${num(counts.cores)}</div><div class="metric-bottom">แก่นความหมายที่บันทึก</div></div><div class="card metric"><div class="metric-top">Semantic Edges <span class="metric-icon">⌁</span></div><div class="metric-number">${num(counts.relations)}</div><div class="metric-bottom">เส้นความสัมพันธ์</div></div><div class="card metric"><div class="metric-top">Audit Events <span class="metric-icon">≋</span></div><div class="metric-number">${num(counts.audit_events)}</div><div class="metric-bottom">เหตุการณ์ตรวจสอบย้อนหลัง</div></div><div class="card metric"><div class="metric-top">Control Plans <span class="metric-icon">☷</span></div><div class="metric-number">${num(counts.control_plans)}</div><div class="metric-bottom">คำสั่งที่จัดการในเครื่อง</div></div></div>
 <div class="grid-two">${card('พื้นที่ทำงานหลัก','เลือกเข้าสู่โมดูลที่มีตัวดำเนินการใน Local',`<div class="module-grid" style="margin-top:18px">${modules.filter(m=>show.includes(m.key)).map(moduleButton).join('')}</div>`)}${card('ความพร้อมและความถูกต้อง','แสดงข้อมูลจาก Runtime โดยตรง',`<div class="connection-list"><div class="connection-row"><div><strong>Audit Integrity</strong><small>${esc(d.audit.detail)}</small></div>${statePill(d.audit.status)}</div><div class="connection-row"><div><strong>Canonical</strong><small>ต้องคงสภาพ Append + Inherit + Delta</small></div>${statePill(d.canonical.status)}</div><div class="connection-row"><div><strong>UI Settings Ledger</strong><small>Append-only และตรวจ Hash Chain</small></div>${statePill(d.ui_settings.status)}</div><div class="connection-row"><div><strong>S-10 Release Gate</strong><small>ห้ามรับรองเองโดยไม่มีหลักฐาน</small></div>${statePill(d.s10)}</div><div class="connection-row"><div><strong>Model Gateway</strong><small>ไม่เปิดโดยอัตโนมัติ</small></div>${statePill(d.model_provider)}</div></div>`)}</div>
 <div class="section-title"><h2>การเชื่อมต่อภายนอก</h2><span class="subtle" style="font-size:11px">การลงทะเบียน ≠ การเชื่อมต่อสด</span></div><div class="module-grid">${modules.filter(m=>con.includes(m.key)).map(moduleButton).join('')}</div>`;
}
function graphSvg(graph){const cores=graph.cores||[],edges=graph.edges||[];if(!cores.length)return '<div class="empty-state"><b>Meaning Space ยังไม่มีแก่นความหมาย</b><span>เพิ่มข้อมูลผ่าน Runtime ที่ผ่านสิทธิ์และหลักฐานก่อน</span></div>';
 const n=Math.min(cores.length,30),pts={};cores.slice(0,n).forEach((c,i)=>{const theta=2*Math.PI*i/n;const radius=25+Math.sqrt(i/n)*135;pts[c.cid]={x:240+Math.cos(theta)*radius,y:198+Math.sin(theta)*radius,name:c.surface_form||c.cid}});
 const svgEdges=edges.filter(e=>pts[e.source_cid]&&pts[e.target_cid]).map(e=>`<g><line x1="${pts[e.source_cid].x}" y1="${pts[e.source_cid].y}" x2="${pts[e.target_cid].x}" y2="${pts[e.target_cid].y}"><title>${esc(e.relation_type)}</title></line></g>`).join('');
 return `<div class="graph-canvas"><svg viewBox="0 0 480 400" role="img" aria-label="แผนภาพ Meaning Space ของแก่นความหมายล่าสุด">${svgEdges}${Object.entries(pts).map(([cid,p])=>`<g><circle cx="${p.x}" cy="${p.y}" r="${Math.max(8,13-Math.floor(n/10))}"><title>${esc(cid)} — ${esc(p.name)}</title></circle><text x="${p.x+14}" y="${p.y+5}">${esc(String(p.name).slice(0,15))}</text></g>`).join('')}</svg></div>`}
// Geographical map view. X is eastward longitude and Y is northward latitude.
// No external tile/API requests; this is a local coordinate plot, not a basemap.
function geoMapSvg(points){
 const W=840,H=420,p=60;
 if(!points.length)return `<div class="geo-empty"><strong>ยังไม่มีจุดบนแผนที่</strong><span>กรอก Latitude / Longitude แล้วกดบันทึกจุดเพื่อแสดงตำแหน่ง</span></div>`;
 const lats=points.map(a=>a.lat), lons=points.map(a=>a.lon);
 const clat=(Math.min(...lats)+Math.max(...lats))/2,clon=(Math.min(...lons)+Math.max(...lons))/2;
 const cos=Math.max(0.02,Math.cos(clat*Math.PI/180));
 const dx=Math.max(...lons.map(x=>Math.abs(x-clon)))*cos;
 const dy=Math.max(...lats.map(y=>Math.abs(y-clat)));
 const scale=Math.min((W-2*p)/(Math.max(2*dx,0.005)*1.25),(H-2*p)/(Math.max(2*dy,0.005)*1.25));
 const x=lon=>W/2+(lon-clon)*cos*scale, y=lat=>H/2-(lat-clat)*scale;
 let grid='';for(let i=0;i<=4;i++){
  const px=p+(W-2*p)*i/4,py=p+(H-2*p)*i/4;
  const lon=clon+(px-W/2)/(cos*scale),lat=clat+(H/2-py)/scale;
  grid+=`<line x1="${px}" y1="${p}" x2="${px}" y2="${H-p}" class="geo-grid"/><text x="${px}" y="${H-p+24}" text-anchor="middle" class="geo-tick">${lon.toFixed(5)}°</text>`;
  grid+=`<line x1="${p}" y1="${py}" x2="${W-p}" y2="${py}" class="geo-grid"/><text x="${p-10}" y="${py+3}" text-anchor="end" class="geo-tick">${lat.toFixed(5)}°</text>`;
 }
 const pins=points.map((a,i)=>`<g class="geo-point"><circle cx="${x(a.lon)}" cy="${y(a.lat)}" r="8"/><text x="${x(a.lon)+13}" y="${y(a.lat)-12}" class="geo-point-label">${esc(a.label)}</text><title>${esc(a.label)}: ${a.lat.toFixed(6)}, ${a.lon.toFixed(6)}</title></g>`).join('');
 return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="พิกัด Latitude Longitude ของ ${points.length} จุด"><rect width="${W}" height="${H}" rx="14" class="geo-background"/>${grid}${pins}<text x="${W/2}" y="${H-7}" class="geo-axis" text-anchor="middle">Longitude / ตะวันออก →</text><text x="16" y="${H/2}" class="geo-axis" transform="rotate(-90 16 ${H/2})" text-anchor="middle">Latitude / เหนือ →</text></svg>`;
}
function geoPointTable(points){
 if(!points.length)return `<p class="fine-print">ไม่มีจุดที่บันทึก</p>`;
 return `<div class="data-table-wrap"><table class="data-table"><thead><tr><th>ชื่อจุด</th><th>Latitude</th><th>Longitude</th><th>UTM EPSG</th><th>X (m)</th><th>Y (m)</th><th>Z (m)</th></tr></thead><tbody>${points.map(p=>`<tr><td>${esc(p.label)}</td><td class="mono">${p.lat.toFixed(6)}</td><td class="mono">${p.lon.toFixed(6)}</td><td>${esc(p.utm?.horizontal_crs||'N/A')}</td><td>${p.utm?.X===undefined?'—':Number(p.utm.X).toFixed(3)}</td><td>${p.utm?.Y===undefined?'—':Number(p.utm.Y).toFixed(3)}</td><td>ไม่ทราบ</td></tr>`).join('')}</tbody></table></div>`;
}
function saveGeoFile(filename,content,mime){
 const blob=new Blob([content],{type:mime});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1200);
}
function allMapFeatures(){
 const old=state.geoPoints.map(p=>({feature_id:p.point_id,label:p.label,revision:1,
   geometry:{type:'Point',coordinates:[p.lon,p.lat]},utm:p.utm?.status==='NOT_AVAILABLE'?{status:'NOT_AVAILABLE'}:{type:'Point',coordinates:[p.utm?.X,p.utm?.Y],horizontal_crs:p.utm?.horizontal_crs,utm_zone_per_vertex:[p.utm?.utm_zone],hemisphere_per_vertex:[p.utm?.hemisphere],vertical_crs:null},semantic_links:[],source_ref:'legacy_geopoints'}));
 return [...state.bigmapFeatures,...old];
}
function exportGeoCSV(){
 const pts=allMapFeatures().filter(f=>f.geometry.type==='Point');
 const rows=['lat,lon',...pts.map(p=>`${p.geometry.coordinates[1].toFixed(8)},${p.geometry.coordinates[0].toFixed(8)}`)];
 saveGeoFile('bigmap_wgs84_lat_lon.csv','\ufeff'+rows.join('\r\n')+'\r\n','text/csv;charset=utf-8');
}
function exportDualCSV(){
 const pts=allMapFeatures().filter(f=>f.geometry.type==='Point'&&f.utm?.status!=='NOT_AVAILABLE');
 const headers=['feature_id','label','lat','lon','X','Y','Z','utm_zone','hemisphere','horizontal_crs','vertical_crs','revision'];
 const csvValue=v=>'"'+String(v===null||v===undefined?'':v).replaceAll('"','""')+'"';
 const rows=[headers.join(',')];
 for(const f of pts){
  const p=f.geometry.coordinates,u=f.utm||{},xy=u.coordinates||[],zone=u.utm_zone_per_vertex||[],hem=u.hemisphere_per_vertex||[];
  const vals=[f.feature_id,f.label,p[1].toFixed(8),p[0].toFixed(8),xy[0],xy[1],xy.length===3?xy[2]:'',zone[0],hem[0],u.horizontal_crs,u.vertical_crs,f.revision];
  rows.push(vals.map(csvValue).join(','));
 }
 saveGeoFile('bigmap_wgs84_latlon_utm_xyz.csv','\ufeff'+rows.join('\r\n')+'\r\n','text/csv;charset=utf-8');
}
function exportGeoJSON(){
 const features=allMapFeatures().map(p=>({type:'Feature',id:p.feature_id,properties:{label:p.label,feature_id:p.feature_id,revision:p.revision,
   semantic_cids:(p.semantic_links||[]).map(l=>l.cid),source_ref:p.source_ref,survey_accuracy:'NOT_CERTIFIED'},geometry:p.geometry}));
 saveGeoFile('bigmap_wgs84_geojson.geojson',JSON.stringify({type:'FeatureCollection',features},null,2),'application/geo+json');
}
function bigmapMapSvg(items){
 if(!items.length)return '<div class="geo-empty"><strong>ยังไม่มีวัตถุภูมิศาสตร์</strong><span>เพิ่มพิกัดจุดหรือแนวเส้นเพื่อแสดงในพื้นที่ BigMap</span></div>';
 const coordSets=items.map(f=>{const g=f.geometry;return g.type==='Point'?[g.coordinates]:g.type==='Polygon'?g.coordinates[0]:g.coordinates});
 const all=coordSets.flat(), lats=all.map(p=>p[1]), lons=all.map(p=>p[0]);
 const W=900,H=470, pad=55, clat=(Math.min(...lats)+Math.max(...lats))/2,clon=(Math.min(...lons)+Math.max(...lons))/2;
 const correction=Math.max(.02,Math.cos(clat*Math.PI/180));
 const dw=Math.max(.0001,(Math.max(...lons)-Math.min(...lons))*correction), dh=Math.max(.0001,Math.max(...lats)-Math.min(...lats));
 const scale=Math.min((W-2*pad)/(dw*1.18),(H-2*pad)/(dh*1.18));
 const x=lon=>W/2+(lon-clon)*correction*scale,y=lat=>H/2-(lat-clat)*scale;
 let grid='';for(let i=0;i<=5;i++){
   const py=pad+(H-2*pad)*i/5,px=pad+(W-2*pad)*i/5;
   const lat=clat+(H/2-py)/scale,lon=clon+(px-W/2)/(correction*scale);
   grid+=`<line class="geo-grid" x1="${pad}" y1="${py}" x2="${W-pad}" y2="${py}"/><text class="geo-tick" x="${pad-6}" y="${py+4}" text-anchor="end">${lat.toFixed(5)}°</text>`;
   grid+=`<line class="geo-grid" x1="${px}" y1="${pad}" x2="${px}" y2="${H-pad}"/><text class="geo-tick" x="${px}" y="${H-pad+20}" text-anchor="middle">${lon.toFixed(5)}°</text>`;
 }
 const shapes=items.map((f,i)=>{
   const g=f.geometry,pts=coordSets[i];const label=esc(f.label);const tip=`${label}: ${esc(f.feature_id)}`;
   if(g.type==='Point')return `<g class="geo-point"><circle cx="${x(pts[0][0])}" cy="${y(pts[0][1])}" r="7"><title>${tip}</title></circle><text class="geo-point-label" x="${x(pts[0][0])+12}" y="${y(pts[0][1])-8}">${label}</text></g>`;
   const xy=pts.map(p=>`${x(p[0]).toFixed(3)},${y(p[1]).toFixed(3)}`).join(' ');
   if(g.type==='LineString')return `<polyline points="${xy}" class="bigmap-line"><title>${tip}</title></polyline>`;
   return `<polygon points="${xy}" class="bigmap-polygon"><title>${tip}</title></polygon>`;
 }).join('');
 return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="BigMap WGS84 Lat Long มีวัตถุ ${items.length} รายการ"><rect width="${W}" height="${H}" rx="14" class="geo-background"/>${grid}${shapes}<text class="geo-axis" x="${W/2}" y="${H-4}" text-anchor="middle">Longitude → WGS84 EPSG:4326</text></svg>`;
}
function parseLatLonLines(str,kind){
 const rows=str.trim().split(/\r?\n/).filter(x=>x.trim()).map((row,i)=>{
   const seg=row.trim().split(/[\s,;]+/).map(Number);
   if((seg.length!==2 && seg.length!==3) || seg.some(n=>!Number.isFinite(n)) || seg[0]<-90||seg[0]>90||seg[1]<-180||seg[1]>180)throw Error(`พิกัดแถว ${i+1} ไม่ถูกต้อง`);
   return [seg[1],seg[0],...(seg.length===3?[seg[2]]:[])]; // GeoJSON lon,lat[,height]
 });
 if(kind==='Point'&&rows.length!==1)throw Error('จุดต้องมีพิกัดหนึ่งคู่');
 if(kind==='LineString'&&rows.length<2)throw Error('เส้นต้องมีอย่างน้อย 2 จุด');
 if(kind==='Polygon'&&(rows.length<4||JSON.stringify(rows[0])!==JSON.stringify(rows[rows.length-1])))throw Error('Polygon ต้องปิดวง โดยบรรทัดสุดท้ายเท่ากับบรรทัดแรก');
 return {type:kind,coordinates:kind==='Point'?rows[0]:(kind==='Polygon'?[rows]:rows)};
}
function bigmapTable(items){
 if(!items.length)return '<p class="fine-print">ยังไม่มีรายการ BigMap</p>';
 return `<div class="data-table-wrap"><table class="data-table"><thead><tr><th>วัตถุ / Feature ID</th><th>ชนิด</th><th>Revision</th><th>UTM Zone / EPSG</th><th>X Easting (m)</th><th>Y Northing (m)</th><th>Z Height (m)</th><th>ความยาว (ประมาณ)</th><th>เชื่อม CID</th></tr></thead><tbody>${items.slice(0,120).map(f=>`<tr><td><b>${esc(f.label)}</b><small style="display:block;word-break:break-all">${esc(f.feature_id)}</small></td><td>${esc(f.kind||f.geometry.type)}</td><td>${esc(f.revision||1)}</td><td>${esc(f.utm?.horizontal_crs||f.utm?.zone_mode||'N/A')}</td><td class="mono">${f.utm?.type==='Point'?Number(f.utm.coordinates[0]).toFixed(3):'—'}</td><td class="mono">${f.utm?.type==='Point'?Number(f.utm.coordinates[1]).toFixed(3):'—'}</td><td class="mono">${f.utm?.type==='Point'&&f.utm.coordinates.length>2?esc(f.utm.coordinates[2]):'ไม่ทราบ'}</td><td>${Number(f.metrics?.length_m_approx||0).toLocaleString('th-TH')} ม.</td><td>${(f.semantic_links||[]).length?f.semantic_links.map(l=>`<span class="pill purple">${esc(l.cid)} · CANDIDATE</span>`).join(' '):'—'}</td></tr>`).join('')}</tbody></table></div>`;
}
async function renderModule(route){const d=await api('module/'+route);if(route==='gis'){const [loc,big]=await Promise.all([api('gis-points'),api('bigmap/features')]);state.geoPoints=loc.points||[];state.bigmapFeatures=big.features||[];}const m=d.module;let main='';const actions=`<button class="secondary-btn" data-action="refresh">↻ รีเฟรช</button>`;
 if(route==='thai')main=card('ผู้ช่วยภาษาไทย','ตอบจากข้อมูลที่ผ่านกฎการใช้งานใน Meaning Space',`<form id="thai-form"><div class="form-block"><label for="thai-question">พิมพ์คำถามภาษาไทย</label><textarea id="thai-question" class="field" placeholder="เช่น หนึ่งบวกสอง หรือ อธิบายความสัมพันธ์ในระบบ..."></textarea></div><button class="primary-btn">◈ สร้างคำตอบ</button></form><div class="divider"></div><h2>คำตอบ</h2><p class="card-sub">ระบบจะแสดงสถานะและที่มาจากตัวดำเนินการจริง ไม่รับรองสิ่งที่ยังไม่ผ่านหลักฐาน</p><pre id="thai-output" class="output">รอคำถาม...</pre>`);
 else if(route==='code')main=card('สร้างโค้ด Python','ใช้รูปแบบที่มีการตรวจชนิดข้อมูล ไม่อนุญาตเขียนไฟล์ Production อัตโนมัติ',`<form id="code-form"><div class="form-block"><label for="code-question">สิ่งที่ต้องการสร้าง</label><textarea id="code-question" class="field" placeholder="เช่น สร้างฟังก์ชันหาผลรวมของข้อมูล..."></textarea></div><button class="primary-btn">⌘ สร้างโค้ดเสนอ</button></form><div class="divider"></div><pre id="code-output" class="output code-output">รอคำสั่งสร้างโค้ด...</pre>`);
 else if(route==='intent')main=card('สร้าง Intent Lock','บันทึกเจตนาใหม่เป็นเหตุการณ์โดยไม่ลบเจตนาเก่า',`<form id="intent-form"><div class="form-block"><label for="intent-statement">ข้อความเจตนา</label><textarea class="field" id="intent-statement" placeholder="ระบุเป้าหมาย ขอบเขต และข้อจำกัด"></textarea></div><div class="form-inline"><select id="intent-task" class="field small-field"><option value="CHAT">CHAT — ถาม</option><option value="WORK">WORK — สั่งงาน</option></select><button class="primary-btn">⌖ บันทึก Intent</button></div></form><pre id="intent-output" class="output" style="margin-top:18px">รอรับเจตนา...</pre>`);
 else if(route==='gis')main=card('BigMap ↔ Meaning Space · WGS84 Lat/Lon + UTM XYZ',
 'WGS84 Lat/Lon ↔ UTM WGS84 X/Y (เมตร) + Z แยก Vertical CRS · Semantic XYZ ไม่ใช่พิกัดพื้นที่จริง',
 `<div class="gis-badge-row"><span class="pill good">WGS84 / EPSG:4326</span><span class="pill purple">UTM Zone 48N EPSG:32648 (อุบลฯ) / Auto Zone</span><span class="pill">EPSG:4979 สำหรับความสูงเหนือทรงรี</span><span class="pill">GeoJSON=[lon,lat,(z)]</span><span class="pill">Offline · no basemap</span><span class="pill warn">Survey: NOT CERTIFIED</span></div>
 <div class="geo-map">${bigmapMapSvg(allMapFeatures())}</div><p class="fine-print">แสดงตำแหน่งสัมพัทธ์โดยฉายลงระนาบจาก Latitude/Longitude บนเครื่องเท่านั้น ไม่ใช่ภาพแผนที่ฐานหรือค่ารังวัดที่รับรองแล้ว</p>
 <div class="gis-tools"><button class="secondary-btn" data-action="geo-dual-csv">⇩ CSV Lat/Lon + UTM XYZ</button><button class="secondary-btn" data-action="geo-csv">⇩ CSV พิกัดอย่างเดียว (lat,lon)</button><button class="secondary-btn" data-action="geo-geojson">⇩ GeoJSON วัตถุ/ความสัมพันธ์</button></div>
 <div class="divider"></div><h2>สร้างวัตถุภูมิศาสตร์</h2><p class="card-sub">รองรับจุด แนวเส้น และพื้นที่ · ตรวจสอบค่าพิกัดและบันทึก Revision เริ่มต้น · ไม่แก้ Canonical</p>
 <form id="bigmap-create-form" class="gis-form"><div class="form-inline"><div class="form-block"><label for="bm-name">ชื่อวัตถุ</label><input class="field" id="bm-name" maxlength="120" required value="ทุ่นลอย 1"></div><div class="form-block"><label for="bm-kind">ประเภท</label><select id="bm-kind" class="field"><option value="Point">Point · จุด</option><option value="LineString">LineString · แนวเส้น</option><option value="Polygon">Polygon · พื้นที่ปิด</option></select></div></div>
 <div class="form-block"><label for="bm-coords">พิกัด Latitude, Longitude[, Z] (หนึ่งรายการต่อบรรทัด)</label><textarea class="field" id="bm-coords" rows="5" required>16.199682, 103.197839</textarea></div>
 <div class="form-block"><label for="bm-vertical-crs">ระบบอ้างอิง Z (ต้องระบุเมื่อมี Z)</label><select id="bm-vertical-crs" class="field"><option value="">ไม่มี Z / ไม่ทราบความสูง</option><option value="EPSG:4979">EPSG:4979 · WGS84 Ellipsoidal Height</option><option value="EPSG:5773">EPSG:5773 · EGM96 Height</option><option value="EPSG:3855">EPSG:3855 · EGM2008 Height</option></select></div>
 <div class="form-inline"><div class="form-block"><label for="bm-origin">Origin reference / ที่มาของเจตนา</label><input class="field" id="bm-origin" required value="local-origin-declaration" maxlength="200"></div><div class="form-block"><label for="bm-source">แหล่งข้อมูล / Source Ref</label><input class="field" id="bm-source" required value="manual:local-console" maxlength="200"></div></div>
 <button class="primary-btn" type="submit">＋ บันทึกวัตถุใน BigMap</button></form>
 <div class="divider"></div><h2>เชื่อม Feature กับ Meaning Core</h2><p class="card-sub">ใส่ Feature ID ที่บันทึกแล้วและ CID ที่มีอยู่ · สร้างเป็นความสัมพันธ์ Candidate เท่านั้น</p>
 <form id="bigmap-link-form" class="gis-form"><div class="form-inline"><div class="form-block"><label for="bm-link-feature">Feature ID</label><input class="field" id="bm-link-feature" list="bigmap-features-list" required placeholder="geo_..."><datalist id="bigmap-features-list">${state.bigmapFeatures.map(f=>`<option value="${esc(f.feature_id)}">${esc(f.label)}</option>`).join('')}</datalist></div><div class="form-block"><label for="bm-link-cid">Meaning CID</label><input class="field" id="bm-link-cid" placeholder="CID ที่มีอยู่ใน Meaning Space" required></div></div>
 <div class="form-inline"><div class="form-block"><label for="bm-link-relation">ความสัมพันธ์</label><select id="bm-link-relation" class="field"><option value="represents">represents</option><option value="located_at">located_at</option><option value="part_of">part_of</option><option value="near">near</option><option value="flows_along">flows_along</option><option value="bounds">bounds</option><option value="observed_at">observed_at</option></select></div><div class="form-block"><label for="bm-link-origin">Origin reference</label><input class="field" id="bm-link-origin" required value="local-origin-declaration"></div></div>
 <button class="secondary-btn" type="submit">＋ เชื่อม CID แบบ Candidate</button></form>
 <pre id="bigmap-result" class="output" aria-live="polite">รอเพิ่มวัตถุหรือเชื่อมความหมาย...</pre>
 <h2 style="margin-top:20px">ทะเบียน BigMap (${state.bigmapFeatures.length})</h2>${bigmapTable(state.bigmapFeatures)}
 <div class="divider"></div><h2>ทะเบียนจุดรุ่นเดิม (${state.geoPoints.length})</h2><p class="card-sub">ยังอ่านได้เพื่อความเข้ากันได้ย้อนหลัง ไม่ย้ายข้อมูลหรือเขียนทับโดยอัตโนมัติ</p>${geoPointTable(state.geoPoints)}
 `);
 else if(route==='meaning')main=card('Semantic Graph','กราฟนี้แสดงความสัมพันธ์จากฐาน SQLite Local ไม่ใช่การประมวลผล 3D ภายนอก',graphSvg(d.graph||{}))+card('Meaning Cores ที่บันทึก','ตัวอย่างรายการล่าสุด',table(d.records));
 else if(route==='s10')main=card('S-10 Acceptance','เกณฑ์ที่ยังขาดหลักฐานจะไม่แสดง PASS',`<div style="margin-top:16px">${(d.gates||[]).map(g=>`<div class="connection-row"><div><strong>${esc(g.id)} — ${esc(g.title)}</strong><small>${esc(g.references)}</small></div>${statePill(g.status)}</div>`).join('')}</div>`);
 else if(route==='skills'){
 const catalog=d.gpt_skills||{skills:[],snapshot_total:0}, stat=d.learning_summary||{}, local=d.skills_catalog?.skills||[];
 const data=(catalog.skills||[]).map(x=>({ชื่อ:x.title,หมวด:x.category_th,ผู้ให้บริการ:x.provider,สถานะ:x.availability,แหล่งที่มา:x.uri}));
 main=card('GPT Skill Library — ศึกษาทักษะจากข้อมูลที่เปิดเผย',
  `นำเข้าคำอธิบาย ${catalog.snapshot_total} ทักษะ • ทักษะ Local ${local.length} • ไม่มีสิทธิ์เรียก GPT/ปลั๊กอินโดยอัตโนมัติ`,
  `${errBanner('ข้อมูลนี้เป็นเพียงทะเบียนทักษะที่เปิดเผยในเซสชัน GPT ณ วันที่ 10 พ.ย. 2569 ไม่ใช่การคัดลอกน้ำหนักโมเดลหรือสิทธิ์บัญชีผู้ใช้')}
   <div class="metric-grid"><div class="card metric"><div class="metric-top">พบคำอธิบาย</div><div class="metric-number">${num(catalog.snapshot_total)}</div></div><div class="card metric"><div class="metric-top">ตัวอย่างรออนุมัติ</div><div class="metric-number">${num(stat.pending_lessons)}</div></div><div class="card metric"><div class="metric-top">อนุมัติใน Local</div><div class="metric-number">${num(stat.locally_approved_lessons)}</div></div></div>
   <form id="skill-match-form" class="form-block"><label for="skill-query">อธิบายงานที่ต้องการ (ภาษาไทยหรืออังกฤษ)</label><div class="form-inline"><input class="field" id="skill-query" maxlength="350" placeholder="เช่น สร้างตารางใน Google Sheets พร้อมสูตรคำนวณ" required><button class="primary-btn" type="submit">ค้นหาทักษะที่เกี่ยวข้อง</button></div></form><div id="skill-match-results" aria-live="polite"></div>
   <h2 style="margin-top:24px">คลังทักษะที่ค้นพบ</h2><p class="card-sub">จัดเรียงตาม Provider • สถานะคือ DISCOVERED เท่านั้น</p>${table(data,100)}`)
 +card('สร้างตัวอย่างสำหรับให้ OLGM เรียนรู้','ตัวอย่างใหม่ถูกเก็บเป็น Candidate ก่อน ไม่ใช้ปรับการตอบจนกว่า Origin ลงนามอนุมัติ',
 `<form id="skill-teach-form">
 <div class="form-block"><label for="teach-uri">ทักษะเป้าหมาย</label><select class="field" id="teach-uri" required>${catalog.skills.map(x=>`<option value="${esc(x.uri)}">${esc(x.provider)} / ${esc(x.title)}</option>`).join('')}</select></div>
 <div class="form-block"><label for="teach-question">ตัวอย่างคำสั่งภาษาไทย</label><textarea id="teach-question" class="field" maxlength="800" required placeholder="ตัวอย่าง: สร้างหน้ารายงานผลการสำรวจใน Google Docs"></textarea></div>
 <div class="form-inline"><div class="form-block"><label for="teach-source">อ้างอิงที่มาของตัวอย่าง</label><input id="teach-source" class="field" maxlength="400" required placeholder="URI หรือเลขเอกสารอ้างอิง"></div><div class="form-block"><label for="teach-origin">Origin reference</label><input id="teach-origin" class="field" maxlength="200" required placeholder="origin:declaration-reference"></div></div>
 <div class="form-block"><label for="teach-rights">สิทธิ์การใช้ข้อมูล</label><select id="teach-rights" class="field"><option value="UNKNOWN">ยังไม่ยืนยันสิทธิ์ (ไม่อนุมัติใช้งาน)</option><option value="ORIGIN_OWNED">Origin เป็นเจ้าของข้อมูล</option><option value="PERMISSION_GRANTED">มีหลักฐานอนุญาต</option><option value="PUBLIC_DOMAIN">มีหลักฐานสาธารณสมบัติ</option></select></div>
 <button type="submit" class="secondary-btn">บันทึกเป็น Candidate (ยังไม่เรียนรู้จริง)</button></form>
 <pre id="skill-teach-result" class="output" style="margin-top:14px">การอนุมัติทำผ่านคำสั่ง Origin ที่ลงลายมือชื่อแยกจาก UI เท่านั้น</pre>`)
 +card('Local Built-in Skills','ทักษะใน Runtime ที่มี Handler แต่การเรียกใช้งานต้องผ่าน CANTI',table(local));
 }
 else if(route==='valueguard')main=card('ValueGuard — มูลค่าสูง',`แจ้ง Origin ก่อนเมื่อมูลค่าประมาณการเกิน 1,000,000 บาท`, `<div class="connection-row"><div><strong>เกณฑ์มูลค่า</strong><small>ต้องมีข้อมูลและหลักฐานการประเมิน</small></div><strong>1,000,000 THB</strong></div><div class="connection-row"><div><strong>Origin</strong><small>อีเมลปลายทางเมื่อผ่านเงื่อนไขและได้รับอนุญาต</small></div><strong>${esc(d.policy?.owner_email||'—')}</strong></div><div class="connection-row"><div><strong>สถานะการส่งจริง</strong><small>ไม่มีการส่งอีเมลจากหน้า Console นี้</small></div>${statePill(d.policy?.status)}</div>${table(d.records)}`);
 else if(route==='origin')main=card('Origin / Canonical / Core 0','Core 0 เป็นรากเชิงแนวคิด ไม่ใช่ทรัพยากรที่ Agent เขียนได้',`<div class="detail-banner"><strong>Immutable boundary</strong> — การเข้า Console ไม่ใช่การพิสูจน์ตัวตน Origin; ห้ามแก้ Core 0, Canonical หรือ Archive โดยอ้างสิทธิ์จาก UI</div><pre class="output">${esc(JSON.stringify(d.canonical_verification,null,2))}</pre>${table(d.records)}`);
 else if(route==='observer'||route==='models')main=card('Model Gateway','โมเดลไม่ถูกเปิดหรือเชื่อมต่อโดยอัตโนมัติ',`<div class="detail-banner">การตั้งค่าผู้ให้บริการเป็นเพียงข้อเสนอ เมื่อไม่ผ่านการตรวจสิทธิ์ Origin และ Egress Policy จะยังไม่เรียกโมเดลใด</div><div class="connection-row"><strong>สถานะการเชื่อมต่อ</strong>${statePill(d.connection)}</div><button class="secondary-btn" data-route="settings">⚙ เปิดการตั้งค่า</button>`);
 else if(['computers','plugins','spaces'].includes(route)){
 const kind=route==='computers'?'computer':route==='plugins'?'plugin':'space';
 const action=kind==='computer'?'computer.status':kind==='plugin'?'plugin.describe':'space.list';
 const register=state.role==='admin'?`<div class="divider"></div><h2>ลงทะเบียนทรัพยากรแบบ NOT_CONNECTED</h2><p class="card-sub">ลงทะเบียนรายการและขอบเขตเท่านั้น การเชื่อมต่อและสิทธิ์เรียกใช้จริงต้องตรวจแยกต่างหาก</p><form id="register-form" data-kind="${kind}" data-action-value="${action}"><div class="form-inline"><div class="form-block"><label>Resource ID</label><input class="field" id="res-id" required placeholder="local.xadmin"></div><div class="form-block"><label>ชื่อแสดง</label><input class="field" id="res-name" required></div></div><div class="form-inline"><div class="form-block"><label>Provider</label><input class="field" id="res-provider" value="local" required></div><div class="form-block"><label>Source reference</label><input class="field" id="res-source" value="local-operator-declaration" required></div></div><button class="secondary-btn" type="submit">+ ลงทะเบียน (ไม่เชื่อมต่อจริง)</button></form>`:'<div class="fine-print" style="margin-top:14px">การลงทะเบียนทรัพยากรต้องใช้ ADMIN CONSOLE TOKEN</div>';
 main=card('ทะเบียนการเข้าถึง',`ข้อมูลจากทะเบียนในเครื่อง ไม่ใช่ผลการเชื่อมต่อ Connector สด`,`${errBanner('ยังไม่มี Bridge ที่ยืนยันการเข้าถึงเครื่อง/Plugin/Space จริง ห้ามนับรายการที่ลงทะเบียนเป็น CONNECTED')}${table(d.records)}${register}`);
 }
 else if(route==='control'||route==='queue'||route==='canti')main=card('คำสั่งและสิทธิ์การปฏิบัติ','ทุกการลงมือจริงต้องมี CANTI Grant, Intent Revision และ Signed Approval',`${errBanner('Console ใช้สำหรับเสนอและตรวจสอบสถานะ ไม่ใช่ทางลัดเปิดสิทธิ์หรือทำคำสั่งที่ยังไม่อนุมัติ')}${table(d.records)}${route==='control'?`<div class="divider"></div><h2>เสนอคำสั่งเข้าสู่ Control Plane</h2><p class="card-sub">ต้องมี Intent ID/Hash และทรัพยากรในทะเบียนก่อน ไม่ใช่การอนุมัติหรือการ Execute</p><form id="control-propose-form"><div class="form-inline"><div class="form-block"><label>Intent ID</label><input id="ctl-intent-id" class="field" required></div><div class="form-block"><label>Intent Hash</label><input id="ctl-intent-hash" class="field" required></div></div><div class="form-inline"><div class="form-block"><label>Resource ID</label><input id="ctl-resource" class="field" required></div><div class="form-block"><label>Action</label><input id="ctl-action" class="field" required placeholder="computer.status"></div></div><button type="submit" class="secondary-btn">ส่งข้อเสนอที่ยังไม่อนุมัติ</button></form><pre class="output" id="control-output" style="margin-top:14px">รอคำสั่ง...</pre>`:''}`);
 else if(route==='audit')main=card('Audit Integrity','Hash Chain และหลักฐานเหตุการณ์ในเครื่อง',`<div style="margin:15px 0">${statePill(d.verification?.status)} <span class="muted">${esc(d.verification?.message)}</span></div>${table(d.records)}`);
 else main=card('ข้อมูลและสถานะโมดูล','อ่านจาก Runtime โดยตรงและแสดงเฉพาะรายการที่อนุญาต',`${table(d.records)}`);
 $('#page').innerHTML=heading(m.group.toUpperCase(),m.title,m.subtitle,actions)+`<div class="detail-banner">สถานะโมดูล: ${statePill(d.connection)} &nbsp;•&nbsp; ${esc(d.caveat||'')}</div><div class="grid-one">${main}</div>`;
}
async function renderSettings(){const d=await api('settings?scope='+encodeURIComponent(state.settingsScope)+(state.settingsScope==='role'?'&scope_id='+encodeURIComponent(state.settingsRole):''));state.settings=d;const cats=d.categories;const keys=d.schema.filter(s=>s.category===state.settingCategory);const scopes=state.role==='admin'?['user','role','workspace']:['user'];const sel=state.settingsScope;$('#page').innerHTML=heading('CONFIGURATION','การตั้งค่าทุกระดับ','ค่าเริ่มต้น → Workspace → Role → User • Append-only พร้อมประวัติและการอนุมัติ',`<button class="secondary-btn" data-action="refresh">↻ รีเฟรช</button>`)+errBanner('ล็อกด้าน Origin / Security / CANTI / ValueGuard ไม่สามารถปลดได้ใน UI การตั้งค่าที่มีความเสี่ยงเป็นเพียงข้อเสนอรอ Origin')+`<section class="card"><div class="settings-toolbar"><div class="settings-groups">${Object.entries(cats).map(([key,label])=>`<button class="segment ${state.settingCategory===key?'active':''}" data-category="${esc(key)}">${esc(label)}</button>`).join('')}</div><select id="settings-scope" class="field small-field" aria-label="ระดับการตั้งค่า">${scopes.map(s=>`<option value="${s}" ${s===sel?'selected':''}>${s==='user'?'ผู้ใช้':s==='role'?'บทบาท':'Workspace'}</option>`).join('')}</select>${sel==='role'?`<select id="settings-role-target" class="field small-field" aria-label="บทบาทเป้าหมาย">${['admin','operator','viewer'].map(x=>`<option value="${x}" ${state.settingsRole===x?'selected':''}>${x}</option>`).join('')}</select>`:''}</div><div id="setting-content">${keys.map(s=>{const info=d.effective[s.key],over=d.overrides[s.key],src=info.source,lock=s.risk==='locked';let inp='';const value=over?.mode==='set'?over.value:info.value;const id='set-'+s.key.replaceAll('.','-');if(s.type==='boolean')inp=`<input class="toggle" type="checkbox" id="${esc(id)}" data-key="${esc(s.key)}" ${value?'checked':''} ${lock?'disabled':''}>`;else if(s.type==='select')inp=`<select class="field" id="${esc(id)}" data-key="${esc(s.key)}" ${lock?'disabled':''}>${s.choices.map(x=>`<option value="${esc(x)}" ${value===x?'selected':''}>${esc(x)}</option>`).join('')}</select>`;else inp=`<input class="field" type="${s.type==='number'?'number':'text'}" id="${esc(id)}" data-key="${esc(s.key)}" value="${esc(value)}" ${s.type==='number'?`step="${Number.isInteger(s.minimum)&&Number.isInteger(s.maximum)?1:.1}"`:''} ${lock?'disabled':''}>`;return `<div class="setting-row"><div class="setting-name"><strong>${esc(s.label)}</strong><small>${esc(s.key)}<br>${esc(s.description)}</small></div><div>${inp}</div><div class="setting-source"><div class="pill ${lock?'purple':'good'}">${lock?'LOCKED':esc(src)}</div><div style="margin-top:9px">${lock?'Origin protected':`<button class="quiet-btn" data-save-setting="${esc(s.key)}">บันทึก</button><button class="quiet-btn" data-reset-setting="${esc(s.key)}">คืนค่า</button>`}</div></div></div>`}).join('')}</div></section><section class="card" style="margin-top:15px"><h2>ประวัติการตั้งค่า</h2><p class="card-sub">ทุกเหตุการณ์ถูกบันทึกเพิ่ม ไม่มีการเขียนทับประวัติ</p>${table(d.history)}</section>`;
 applyAppearance(d.effective);
}
function applyAppearance(data){const eff=data||state.settings?.effective;if(!eff)return;const theme=eff['appearance.theme']?.value;document.body.classList.toggle('theme-light',theme==='light');const size=eff['appearance.font_scale']?.value||100;document.documentElement.style.fontSize=(Number(size)*.14)+'px'}
async function saveSetting(k,reset){const d=state.settings,def=d.schema.find(s=>s.key===k);if(!def||def.risk==='locked')return;const info=d.overrides[k];const el=document.getElementById('set-'+k.replaceAll('.','-'));let value=def.type==='boolean'?el.checked:def.type==='number'?Number(el.value):el.value;const reason=prompt('เหตุผลในการเปลี่ยนการตั้งค่า (บันทึกใน Audit):','ปรับปรุงการตั้งค่าการใช้งาน');if(!reason)return;const payload={scope:d.scope,scope_id:d.scope_id,key:k,reason,expected_revision:info.revision};if(!reset)payload.value=value;try{const o=await api('settings/'+(reset?'reset':'change'),'POST',payload);toast(o.status==='AWAITING_ORIGIN'?'บันทึกข้อเสนอแล้ว ยังไม่มีผลจนกว่า Origin อนุมัติ':'บันทึกค่าตั้งเรียบร้อย');await renderSettings()}catch(e){toast(e.message,true)}}
async function appInit(){try{state.bootstrap=await api('bootstrap');state.role=state.bootstrap.role;$('#login-screen').classList.add('hidden');goto(location.hash.slice(1)||'overview')}catch(e){$('#login-screen').classList.remove('hidden')}}
$('#login-form').addEventListener('submit',async e=>{e.preventDefault();const token=$('#login-token').value;try{await api('login','POST',{token});$('#login-token').value='';$('#login-error').textContent='';await appInit()}catch(e){$('#login-error').textContent='รหัสไม่ถูกต้อง หรือ Console ไม่พร้อม'}});
$('#logout-btn').addEventListener('click',async()=>{try{await api('logout','POST',{})}finally{location.reload()}});
document.body.addEventListener('click',e=>{const r=e.target.closest('[data-route]');if(r){goto(r.dataset.route);return}const action=e.target.closest('[data-action]');if(action?.dataset.action==='refresh'){goto(state.route);return}if(action?.dataset.action==='geo-dual-csv'){exportDualCSV();return}if(action?.dataset.action==='geo-csv'){exportGeoCSV();return}if(action?.dataset.action==='geo-geojson'){exportGeoJSON();return}const cat=e.target.closest('[data-category]');if(cat){state.settingCategory=cat.dataset.category;renderSettings();return}const save=e.target.closest('[data-save-setting]');if(save){saveSetting(save.dataset.saveSetting,false);return}const reset=e.target.closest('[data-reset-setting]');if(reset){saveSetting(reset.dataset.resetSetting,true);return}});
document.body.addEventListener('change',e=>{if(e.target.id==='settings-scope'){state.settingsScope=e.target.value;renderSettings()}if(e.target.id==='settings-role-target'){state.settingsRole=e.target.value;renderSettings()}});
document.body.addEventListener('submit',async e=>{
 if(e.target.id==='register-form'){
  e.preventDefault();const kind=e.target.dataset.kind,action=e.target.dataset.actionValue;
  const payload={resource_id:$('#res-id').value,kind,display_name:$('#res-name').value,provider:$('#res-provider').value,source_ref:$('#res-source').value,actions:[action],connection_state:'NOT_CONNECTED'};
  try{const r=await api('resource','POST',payload);toast('บันทึกในทะเบียนแบบยังไม่เชื่อมต่อ: '+r.status);goto(state.route)}catch(ex){toast(ex.message,true)}return;
 }
 if(e.target.id==='control-propose-form'){
  e.preventDefault();const payload={intent_id:$('#ctl-intent-id').value,intent_hash:$('#ctl-intent-hash').value,resource_id:$('#ctl-resource').value,action:$('#ctl-action').value,args:{}};
  try{const r=await api('control-propose','POST',payload);$('#control-output').textContent=JSON.stringify(r,null,2);toast('สร้างข้อเสนอแล้ว ยังไม่มีการ Execute')}catch(ex){$('#control-output').textContent='ERROR: '+ex.message;toast(ex.message,true)}return;
 }
 if(e.target.id==='skill-match-form'){
  e.preventDefault();const out=$('#skill-match-results');out.textContent='กำลังค้นหาจากคำอธิบายทักษะ...';
  try{const d=await api('gpt-skill-match?q='+encodeURIComponent($('#skill-query').value));
   out.innerHTML=d.candidates.length?`<div class="data-table-wrap"><table class="data-table"><thead><tr><th>ทักษะ</th><th>เหตุผลที่เลือก</th><th>สถานะ</th></tr></thead><tbody>${d.candidates.map(x=>`<tr><td>${esc(x.title)}<small style="display:block">${esc(x.provider)}</small></td><td>${esc(x.matched_terms.join(', '))}</td><td>${statePill(x.status)}</td></tr>`).join('')}</tbody></table></div>`:'<p class="fine-print">ยังไม่พบทักษะที่ตรงจากคลังข้อมูลปัจจุบัน — ไม่เดาความสามารถเพิ่มเติม</p>';
  }catch(ex){out.textContent='ERROR: '+ex.message;toast(ex.message,true)}return;
 }
 if(e.target.id==='skill-teach-form'){
  e.preventDefault();const payload={uri:$('#teach-uri').value,example_text:$('#teach-question').value,source_ref:$('#teach-source').value,origin_ref:$('#teach-origin').value,rights_basis:$('#teach-rights').value};
  try{const result=await api('gpt-skill-propose','POST',payload);$('#skill-teach-result').textContent=JSON.stringify(result,null,2);toast('บันทึกตัวอย่างรอ Origin อนุมัติแล้ว')}
  catch(ex){$('#skill-teach-result').textContent='ERROR: '+ex.message;toast(ex.message,true)}return;
 }
 if(e.target.id==='bigmap-create-form'){
  e.preventDefault();
  try{
   const geom=parseLatLonLines($('#bm-coords').value,$('#bm-kind').value);
   const payload={label:$('#bm-name').value,geometry:geom,vertical_crs:$('#bm-vertical-crs').value||null,origin_ref:$('#bm-origin').value,source_ref:$('#bm-source').value};
   const r=await api('bigmap/add','POST',payload);
   toast(`บันทึก Feature ${r.feature.feature_id} แล้ว`);await renderModule('gis');
  }catch(ex){if($('#bigmap-result'))$('#bigmap-result').textContent='ERROR: '+ex.message;toast(ex.message,true)}return;
 }
 if(e.target.id==='bigmap-link-form'){
  e.preventDefault();
  try{
   const p={feature_id:$('#bm-link-feature').value.trim(),cid:$('#bm-link-cid').value.trim(),relation_type:$('#bm-link-relation').value,origin_ref:$('#bm-link-origin').value};
   const r=await api('bigmap/link','POST',p);
   toast('บันทึก Candidate Link แล้ว · ยังไม่ใช่ Verified Fact');await renderModule('gis');
  }catch(ex){if($('#bigmap-result'))$('#bigmap-result').textContent='ERROR: '+ex.message;toast(ex.message,true)}return;
 }
 if(e.target.id==='gis-add-form'){
  e.preventDefault();const la=$('#gis-lat'),lo=$('#gis-lon');
  if(!la.value.trim()||!lo.value.trim()){toast('กรอกพิกัดให้ครบทั้งสองค่า',true);return;}
  const payload={label:$('#gis-label').value,lat:Number(la.value),lon:Number(lo.value)};
  try{const r=await api('gis-add-point','POST',payload);if(r.status!=='RECORDED')throw Error(r.status);toast('บันทึกพิกัด Lat / Long แล้ว');await renderModule('gis');}catch(ex){$('#gis-output').textContent='ERROR: '+ex.message;toast(ex.message,true)}return;
 }
 if(!['thai-form','code-form','intent-form'].includes(e.target.id))return;e.preventDefault();const form=e.target.id;let path,payload,target;if(form==='thai-form'){path='thai-answer';payload={question:$('#thai-question').value};target='#thai-output'}else if(form==='code-form'){path='code';payload={request:$('#code-question').value};target='#code-output'}else{path='intent';payload={statement:$('#intent-statement').value,task_type:$('#intent-task').value};target='#intent-output'};try{$(target).textContent='กำลังประมวลผล...';const r=await api(path,'POST',payload);$(target).textContent=typeof r==='string'?r:JSON.stringify(r,null,2);toast('ประมวลผลเสร็จแล้ว')}catch(ex){$(target).textContent='ERROR: '+ex.message;toast(ex.message,true)}});
function searchDialog(){const d=$('#search-dialog');$('#command-input').value='';filterCommands('');d.showModal();$('#command-input').focus()}
function filterCommands(q){const modules=state.bootstrap?.modules||[];const words=q.toLocaleLowerCase();const matching=modules.filter(m=>(m.title+' '+m.subtitle+' '+m.key).toLocaleLowerCase().includes(words));$('#command-results').innerHTML=matching.slice(0,25).map(m=>`<button class="command-item" data-route="${esc(m.key)}"><span>${esc(icons[m.key]||'◈')}　${esc(m.title)}</span><small>${esc(m.subtitle)}</small></button>`).join('')||'<p class="fine-print" style="padding:20px">ไม่พบโมดูล</p>'}
$('#command-input').addEventListener('input',e=>filterCommands(e.target.value));$('#search-open').addEventListener('click',searchDialog);$('#command-results').addEventListener('click',e=>{if(e.target.closest('[data-route]'))$('#search-dialog').close()});document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();if(state.bootstrap)searchDialog()}});
$('#nav-open').addEventListener('click',()=>{$('#sidebar').classList.add('open');$('#screen-overlay').classList.add('open')});$('#nav-close').addEventListener('click',()=>{$('#sidebar').classList.remove('open');$('#screen-overlay').classList.remove('open')});$('#screen-overlay').addEventListener('click',()=>{$('#sidebar').classList.remove('open');$('#screen-overlay').classList.remove('open')});
appInit();
