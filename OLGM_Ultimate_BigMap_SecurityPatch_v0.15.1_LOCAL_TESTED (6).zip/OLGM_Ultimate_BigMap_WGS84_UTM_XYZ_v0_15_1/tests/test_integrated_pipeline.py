"""Code-level OLGM acceptance and adversarial checks; NOT a live model/training certification."""
import hashlib
import json
import os
import sqlite3
import uuid
import pytest
from olgm.meaning_space import MeaningSpace
from olgm.audit import AuditChain
from olgm.otfa import OTFA
from olgm.canti import CANTI
from olgm.observer import DisabledBackend,ModelBackend,Observer
from olgm.pipeline import IntegratedRuntime
from olgm.intent import IntentLedger
from olgm.canonical import CanonicalLedger
from olgm.semantic import MeaningEngine
from olgm.evidence import EvidenceLedger
from olgm.checkpoints import Checkpoints,STAGES
from olgm.quality import quality_proof,assess_five_axes,logical_gravity
from olgm.multimodal import MultimodalIngest
from olgm.dictionary import import_dictionary_tsv
from olgm.training import evaluate_jsonl

@pytest.fixture
def rt(tmp_path):
    db=str(tmp_path/'olgm.db')
    ms=MeaningSpace(db);audit=AuditChain(db)
    return IntegratedRuntime(ms,DisabledBackend(),audit,CANTI(db),OTFA(ms),signing_key='test-only-key')


def seed(rt):
    for id_,name in [('water','น้ำ'),('river','แม่น้ำ'),('flow','ไหล')]:
        rt.ms.add_core(id_,'th',name,'graph test',origin_ref='origin-test')
    rt.ms.add_edge('r1','water','river','flows_to',origin_ref='origin-test')
    rt.ms.add_edge('r2','river','flow','causes',origin_ref='origin-test')


def test_boundary_denies_every_core0_operation(rt):
    d=rt.intent.refuse_core0_operation('agent','inspect contents')
    assert d['status']=='DENIED'
    with sqlite3.connect(rt.ms.db_path) as db:
        tables={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert 'core0_contents' not in tables


def test_intent_lock_revision_and_latest_proof(rt):
    lock=rt.intent.create('a','origin-ext','Build safe graph',constraints={'scope':'sandbox'})
    same=rt.intent.proof(lock['intent_id'],lock['intent_hash'])
    assert same['status']=='PASS'
    revised=rt.intent.revise(lock['intent_id'],statement='Build graph with evidence',reason='clarification',
                              expected_hash=lock['intent_hash'],actor='a')
    assert revised['revision']==2
    assert rt.intent.proof(lock['intent_id'],lock['intent_hash'])['status']=='ROOT_REENTRY'
    assert rt.intent.latest(lock['intent_id'])['constraints']['scope']=='sandbox'
    with pytest.raises(ValueError,match='silent_delete'):
        rt.intent.revise(lock['intent_id'],constraints_delta={'scope':None},reason='delete',
                         expected_hash=revised['intent_hash'],actor='a')


def test_intent_does_not_allow_actor_substitution(rt):
    lock=rt.intent.create('a','origin-ext','X')
    with pytest.raises(PermissionError):
        rt.intent.revise(lock['intent_id'],statement='Y',reason='x',expected_hash=lock['intent_hash'],actor='b')


def test_policy_reference_immutable_and_nonsemantic(rt):
    d='a'*64
    p=rt.intent.register_policy_ref('ext','url-to-locked-file',d,'five-axes-external','v1')
    assert p['status']=='REGISTERED_REFERENCE_ONLY'
    with pytest.raises(sqlite3.IntegrityError):
        rt.intent.register_policy_ref('ext','changed',d,'five-axes-external','v2')


def test_canonical_append_inherit_no_overwrite(rt):
    c=rt.canonical.initialize('master.pdf','b'*64,'origin-test')
    p=rt.canonical.propose_and_apply(str(uuid.uuid4()),c['state_hash'],
                       {'experiment_001':{'feature':'graph traversal'}},'research delta',
                       ['research.md'],'origin-test','origin-test',['semantic'],['T06'], 'low')
    assert p['status']=='APPENDED_WITH_INHERITANCE'
    assert rt.canonical.verify()['status']=='PASS'
    with pytest.raises(ValueError,match='no_overwrite'):
        rt.canonical.propose_and_apply(str(uuid.uuid4()),p['state_hash'],
                       {'experiment_001':{'feature':'deleted'}},'bad delta',['x'],'origin-test','origin-test',
                       ['semantic'],['T06'],'low')
    with pytest.raises(PermissionError):
        rt.canonical.propose_and_apply(str(uuid.uuid4()),p['state_hash'],
                       {'invariants':[]},'bad delta',['x'],'origin-test','origin-test',
                       ['semantic'],['T06'],'low')


def test_canonical_tamper_detected(rt):
    rt.canonical.initialize('master','a'*64,'actor')
    with sqlite3.connect(rt.ms.db_path) as db:
        db.execute("UPDATE canonical_events SET state_json='{}' WHERE seq=1")
    assert rt.canonical.verify()['status']=='FAIL'


def test_categories_do_not_change_edges_or_cid(rt):
    seed(rt)
    original=rt.ms.get_edge('r1')
    rt.ms.assign_category('water','วัสดุ','class revision')
    rt.ms.assign_category('water','ธรรมชาติ','new classification')
    assert rt.ms.get_edge('r1')==original
    assert rt.ms.get_core('water')['cid']=='water'
    assert rt.ms.get_categories('water')==['ธรรมชาติ','วัสดุ']


def test_graph_path_alternates_and_resonance(rt):
    seed(rt)
    rt.ms.add_edge('r3','water','flow','causes',origin_ref='origin-test')
    result=rt.semantic.candidate_paths('water','flow')
    assert {tuple(p['edge_ids']) for p in result['candidate_paths']}=={('r1','r2'),('r3',)}
    found=rt.semantic.resonance(['water'],depth=2)
    assert {x['cid'] for x in found['candidates']}=={'water','river','flow'}


def test_conflict_preserves_both_edges(rt):
    seed(rt)
    rt.ms.add_edge('no1','water','river','does_not_cause',origin_ref='origin-test')
    rt.ms.add_edge('yes1','water','river','causes',origin_ref='origin-test')
    conflicts=rt.semantic.store_conflicts()
    assert any(set(x['edge_ids'])=={'no1','yes1'} for x in conflicts)
    assert rt.ms.get_edge('no1') and rt.ms.get_edge('yes1')


def test_attestation_requires_real_registered_evidence_and_authority(rt):
    seed(rt)
    with pytest.raises(ValueError):
        rt.semantic.attest_edge('r1',['fake'],'reviewer','checked')
    rt.ms.add_evidence('ev1','local_doc','Water is here')
    assert rt.semantic.attest_edge('r1',['ev1'],'reviewer_reference','manual_review')['effective_status']=='VERIFIED'
    assert rt.semantic.candidate_paths('water','river')['candidate_paths'][0]['statuses']==['VERIFIED']


def test_claim_binding_and_v1_v7_conflict(rt):
    rt.ms.add_evidence('evidence_a','observation','Water is wet; measured once')
    rt.ms.add_evidence('evidence_b','report','Water is not wet in this context')
    cid=rt.evidence.add_claim('Water is wet', 'INFERRED',origin_ref='origin')
    with pytest.raises(ValueError,match='excerpt'):
        rt.evidence.link(cid,'evidence_a','supports','NEVER IN SOURCE',assessed_by='human',assessment_method='manual')
    rt.evidence.link(cid,'evidence_a','supports','Water is wet',assessed_by='human',assessment_method='manual')
    rt.evidence.link(cid,'evidence_b','contradicts','Water is not wet',assessed_by='human',assessment_method='manual')
    result=rt.evidence.v1_v7(cid)
    assert result['status']=='CONFLICTED'
    assert result['checks']['V6_conflicts']['status']=='CONTRADICTED'
    assert result['checks']['V5_independence']['status']=='NOT_TESTED'


def test_quality_never_averages_fail(rt):
    q=quality_proof({'intent_preservation':'FAIL','semantic_coherence':'PASS'})
    assert q['status']=='FAIL'
    axes=assess_five_axes({'ethics':'FAIL','truthfulness':'PASS'})
    assert axes['overall']=='FAIL'
    g=logical_gravity([{'intent_hash':'wrong','evidence':'VERIFIED'}],'current')
    assert g['selected_for_action']==[]


def test_all_stages_receipted_without_model(rt):
    rt.canti.grant('reason','agent.ask','developer',3600)
    result=rt.process('ทำไมน้ำไหล',actor='a',origin_ref='origin-ext',intent_tag='why')
    assert result['status']=='INSUFFICIENT'
    assert result['gate_s10']=='NOT_PASSED'
    assert [x['stage'] for x in result['checkpoints']]==list(STAGES)
    assert rt.checkpoints.verify(result['trace_id'])['status']=='PASS'
    assert rt.audit.verify()[0]


def test_no_auto_grant_and_math_preserved(rt):
    assert rt.process('1+2',intent_tag='numeric')['status']=='DENIED'
    rt.canti.grant('reason','agent.ask','developer',3600)
    r=rt.process('1+2',intent_tag='numeric')
    assert r['status']=='DETERMINISTIC_RESULT'
    assert r['answer']=='3'
    assert r['quality_proof']['status']=='PENDING'
    assert r['can_execute_external_action'] is False


def test_checkpoint_tamper_detected(rt):
    rt.canti.grant('reason','agent.ask','developer',3600)
    r=rt.process('1+2',intent_tag='numeric')
    with sqlite3.connect(rt.ms.db_path) as db:
        db.execute("UPDATE checkpoints SET findings='{}' WHERE trace_id=? AND stage='OP-03'",(r['trace_id'],))
    assert rt.checkpoints.verify(r['trace_id'])['status']=='FAIL'


def test_sandbox_execution_idempotent(rt):
    rt.canti.grant('sandbox_write','sandbox.counter','developer',3600)
    lock=rt.intent.create('a','origin-ext','Increment sandbox counter',task_type='WORK')
    p=rt.actions.propose(lock['intent_id'],lock['intent_hash'], 'sandbox.counter','sandbox.counter',
                         {'name':'test'} ,'a','unique1')
    assert rt.actions.execute(p['plan_id'])['status']=='DENIED'
    assert rt.actions.approve(p['plan_id'],'approver','approval-reference')['status']=='APPROVED'
    first=rt.actions.execute(p['plan_id'])
    second=rt.actions.execute(p['plan_id'])
    assert first['effects']['count']==second['effects']['count']==1
    assert second['idempotent_replay']
    with sqlite3.connect(rt.ms.db_path) as db:
        assert db.execute("SELECT count FROM sandbox_counters WHERE name='test'").fetchone()[0]==1


def test_stale_intent_blocks_sandbox_action(rt):
    rt.canti.grant('sandbox_write','sandbox.note','developer',3600)
    lock=rt.intent.create('a','origin','Write a note',task_type='WORK')
    plan=rt.actions.propose(lock['intent_id'],lock['intent_hash'],'sandbox.note','sandbox.note',
                     {'text':'note'},'a','key')
    assert rt.actions.approve(plan['plan_id'],'other','proof')['status']=='APPROVED'
    rt.intent.revise(lock['intent_id'],'Do something else',reason='changed',
                     expected_hash=lock['intent_hash'],actor='a')
    assert rt.actions.execute(plan['plan_id'])['status']=='ROOT_REENTRY'


def test_unallowed_external_action_denied(rt):
    lock=rt.intent.create('a','origin','run command',task_type='WORK')
    assert rt.actions.propose(lock['intent_id'],lock['intent_hash'],'shell.exec','shell.exec',{},'a','x')['status']=='DENIED'


def test_external_model_never_sees_live_graph(rt):
    rt.ms.add_core('secret','th','ข้อมูลลับ','PRIVATE_CANONICAL_CONTENT',origin_ref='owner')
    class FakeExternal(ModelBackend):
        allow_internal_context=False
        name='remote-mock'
        def __init__(self):self.seen=None
        def complete(self,system,user):
            self.seen=user
            return json.dumps({'meaning_cores':[{'proposed_surface':'A','language':'en','definition':'a','role':'subject'},
                       {'proposed_surface':'B','language':'en','definition':'b','role':'object'}],
                 'relation':{'type':'affects','source':'A','target':'B','direction':'forward','context':'general',
                             'confidence':0.5,'evidence_ref':None},
                 'provenance':{'rationale':'test','unknowns':['unknown']}})
    model=FakeExternal()
    obs=Observer(rt.ms,model,rt.audit).observe('trace','why','user supplied question',['secret'])
    assert obs['status']=='CANDIDATE_OBSERVATION'
    assert 'PRIVATE_CANONICAL_CONTENT' not in model.seen
    assert 'ข้อมูลลับ' not in model.seen


def test_numeric_3d_coordinates_are_stable(rt):
    rt.ms.add_core('A','en','A','test',origin_ref='x',coords=[0,0,0])
    rt.ms.add_core('B','en','B','test',origin_ref='x',coords=[1,0,0])
    with pytest.raises(sqlite3.IntegrityError):
        rt.ms.add_core('C','en','C','test',origin_ref='x',coords=[1,0,0])
    result=rt.cognitive.run('where',['A','B'])
    spatial=next(x['result'] for x in result['executions'] if x['method']=='spatial')
    assert spatial['pairs'][0]['semantic_euclidean_distance']==1


def test_local_dictionary_licensing(tmp_path):
    f=tmp_path/'dict.tsv';f.write_text('language\tsurface_form\tdefinition\nth\tแม่น้ำ\tแม่น้ำสายหนึ่ง\n',encoding='utf-8')
    with pytest.raises(ValueError):import_dictionary_tsv(f,'source','')
    x=import_dictionary_tsv(f,'source','cc-license')
    assert x['count']==1 and x['candidates'][0]['status']=='PROPOSED_NOT_IMPORTED'


def test_multimodal_metadata_no_vision_claim(rt,tmp_path):
    Image=pytest.importorskip('PIL.Image')
    f=tmp_path/'one.png';Image.new('RGB',(3,2)).save(f)
    res=MultimodalIngest(rt.ms.db_path).ingest(f,'origin')
    assert res['metadata']['pixels']==[3,2]
    assert res['semantic_interpretation']=='NOT_TESTED'


def test_optional_gis_transform_round_trip():
    pyproj=pytest.importorskip('pyproj')
    from olgm.gis import BigMapGIS
    gis=BigMapGIS()
    p=gis.wgs84_to_indian_utm48(16.199682,103.197839)
    assert p['target_crs']=='EPSG:24048'
    assert p['field_accuracy_certified'] is False
    back=gis.indian_utm48_to_wgs84(p['X'],p['Y'])
    assert abs(back['lat']-16.199682)<0.0001
    assert abs(back['lon']-103.197839)<0.0001


def test_benchmark_is_real_exact_match_not_learning(tmp_path):
    f=tmp_path/'test.jsonl'
    f.write_text('{"input":"1+2","expected":"3"}\n{"input":"1+1","expected":"2"}\n',encoding='utf-8')
    r=evaluate_jsonl(str(f),lambda s:'3' if s=='1+2' else '2')
    assert r['status']=='EVALUATED' and r['accuracy']==1.0


def test_curiosity_suggests_gaps_without_executing(rt):
    seed(rt)
    x=rt.curiosity.suggest('trace',['water'])
    assert x['status']=='SUGGESTIONS_ONLY'
    assert x['tool_executions']==0
    assert 0<len(x['recommendations'])<=3


def test_dispatcher_uses_graph_not_phrase_lookup(rt):
    seed(rt)
    rt.ms.add_core('draw','en','Draw_Polyline','action capability',origin_ref='origin')
    rt.ms.add_core('boundary','en','Water_Boundary','GIS target',origin_ref='origin')
    rt.ms.add_edge('r_act','river','draw','maps_to_action',origin_ref='origin')
    rt.dispatcher.register_capability('draw','Draw_Polyline','boundary',
                                     'gis.polyline',{'geometry':'polyline'},'admin')
    r=rt.dispatcher.candidates(['water'])
    assert len(r['actions'])==1
    assert r['actions'][0]['action_name']=='Draw_Polyline'
    assert r['actions'][0]['status']=='CANDIDATE_NOT_VERIFIED'
    assert not r['actions'][0]['auto_execute']


def test_signed_ed25519_approval_and_nonce_replay(rt):
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives.serialization import Encoding,PublicFormat
    except ImportError:
        pytest.skip('cryptography missing')
    from datetime import datetime,timezone,timedelta
    from olgm.intent import digest
    private=Ed25519PrivateKey.generate()
    public=private.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw).hex()
    rt.signatures.enroll_public_key('reviewer1',public,'approver','physically_verified_local_admin')
    rt.canti.grant('sandbox_write','sandbox.note','local_cli_operator',60)
    lock=rt.intent.create('owner','external-origin','Write harmless note',task_type='WORK')
    plan=rt.actions.propose(lock['intent_id'],lock['intent_hash'],'sandbox.note','sandbox.note',
                            {'text':'Hello'},'owner','request1')
    receipt={'principal':'reviewer1','plan_id':plan['plan_id'],'intent_id':lock['intent_id'],
             'intent_hash':lock['intent_hash'],'resource':'sandbox.note','scope':'sandbox_write',
             'nonce':str(uuid.uuid4()),'expires_at':(datetime.now(timezone.utc)+timedelta(minutes=5)).isoformat(),
             'approval_ref':'record-123','decision_ref':'review-001'}
    sig=private.sign(digest(receipt).encode()).hex()
    assert rt.signatures.verify(receipt,'00'+sig,expected_plan_id=plan['plan_id'])['status']=='DENIED'
    assert rt.actions.approve(plan['plan_id'],'reviewer1','record-123',
                      signed_receipt=receipt,signature_hex=sig,require_signature=True)['status']=='APPROVED'
    assert rt.signatures.verify(receipt,sig)['reason']=='nonce_replay'
    assert rt.actions.execute(plan['plan_id'])['status']=='EXECUTED_SANDBOX'


def test_signed_approval_required_mode_denies_string_only(rt,monkeypatch):
    monkeypatch.setenv('OLGM_REQUIRE_SIGNED_APPROVAL','1')
    rt.canti.grant('sandbox_write','sandbox.note','local_cli_operator',60)
    lock=rt.intent.create('owner','external-origin','Write harmless note',task_type='WORK')
    plan=rt.actions.propose(lock['intent_id'],lock['intent_hash'],'sandbox.note','sandbox.note',
                            {'text':'Hello'},'owner','request1')
    assert rt.actions.approve(plan['plan_id'],'reviewer1','plain-text-approval')['status']=='DENIED'


def test_all_19_structural_methods_executable(rt):
    seed(rt)
    from olgm.methods import METHODS
    assert len(METHODS)==19
    for tag in ('impact','why','where','how','true','numeric','route','career','clean','observation'):
        outcome=rt.cognitive.run(tag,['water','river'])
        assert all(x['status']=='COMPUTED_GRAPH_OPERATION' for x in outcome['executions'])
    from olgm.methods import select_methods
    assert select_methods('why')[0]==1 and select_methods('why')[-1]==19


def test_graph_benchmark_metrics(tmp_path):
    from olgm.benchmarks import evaluate_retrieval,rank_bm25
    docs=[{'cid':'A','text':'น้ำไหลสู่แม่น้ำ'},{'cid':'B','text':'ถนนและรถยนต์'}]
    f=tmp_path/'semantic_test.jsonl'
    f.write_text(json.dumps({'id':'case1','query':'แม่น้ำ','relevant_cids':['A']},ensure_ascii=False)+'\n',encoding='utf-8')
    result=evaluate_retrieval(f,lambda q,k:rank_bm25(q,docs,k))
    assert result['status']=='EVALUATED'
    assert result['aggregate']['Recall@5']==1
    assert result['blind_evaluation_certified'] is False


def test_model_trainer_blocks_if_deps_missing_or_no_cuda(tmp_path):
    from olgm.training import TrainingPipeline
    x=TrainingPipeline('offline-nonexistent-model',str(tmp_path)).train(str(tmp_path/'none.jsonl'))
    assert x['status']=='BLOCKED'


def test_graph_placement_append_only_stable_neighbors(rt):
    from olgm.placement import GraphPlacement
    p=GraphPlacement(rt.ms)
    first=p.add_new('A','en','A','Meaning A','owner')
    second=p.add_new('B','en','B','Meaning B','owner',near_cids=['A'])
    assert first['coords']!=second['coords']
    assert rt.ms.get_core('A')['semantic_coordinates']==json.dumps(first['coords'],separators=(',',':'))
    with pytest.raises(ValueError,match='relocate'):
        p.propose('A')


def test_canti_has_seven_stage_audit(rt):
    rt.canti.grant('sandbox_write','sandbox.note','developer',60)
    lock=rt.intent.create('a','x','create',task_type='WORK')
    p=rt.actions.propose(lock['intent_id'],lock['intent_hash'],'sandbox.note','sandbox.note',
                         {'text':'hello'},'a','key')
    rt.actions.approve(p['plan_id'],'someone','approval')
    rt.actions.execute(p['plan_id'])
    with sqlite3.connect(rt.ms.db_path) as db:
        rows=db.execute("SELECT payload FROM audit_chain WHERE trace_id=? AND event_type='CANTI_STAGE' ORDER BY seq",
                        (p['plan_id'],)).fetchall()
    names=[json.loads(x[0])['stage'] for x in rows]
    assert names==['TARGET_LOCK','PATH_ANALYSIS','EXECUTE_NO_EXPAND','OBSERVE',
                   'EMPIRICAL_EVAL','REFINE_ONLY_DEVIATIONS','TERMINATE']


def test_all_19_graph_method_handlers(rt):
    seed(rt)
    results=rt.cognitive.run('how',['water','river'],force_ids=list(range(1,20)))
    assert len(results['executions'])==19
    assert all(row['status']=='COMPUTED_GRAPH_OPERATION' for row in results['executions'])


def test_zero_hop_path_never_confers_verification(rt):
    rt.ms.add_core('a','en','A','a',origin_ref='o')
    p=rt.semantic.candidate_paths('a','a')
    assert p['candidate_paths'][0]['status']=='CANDIDATE_PATH'


def test_binary_hash_only_is_not_content_integrity_proof(rt):
    rt.ms.add_evidence('binary','file',b'\x00\x01\x02')
    cid=rt.evidence.add_claim('binary data supports x','UNKNOWN',origin_ref='o')
    # No excerpt for binary source, so no independently checkable claim binding.
    assert rt.evidence.v1_v7(cid)['checks']['V2_content_integrity']['status']=='NOT_TESTED'


def test_research_requires_explicit_consent_and_two_permissions(rt):
    provider=lambda q,n:[{'source_url':'https://example.org/a','title':'example','content':'unverified text'}]
    assert rt.research.search('topic',provider)['status']=='DENIED'
    assert rt.research.search('topic',provider,True)['status']=='DENIED'
    rt.canti.grant('read','research.external','developer',60)
    assert rt.research.search('topic',provider,True)['status']=='BLOCKED'
    rt.canti.grant('sandbox_write','evidence','developer',60)
    r=rt.research.search('topic',provider,True)
    assert r['status']=='RETRIEVED_CANDIDATES'
    assert r['verified_fact_count']==0
    assert rt.ms.get_evidence(r['results'][0]['evidence_ref'])


def test_persistent_observer_job_queue_disabled_model(rt):
    rt.canti.grant('reason','agent.ask','developer',60)
    lock=rt.intent.create('a','o','Some unknown topic')
    q=rt.queue.enqueue(lock['intent_id'],lock['intent_hash'])
    assert q['status']=='QUEUED'
    res=rt.queue.step()
    assert res['status']=='BLOCKED'
    assert res['result_status']=='BLOCKED_MODEL'
    assert rt.queue.step()['status']=='IDLE'


def test_queue_stale_intent_cannot_run(rt):
    rt.canti.grant('reason','agent.ask','developer',60)
    lock=rt.intent.create('a','o','First statement')
    assert rt.queue.enqueue(lock['intent_id'],lock['intent_hash'])['status']=='QUEUED'
    rt.intent.revise(lock['intent_id'],'New statement',reason='update',
                     expected_hash=lock['intent_hash'],actor='a')
    assert rt.queue.step()['result_status']=='ROOT_REENTRY'


def test_http_process_local_token_and_checkpoints(tmp_path):
    """Real loopback HTTP request/response, not a mocked handler."""
    import socket
    import subprocess
    import sys
    import time
    import requests
    root=os.path.dirname(os.path.dirname(__file__))
    db=str(tmp_path/'api.db')
    env={**os.environ,'OLGM_DB':db,'OLGM_HTTP_TOKEN':'example-dev-token'}
    subprocess.run([sys.executable,'runtime.py','grant-dev','reason','agent.ask'],
                   cwd=root,env=env,stdout=subprocess.PIPE,check=True)
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    process=subprocess.Popen([sys.executable,'runtime.py','serve','--port',str(port)],
                             cwd=root,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    url=f'http://127.0.0.1:{port}'
    try:
        for i in range(100):
            try:
                if requests.get(url+'/health',timeout=.2).status_code==200:break
            except requests.RequestException:time.sleep(.05)
        else:pytest.fail('loopback API did not start')
        body={'q':'1+2','intent':'numeric'}
        unauthorized=requests.post(url+'/api/process',json=body,timeout=5)
        assert unauthorized.status_code==401
        valid=requests.post(url+'/api/process',json=body,
                    headers={'X-OLGM-Token':'example-dev-token'},timeout=5)
        assert valid.status_code==200
        data=valid.json()
        assert data['answer']=='3' and len(data['checkpoints'])==16
    finally:
        process.terminate()
        try:process.wait(timeout=3)
        except subprocess.TimeoutExpired:process.kill();process.wait(timeout=3)


def test_graph_only_answer_is_candidate_not_fact(rt):
    seed(rt)
    rt.canti.grant('reason','agent.ask','developer',60)
    out=rt.process('น้ำไหลลงแม่น้ำ',intent_tag='why',seed_cids=['water'],goal_cid='river')
    assert out['status']=='CANDIDATE'
    assert '--flows_to-->' in out['answer']
    assert out['proof_type']=='GRAPH_DERIVED_CANDIDATE_NOT_INDEPENDENTLY_VERIFIED'
    assert out['quality_proof']['status']=='PENDING'
