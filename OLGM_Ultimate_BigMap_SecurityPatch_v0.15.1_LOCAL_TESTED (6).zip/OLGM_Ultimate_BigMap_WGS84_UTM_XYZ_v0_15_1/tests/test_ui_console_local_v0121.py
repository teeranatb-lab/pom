"""Local control console integration tests; do not assert connector access or production readiness."""
import concurrent.futures
import json
import threading
from http.server import ThreadingHTTPServer
import pytest
import requests
from runtime import build_runtime
from olgm.ui.service import ConsoleService, MODULE_BY_KEY
from olgm.ui.settings import SettingsStore
from console import create_handler, serve_local

TOKEN='test_operator_token_'+'g'*40
ADMIN='test_admin_token_'+'p'*40

@pytest.fixture
def ui(tmp_path,monkeypatch):
    monkeypatch.setenv('OLGM_DB',str(tmp_path/'local.db'))
    monkeypatch.setenv('OLGM_MODEL_PROVIDER','disabled')
    rt=build_runtime()
    s=ConsoleService(rt.ms.db_path,rt)
    http=ThreadingHTTPServer(('127.0.0.1',0),Base)
    http.RequestHandlerClass=create_handler(s,TOKEN,http.server_port,ADMIN)
    t=threading.Thread(target=http.serve_forever,daemon=True)
    t.start()
    yield 'http://127.0.0.1:'+str(http.server_port),s
    http.shutdown();http.server_close();t.join(3)

class Base:
    def __init__(self,*a,**kw):
        raise AssertionError('dummy handler should never be called')

def login(url,token=TOKEN):
    c=requests.Session()
    r=c.post(url+'/api/ui/login',headers={'X-OLGM-UI':'local-console'},json={'token':token})
    return c,r

def post(c,url,path,data):
    return c.post(url+'/api/ui/'+path,headers={'X-OLGM-UI':'local-console'},json=data)

def test_unauthenticated_private_endpoints_denied(ui):
    url,s=ui
    assert requests.get(url+'/api/ui/bootstrap').status_code==401
    assert requests.get(url+'/api/ui/overview').status_code==401
    assert requests.get(url+'/health').json()['production_certified'] is False
    assert requests.get(url+'/').status_code==200

def test_login_requires_long_correct_token(ui):
    url,s=ui
    assert login(url,'wrong')[1].status_code==401
    c,r=login(url)
    assert r.status_code==200
    assert r.json()['origin_authority'] is False
    assert 'HttpOnly' in r.headers['Set-Cookie']
    assert c.get(url+'/api/ui/bootstrap').json()['mode']=='LOCAL_ONLY'

def test_csrf_and_origin_barrier(ui):
    url,s=ui
    c,r=login(url)
    assert c.post(url+'/api/ui/settings/change',json={}).status_code==403
    assert c.post(url+'/api/ui/settings/change',headers={'X-OLGM-UI':'local-console','Origin':'https://attacker.tld'},json={}).status_code==403

def test_no_auto_grant_origin_authority(ui):
    url,s=ui
    c,r=login(url,ADMIN)
    assert r.json()['role']=='admin'
    assert r.json()['origin_authority'] is False
    r=post(c,url,'settings/change',{'scope':'user','scope_id':'local_console','key':'security.core0_no_api','value':False,'reason':'try','expected_revision':0})
    assert r.status_code==403

def test_all_25_module_views_load_without_fake_connections(ui):
    url,s=ui
    c,r=login(url)
    b=c.get(url+'/api/ui/bootstrap').json()
    assert len(b['modules'])>=25
    for m in b['modules']:
        r=c.get(url+'/api/ui/module/'+m['key'])
        assert r.status_code==200,(m['key'],r.text)
    assert c.get(url+'/api/ui/module/computers').json()['connection']=='NOT_CONNECTED'
    assert c.get(url+'/api/ui/module/spaces').json()['connection']=='NOT_CONNECTED'
    assert c.get(url+'/api/ui/module/s10').json()['connection']=='NOT_PASSED'

def test_thai_code_and_intent_workflows(ui):
    url,s=ui
    c,r=login(url)
    r=post(c,url,'thai-answer',{'question':'หนึ่ง บวก สอง'})
    assert r.status_code==200
    assert r.json()['math']['result']=='3'
    r=post(c,url,'code',{'request':'สร้างฟังก์ชันหาผลรวม'})
    assert r.status_code==200
    assert 'def process' in r.json()['code']
    r=post(c,url,'intent',{'statement':'ตั้งเป้าหมายใหม่ในระบบ','task_type':'CHAT'})
    assert r.status_code==200
    assert r.json()['status']=='LOCKED'

def test_settings_inherit_reset_and_rollback_are_real(ui):
    url,s=ui
    c,r=login(url,ADMIN)
    def change(scope,scope_id,value,expected):
        return post(c,url,'settings/change',{'scope':scope,'scope_id':scope_id,'key':'appearance.theme','value':value,'reason':'regression_test','expected_revision':expected})
    w=change('workspace','default','light',0).json()
    assert w['status']=='APPLIED'
    u=change('user','local_console','dark',0).json()
    assert u['status']=='APPLIED'
    result=c.get(url+'/api/ui/settings').json()
    assert result['effective']['appearance.theme']['value']=='dark'
    reset=post(c,url,'settings/reset',{'scope':'user','scope_id':'local_console','key':'appearance.theme','reason':'regression_test','expected_revision':u['seq']})
    assert reset.status_code==200
    result=c.get(url+'/api/ui/settings').json()
    assert result['effective']['appearance.theme']['value']=='light'  # inherit workspace not hardcoded dark
    s1=change('user','local_console','dark',reset.json()['seq']).json()
    s2=change('user','local_console','light',s1['seq']).json()
    rollback=post(c,url,'settings/rollback',{'seq':s2['seq'],'reason':'rollback_to_previous','expected_revision':s2['seq']})
    assert rollback.status_code==200
    assert c.get(url+'/api/ui/settings').json()['effective']['appearance.theme']['value']=='dark'
    assert s.settings.verify()['status']=='PASS'

def test_control_registration_requires_admin_but_stays_unconnected(ui):
    url,s=ui
    details={'resource_id':'test-xadmin','kind':'computer','display_name':'Test X Admin','provider':'local','source_ref':'test-fixture',
             'actions':['computer.status'],'connection_state':'CONNECTED'}
    c,_=login(url)
    assert post(c,url,'resource',details).status_code==403
    c,_=login(url,ADMIN)
    assert post(c,url,'resource',details).status_code==403
    details['connection_state']='NOT_CONNECTED'
    r=post(c,url,'resource',details)
    assert r.status_code==200
    assert c.get(url+'/api/ui/module/computers').json()['connection']=='NOT_CONNECTED'

def test_operator_cannot_change_workspace_scope(ui):
    url,s=ui
    c,_=login(url)
    r=post(c,url,'settings/change',{'scope':'workspace','scope_id':'default','key':'appearance.theme','value':'light','reason':'no_access','expected_revision':0})
    assert r.status_code==403

def test_loopback_bind_required(tmp_path,monkeypatch):
    monkeypatch.setenv('OLGM_DB',str(tmp_path/'a.db'))
    with pytest.raises(ValueError):serve_local(host='0.0.0.0',port=9001,token=TOKEN)

def test_gis_conversion_local_not_field_certified(ui):
    pytest.importorskip('pyproj')
    url,s=ui
    c,_=login(url)
    r=post(c,url,'gis-point',{'lat':16.199682,'lon':103.197839})
    assert r.status_code==200
    result=r.json()
    assert result['horizontal_crs']=='EPSG:32648'
    assert result['survey_accuracy']=='NOT_CERTIFIED'
    assert 100000 < result['X'] < 900000

def test_production_rejects_dev_ui(tmp_path,monkeypatch):
    monkeypatch.setenv('OLGM_DB',str(tmp_path/'a.db'))
    monkeypatch.setenv('OLGM_ENV','production')
    with pytest.raises(PermissionError,match='cannot serve production'):
        serve_local(port=18979,token=TOKEN)

def test_role_scope_admin_may_set_but_operator_may_not(ui):
    url,s=ui
    c,_=login(url,ADMIN)
    r=post(c,url,'settings/change',{'scope':'role','scope_id':'viewer','key':'language.answer',
                                  'value':'en','reason':'test_role_inheritance','expected_revision':0})
    assert r.status_code==200
    result=c.get(url+'/api/ui/settings?scope=role&scope_id=viewer').json()
    assert result['overrides']['language.answer']['value']=='en'
    c,_=login(url)
    assert c.get(url+'/api/ui/settings?scope=role&scope_id=viewer').json()['scope']=='user'


def test_s10_hashes_console_and_frontend():
    from olgm.s10 import source_manifest
    from pathlib import Path
    m=source_manifest(Path(__file__).resolve().parents[1])
    assert all(p in m for p in ('console.py','web/app.js','web/styles.css','web/index.html','olgm/ui/settings.py'))


def test_bigmap_wgs84_utm_xyz_http_and_reverse(ui):
    url,service=ui
    c,_=login(url)
    result=post(c,url,'bigmap/add',{
        'label':'GPS buoy with ellipsoidal elevation',
        'geometry':{'type':'Point','coordinates':[103.197839,16.199682,25.5]},
        'vertical_crs':'EPSG:4979',
        'origin_ref':'test:source','source_ref':'fixture:ground_reference'})
    assert result.status_code==200,result.text
    feature=result.json()['feature']
    assert feature['utm']['horizontal_crs']=='EPSG:32648'
    assert feature['utm']['vertical_crs']=='EPSG:4979'
    assert feature['utm']['coordinates'][2]==25.5
    assert feature['utm']['derived_from_geometry_hash']==feature['geometry_hash']
    all_features=c.get(url+'/api/ui/bigmap/features').json()['features']
    assert len(all_features)==1
    assert all_features[0]['feature_id']==feature['feature_id']
    x,y=feature['utm']['coordinates'][:2]
    reverse=post(c,url,'gis-utm-inverse',{'X':x,'Y':y,'utm_zone':48,'hemisphere':'N','Z':25.5,'vertical_crs':'EPSG:4979'})
    assert reverse.status_code==200,reverse.text
    assert abs(reverse.json()['lat']-16.199682)<1e-9
    assert abs(reverse.json()['lon']-103.197839)<1e-9


def test_bigmap_http_rejects_unreferenced_z_and_zone_refusal(ui):
    url,service=ui
    c,_=login(url)
    r=post(c,url,'bigmap/add',{'label':'unqualified','geometry':{'type':'Point','coordinates':[103.1,16.1,99]},
                                 'origin_ref':'o'})
    assert r.status_code==400
    assert c.get(url+'/api/ui/bigmap/features').json()['features']==[]
    r=post(c,url,'gis-point',{'lat':16.199682,'lon':103.197839})
    assert r.status_code==200 and r.json()['horizontal_crs']=='EPSG:32648'
    assert r.json()['Z'] is None
