"""Full real apply/rollback runs on an isolated SOURCE COPY only."""
import json,os,shutil
from pathlib import Path
import pytest
from olgm.audit import AuditChain
from olgm.canti import CANTI
from olgm.identity import SignedAuthorizations
from olgm.improve import SourceImprover,approval_message
from olgm.proposals import current_mapping

pytestmark=pytest.mark.skipif(os.environ.get('OLGM_G06_SANDBOX_TEST')=='1',
                            reason='Prevent recursive source mutation test inside regression workspace')


def isolated_repo(tmp_path):
    root=Path(__file__).resolve().parents[1]
    dst=tmp_path/'repo'
    shutil.copytree(root,dst,ignore=shutil.ignore_patterns('.pytest_cache','__pycache__','*.pyc',
                '*.db','*.sqlite*','*.json','*.log','.g06_backups','*.zip'))
    return dst


def new_approver(tmp_path,repo):
    cryptography=pytest.importorskip('cryptography')
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization
    db=str(tmp_path/'app.db');a=AuditChain(db);c=CANTI(db)
    auth=SignedAuthorizations(db)
    private=Ed25519PrivateKey.generate()
    pub=private.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw).hex()
    auth.enroll_public_key('local-origin-signing-key',pub,'Origin','verified_local_test_fixture')
    imp=SourceImprover(repo,db,a,c)
    return private,imp,a,c


def test_g06_real_trusted_code_change_approval_rollback(tmp_path):
    repo=isolated_repo(tmp_path)
    private,imp,a,c=new_approver(tmp_path,repo)
    methods=repo/'olgm/methods.py';old=methods.read_bytes()
    result=imp.propose('compare')
    assert result['status']=='AWAITING_SIGNED_APPROVAL',result
    assert result['assessment']['ok']
    receipt=imp.receipt_template(result['proposal_id'],'local-origin-signing-key')
    sig=private.sign(approval_message(receipt)).hex()
    # Signature alone is insufficient without independently assigned CANTI scope.
    with pytest.raises(PermissionError,match='CANTI'):
        imp.apply(result['proposal_id'],receipt,sig)
    assert methods.read_bytes()==old
    assert c.grant('source_apply','repo.olgm.methods','local_operator',ttl=60)['status']=='GRANTED'
    bad=dict(receipt,proposal_id='tampered')
    with pytest.raises(PermissionError,match='receipt_scope_or_patch_mismatch'):
        imp.apply(result['proposal_id'],bad,sig)
    applied=imp.apply(result['proposal_id'],receipt,sig)
    assert applied['status']=='APPLIED',applied
    mapping,_=current_mapping(methods.read_text())
    assert 'compare' in mapping
    assert (repo/'olgm/g06_capabilities.json').exists()
    with pytest.raises(PermissionError,match='proposal_not_approved_ready'):
        imp.apply(result['proposal_id'],receipt,sig)
    rb=imp.receipt_template(result['proposal_id'],'local-origin-signing-key',action='rollback')
    signed=private.sign(approval_message(rb)).hex()
    rolled=imp.rollback(result['proposal_id'],rb,signed)
    assert rolled['status']=='ROLLED_BACK'
    assert methods.read_bytes()==old
    assert not (repo/'olgm/g06_capabilities.json').exists()
    assert a.verify()[0]
    assert imp.status()['proposals'][0]['status']=='ROLLED_BACK'
    with pytest.raises(PermissionError):imp.rollback(result['proposal_id'],rb,signed)


def test_g06_template_refuses_unknown_intent(tmp_path):
    repo=isolated_repo(tmp_path)
    _,imp,_,_=new_approver(tmp_path,repo)
    assert imp.propose('quantum_entangle')['status']=='NO_TEMPLATE_OR_ALREADY_SUPPORTED'
    assert imp.propose(';rm -rf')['status']=='INVALID_INTENT'
