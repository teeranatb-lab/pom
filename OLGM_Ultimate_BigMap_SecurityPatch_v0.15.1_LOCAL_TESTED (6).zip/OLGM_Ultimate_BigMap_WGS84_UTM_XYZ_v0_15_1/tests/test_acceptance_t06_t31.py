import hashlib
import json
import sqlite3
import pytest
from olgm.meaning_space import MeaningSpace
from olgm.audit import AuditChain
from olgm.canti import CANTI
from olgm.otfa import OTFA
from olgm.episodic import EpisodicMemory
from olgm.observer import Observer, ModelBackend, DisabledBackend
from olgm.agent import Agent
from olgm.training import evaluate_jsonl


def ms(tmp_path):
    return MeaningSpace(tmp_path/'m.db')


def seed(space):
    space.add_core('C_WATER','th','น้ำ','water',origin_ref='owner-1')
    space.add_core('C_FLOW','th','ไหล','flow',origin_ref='owner-1')
    space.add_edge('R1','C_WATER','C_FLOW','related_to',origin_ref='owner-1')


def test_schema_creation_and_uniqueness(tmp_path):
    space=ms(tmp_path)
    seed(space)
    with pytest.raises(sqlite3.IntegrityError):
        space.add_core('C_NEW','th','น้ำ','duplicate surface/sense',origin_ref='owner-2')
    with pytest.raises(sqlite3.IntegrityError):
        space.add_core('C_WATER','en','different','collision',origin_ref='owner-1')
    assert space.get_core('C_WATER')['definition']=='water'


def test_meaning_coordinates_3d_unique(tmp_path):
    space=ms(tmp_path)
    space.add_core('A','th','ดาว','star',origin_ref='owner',coords=[0,1,2])
    with pytest.raises(sqlite3.IntegrityError):
        space.add_core('B','th','โลก','earth',origin_ref='owner',coords=(0.0,1,2))
    with pytest.raises(ValueError):
        space.add_core('C','th','จุด','point',origin_ref='owner',coords=[0,1])


def test_revisions_immutable_origin_and_stable_edges(tmp_path):
    space=ms(tmp_path);seed(space)
    space.assign_category('C_WATER','hydrology','first category')
    space.assign_category('C_WATER','natural_resource','new grouping')
    space.assign_category('C_WATER','hydrology','drop prior category','remove')
    assert space.get_categories('C_WATER')==['natural_resource']
    assert space.revise_core('C_WATER',definition='water revised',reason='source corrected')==2
    assert space.get_core('C_WATER')['origin_ref']=='owner-1'
    assert space.get_edge('R1')['source_cid']=='C_WATER'
    with space._conn() as db:
        history=db.execute('SELECT revision,snapshot FROM core_revisions WHERE cid=? ORDER BY revision',('C_WATER',)).fetchall()
    assert [r[0] for r in history]==[1,2]
    assert json.loads(history[0][1])['definition']=='water'


def test_foreign_keys_enforced(tmp_path):
    space=ms(tmp_path)
    with pytest.raises(sqlite3.IntegrityError):
        space.add_edge('BAD','MISSING','OTHER','flows_to',origin_ref='owner')


def test_chain_append_verify_and_tamper(tmp_path):
    audit=AuditChain(tmp_path/'a.db')
    audit.append('t1','ONE',{'x':1})
    audit.append('t1','TWO',{'x':2})
    assert audit.verify()[0]
    with sqlite3.connect(tmp_path/'a.db') as db:
        db.execute("UPDATE audit_chain SET created_at='2000-01-01' WHERE seq=1")
    assert not audit.verify()[0]


def test_chain_anchor_hmac_and_tail_delete(tmp_path):
    audit=AuditChain(tmp_path/'a.db',tmp_path/'separate.jsonl',anchor_key='external-secret')
    audit.append('t1','ONE',{'x':1})
    audit.append('t1','TWO',{'x':2})
    result=audit.anchor('host-b-offsite-ref')
    assert result['status']=='ANCHOR_RECORDED_LOCAL' and result['signed']
    assert audit.verify()[0]
    with sqlite3.connect(tmp_path/'a.db') as db:
        db.execute('PRAGMA foreign_keys=OFF')
        db.execute('DELETE FROM audit_chain WHERE seq=2')
    assert not audit.verify()[0]


def test_anchor_unconfigured_not_fake_external(tmp_path):
    audit=AuditChain(tmp_path/'a.db')
    audit.append('x','EV',{})
    assert audit.anchor('named-ref')['status']=='NOT_ANCHORED'


def test_episodic_pointers_roundtrip_and_evidence(tmp_path):
    space=ms(tmp_path);seed(space)
    ep=EpisodicMemory(space.db_path,space)
    fail=ep.record('tid','goal','C_WATER','C_FLOW',['R1'],'success','missing-doc')
    assert fail['status']=='REJECTED'
    space.add_evidence('E1','user_supplied','document bytes')
    record=ep.record('tid','goal','C_WATER','C_FLOW',['R1'],'success','E1')
    assert record['status']=='RECORDED'
    loaded=ep.rehydrate(record['episode_id'])
    assert loaded['status']=='REHYDRATED' and loaded['relations'][0]['edge_id']=='R1'
    assert ep.record('tid','goal','C_WATER','C_FLOW',['MISSING'],'failure')['status']=='REJECTED'


def test_canti_default_deny_grant_revoke(tmp_path):
    gate=CANTI(tmp_path/'a.db')
    assert not gate.check('reason','agent.ask')['allowed']
    assert gate.grant('bad_scope','x','owner')['status']=='REJECTED'
    grant=gate.grant('reason','agent.ask','local_admin',ttl=60)
    assert gate.check('reason','agent.ask')['allowed']
    gate.revoke(grant['grant_id'])
    assert not gate.check('reason','agent.ask')['allowed']


def test_otfa_registered_reference_is_not_verified_fact(tmp_path):
    space=ms(tmp_path)
    space.add_evidence('EV1','file','a proof candidate')
    result=OTFA(space).verify({'text':'Earth is flat','evidence_refs':['EV1']})
    assert result['overall']=='NOT_TESTED'
    assert result['planes']['empirical']['status']=='NOT_TESTED'
    assert OTFA(space).verify({'text':'unsupported'})['overall']=='INSUFFICIENT'


class FakeBackend(ModelBackend):
    def __init__(self,response):self.response=response
    def complete(self,system,user):return self.response
    @property
    def name(self):return 'mock/not-live'


def sample_observation():
    return {'meaning_cores':[
                {'proposed_surface':'น้ำ','language':'th','definition':'liquid','role':'source'},
                {'proposed_surface':'แม่น้ำ','language':'th','definition':'river','role':'target'}],
            'relation':{'source':'น้ำ','target':'แม่น้ำ','type':'flows_to',
                        'direction':'forward','confidence':0.55,'evidence_ref':None},
            'composite':{'definition':'possibly flows'},
            'provenance':{'rationale':'mock','unknowns':['no actual observations']}}


def test_observer_mock_schema_validation_not_live(tmp_path):
    space=ms(tmp_path);audit=AuditChain(space.db_path)
    model=FakeBackend(json.dumps(sample_observation(),ensure_ascii=False))
    obs=Observer(space,model,audit).observe('t','observed','river')
    assert obs['status']=='CANDIDATE_OBSERVATION'
    assert obs['backend']=='mock/not-live'
    assert audit.verify()[0]
    invalid=sample_observation(); invalid['relation']['confidence']=1.5
    fail=Observer(space,FakeBackend(json.dumps(invalid)),audit).observe('t2','observed','river')
    assert fail['status']=='INSUFFICIENT' and fail['reason']=='invalid_confidence'


def test_observer_disabled_is_blocked_without_model(tmp_path):
    space=ms(tmp_path);audit=AuditChain(space.db_path)
    obs=Observer(space,DisabledBackend(),audit).observe('t','question','x')
    assert obs['status']=='INSUFFICIENT' and obs['reason']=='model_unavailable'


def test_agent_grant_required_numeric_arithmetic(tmp_path):
    space=ms(tmp_path);audit=AuditChain(space.db_path);gate=CANTI(space.db_path)
    agent=Agent(space,DisabledBackend(),audit,gate,OTFA(space))
    assert agent.ask('1+2','numeric')['status']=='DENIED'
    gate.grant('reason','agent.ask','local_admin',60)
    response=agent.ask('1+2','numeric')
    assert response['answer']=='3' and response['status']=='DETERMINISTIC_RESULT'
    assert agent.ask('__import__("os")','numeric')['status']=='INSUFFICIENT'
    assert agent.ask('2**1000000','numeric')['status']=='INSUFFICIENT'


def test_agent_mock_not_real_verification(tmp_path):
    space=ms(tmp_path);audit=AuditChain(space.db_path);gate=CANTI(space.db_path)
    gate.grant('reason','agent.ask','owner',60)
    agent=Agent(space,FakeBackend(json.dumps(sample_observation(),ensure_ascii=False)),
                audit,gate,OTFA(space))
    ans=agent.ask('น้ำไหลลงแม่น้ำ','impact')
    assert ans['status']=='CANDIDATE'
    assert ans['otfa']['overall']=='INSUFFICIENT'
    assert 'methods_planned' in ans and 'methods_used' not in ans


def test_benchmark_real_loop_using_mock_predictor(tmp_path):
    file=tmp_path/'eval.jsonl'
    file.write_text('{"input":"1+2","expected":"3"}\n{"input":"2+2","expected":"4"}\n',encoding='utf8')
    outcome=evaluate_jsonl(str(file),lambda x:{'1+2':'3','2+2':'4'}[x])
    assert outcome['status']=='EVALUATED' and outcome['accuracy']==1.0
    assert outcome['items']==2
    assert outcome['eval_sha256']==hashlib.sha256(file.read_bytes()).hexdigest()


@pytest.mark.skip(reason='T06 live requires configured model, model-side evidence and runtime invocation')
def test_T06_live_observer_NOT_TESTED():
    pass


@pytest.mark.skip(reason='T17 weight training requires real before/after checkpoints and independent eval')
def test_T17_real_learning_NOT_TESTED():
    pass
