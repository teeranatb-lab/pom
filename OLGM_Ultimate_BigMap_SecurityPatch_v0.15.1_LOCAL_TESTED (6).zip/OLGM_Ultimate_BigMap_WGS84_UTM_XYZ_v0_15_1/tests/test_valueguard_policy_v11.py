"""No network or real user data. All identities and keys are synthetic."""
import hashlib, json
from datetime import datetime, timedelta, timezone
import pytest
from olgm.audit import AuditChain
from olgm.meaning_space import MeaningSpace
from olgm.identity import SignedAuthorizations
from olgm.valueguard import ValueGuard, OWNER_EMAIL, THRESHOLD_THB
from olgm.valueguard.policy import estimate_value, _hash

ANSWER='a'*64

class FakeSender:
    def __init__(self,fail=False):self.sent=[];self.fail=fail
    def send(self,to,subject,body):
        if self.fail:raise RuntimeError('fake_failure')
        self.sent.append({'to':to,'subject':subject,'body':body})

@pytest.fixture
def vg(tmp_path):
    db=str(tmp_path/'olgm.db')
    audit=AuditChain(db)
    MeaningSpace(db).add_evidence('forecast-doc-001','document', 'Synthetic estimate evidence for tests',license='synthetic')
    return ValueGuard(db,audit),audit

def _payload(**kw):
    base={'subject_id':'external-001','answer_hash':ANSWER,
        'public_safe_summary':'วิเคราะห์การลดต้นทุนขนส่ง (เฉพาะหัวข้อที่เปิดเผยได้)',
        'estimate_inputs':{'incremental_net_profit_thb':1500000,
            'verified_cost_savings_thb':0,'implementation_cost_thb':0,
            'ongoing_cost_thb':0,'success_probability':0.8},
        'evidence_refs':['forecast-doc-001']}
    base.update(kw);return base

def test_address_correct_and_strictly_above_one_million(vg):
    g,_=vg
    assert OWNER_EMAIL=='teeranat.b@gmail.com'
    assert str(THRESHOLD_THB)=='1000000'
    one=_payload(estimate_inputs={**_payload()['estimate_inputs'],
        'incremental_net_profit_thb':1000000,'success_probability':1})
    assert g.evaluate(**one)['status']=='BELOW_THRESHOLD'
    more=_payload(estimate_inputs={**one['estimate_inputs'],'incremental_net_profit_thb':1000000.01})
    assert g.evaluate(**more)['status']=='OWNER_ALERT_QUEUED'

def test_owner_first_and_user_in_app(vg):
    g,a=vg
    queued=g.evaluate(**_payload())
    cid=queued['case_id']
    assert queued['estimated_thb']=='1200000.00'
    assert g.user_notice(cid,'external-001')['status']=='WAIT_OWNER_DELIVERY'
    fake=FakeSender()
    assert g.dispatch_next(fake,allowed=False)['status']=='DENIED'
    assert not fake.sent
    sent=g.dispatch_next(fake,allowed=True)
    assert sent['status']=='EMAIL_SENT' and sent['recipient_role']=='OWNER'
    assert fake.sent[0]['to']==OWNER_EMAIL
    assert g.user_notice(cid,'external-001')['status']=='AVAILABLE'
    assert g.user_notice(cid,'someone-else')['status']=='DENIED'
    assert g.dispatch_next(fake,allowed=True)['status']=='NO_QUEUED_EMAIL'
    assert a.verify()[0]

def test_owner_first_and_user_email_only_if_consented(vg):
    g,_=vg
    resp=g.evaluate(**_payload(user_email='customer@example.org',consent_user_email=True,
                              display_name='Test Person',coarse_location='Ubon Ratchathani',
                              consent_share_identity=True))
    fake=FakeSender()
    g.dispatch_next(fake,allowed=True)
    g.dispatch_next(fake,allowed=True)
    assert [m['to'] for m in fake.sent]==[OWNER_EMAIL,'customer@example.org']
    assert 'Test Person' in fake.sent[0]['body']
    assert 'Ubon Ratchathani' in fake.sent[0]['body']
    assert 'Case: '+resp['case_id'] in fake.sent[1]['body']
    assert 'ยังไม่ใช่' in fake.sent[1]['body']

def test_non_consented_identity_not_stored(vg):
    g,_=vg
    res=g.evaluate(**_payload(display_name='sensitive name',coarse_location='secret location'))
    f=FakeSender();g.dispatch_next(f,allowed=True)
    assert 'sensitive name' not in f.sent[0]['body']
    assert 'secret location' not in f.sent[0]['body']
    import sqlite3
    with sqlite3.connect(g.db_path) as db:
        assert db.execute('SELECT identity_display,location_display FROM value_cases').fetchone()==(None,None)

def test_fail_closed_on_smtp_error_and_no_user_notice(vg):
    g,_=vg
    cid=g.evaluate(**_payload())['case_id']
    failure=g.dispatch_next(FakeSender(fail=True),allowed=True)
    assert failure['status']=='DELIVERY_UNCERTAIN'
    assert g.user_notice(cid,'external-001')['status']=='WAIT_OWNER_DELIVERY'
    assert g.dispatch_next(FakeSender(),allowed=True)['status']=='NO_QUEUED_EMAIL'

def test_email_user_needs_consent(vg):
    g,_=vg
    with pytest.raises(ValueError,match='explicit_consent'):
        g.evaluate(**_payload(user_email='someone@example.org'))
    assert g.pending()['pending_summary']==[]

def test_exemption_cannot_be_self_claimed(vg):
    g,_=vg
    assert g._role('claim:family')=='external_or_unverified'
    assert g.register_exemption('claim:family','family','ref',{'principal':'self'},'00')['status']=='DENIED'


def test_exemption_requires_origin_signature(vg):
    g,_=vg
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding,PublicFormat
    priv=Ed25519PrivateKey.generate()
    pub=priv.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw).hex()
    SignedAuthorizations(g.db_path).enroll_public_key('synthetic-origin',pub,'Origin','offline-test-enrollment')
    subject='family-member-001'
    receipt={'subject_digest':g._subject_digest(subject),'role':'family','evidence_ref':'private-family-proof',
             'principal':'synthetic-origin','nonce':'nonce-123',
             'expires_at':(datetime.now(timezone.utc)+timedelta(hours=2)).isoformat()}
    sig=priv.sign(_hash(receipt).encode('ascii')).hex()
    assert g.register_exemption(subject,'family','private-family-proof',receipt,'00')['status']=='DENIED'
    assert g.register_exemption(subject,'family','private-family-proof',receipt,sig)['status']=='EXEMPTION_ATTESTED'
    assert g.evaluate(**_payload(subject_id=subject))['status']=='EXEMPT'
    assert g.register_exemption(subject,'family','private-family-proof',receipt,sig)['status']=='DENIED'
    assert g.evaluate(**_payload(subject_id='random-user'))['status']=='OWNER_ALERT_QUEUED'


def test_unknown_financial_proof_not_evaluated(vg):
    g,_=vg
    assert g.evaluate(**_payload(evidence_refs=[]))['status']=='NEEDS_EVIDENCE'
    assert g.evaluate(**_payload(evidence_exists=lambda r:False))['status']=='NEEDS_EVIDENCE'
    assert g.pending()['pending_summary']==[]


def test_invalid_inputs_rejected(vg):
    g,_=vg
    for p in [-1,1.001,'NaN','Infinity']:
        with pytest.raises(ValueError):
            g.evaluate(**_payload(estimate_inputs={**_payload()['estimate_inputs'],'success_probability':p}))
    with pytest.raises(ValueError):
        g.evaluate(**_payload(answer_hash='not hash'))
    with pytest.raises(ValueError):
        g.evaluate(**_payload(public_safe_summary=''))


def test_idempotent_no_duplicate_owner_alert(vg):
    g,_=vg
    a=g.evaluate(**_payload()); b=g.evaluate(**_payload())
    assert a['case_id']==b['case_id'] and b['status']=='ALREADY_QUEUED'
    assert sum(x['n'] for x in g.pending()['pending_summary'])==2


def test_owner_notified_no_claim_legal_entitlement(vg):
    g,_=vg
    g.evaluate(**_payload())
    f=FakeSender();g.dispatch_next(f,allowed=True)
    assert 'ยังไม่ใช่การรับรอง' in f.sent[0]['body']
    assert 'จ่ายเงิน' not in f.sent[0]['body']


def test_all_audit_metadata_redacted(vg):
    g,_=vg
    g.evaluate(**_payload(display_name='Secret Name',coarse_location='Secret Village',
        user_email='private@example.org',consent_share_identity=True,consent_user_email=True))
    import sqlite3
    with sqlite3.connect(g.db_path) as db:
        events=db.execute("SELECT payload FROM audit_chain").fetchall()
    blob=''.join(e[0] for e in events)
    for secret in ['Secret Name','Secret Village','private@example.org']:
        assert secret not in blob


def test_s10_value_alert_gate_not_silently_passed(vg):
    from olgm.s10 import RELEASE_GATES
    gate_ids=[x[0] for x in RELEASE_GATES]
    assert 'S10-21' in gate_ids
    assert len(gate_ids)==len(set(gate_ids))
