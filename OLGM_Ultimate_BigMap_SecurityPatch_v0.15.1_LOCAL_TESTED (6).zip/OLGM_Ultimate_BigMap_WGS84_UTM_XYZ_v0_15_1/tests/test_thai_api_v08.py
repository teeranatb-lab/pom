"""Loopback-only HTTP smoke: Thai answers require explicit bearer-like dev token."""
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request


def _post(url,token=None):
    headers={'Content-Type':'application/json'}
    if token is not None:headers['X-OLGM-Token']=token
    req=urllib.request.Request(url,data=json.dumps({'q':'หนึ่ง บวก สอง'}).encode(),
                               headers=headers,method='POST')
    try:
        with urllib.request.urlopen(req,timeout=2) as response:
            return response.status,json.load(response)
    except urllib.error.HTTPError as err:
        return err.code,json.load(err)


def test_thai_api_requires_token(tmp_path):
    root=Path(__file__).resolve().parents[1]
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    env={**os.environ,'OLGM_DB':str(tmp_path/'api.db'),'OLGM_MODEL_PROVIDER':'disabled',
         'OLGM_HTTP_TOKEN':'test-only-secret-do-not-use'}
    proc=subprocess.Popen([sys.executable,str(root/'runtime.py'),'serve','--host','127.0.0.1','--port',str(port)],
                          cwd=tmp_path,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        url=f'http://127.0.0.1:{port}/api/thai/answer'
        for _ in range(60):
            if proc.poll() is not None:raise AssertionError('server_exited')
            try:
                status,_=_post(url,token='wrong')
                if status==401:break
            except (OSError,TimeoutError):time.sleep(.05)
        else:raise AssertionError('server_not_ready')
        status,bad=_post(url)
        assert status==401 and bad['status']=='DENIED'
        status,ok=_post(url,token='test-only-secret-do-not-use')
        assert status==200 and ok['answer_th'].endswith('3')
        assert not ok['network_called'] # internal Thai module made no outside network calls
    finally:
        proc.terminate()
        try:proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill();proc.wait(timeout=5)
