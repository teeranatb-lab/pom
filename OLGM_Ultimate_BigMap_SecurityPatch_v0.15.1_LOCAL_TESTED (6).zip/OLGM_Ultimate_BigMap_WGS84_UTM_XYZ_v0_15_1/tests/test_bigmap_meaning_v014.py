import csv
import json
import sqlite3
from pathlib import Path

import pytest

from olgm.audit import AuditChain
from olgm.bigmap import (BigMapMeaning, haversine_m, geometry_metrics,
                         validate_geometry)
from olgm.meaning_space import MeaningSpace
from olgm.production import cli_allowed


@pytest.fixture
def bridge(tmp_path):
    db=tmp_path/'bigmap.db'
    ms=MeaningSpace(db)
    au=AuditChain(db)
    bm=BigMapMeaning(db,meaning_space=ms,audit=au)
    return bm,ms,au


def point(lat=16.199682,lon=103.197839):
    return {'type':'Point','coordinates':[lon,lat]}


def line():
    return {'type':'LineString','coordinates':[[103.197839,16.199682],[103.199069,16.201307]]}


def polygon():
    return {'type':'Polygon','coordinates':[[[103.1,16.1],[103.101,16.1],[103.101,16.101],[103.1,16.101],[103.1,16.1]]]}


def add(bm,geometry=None,label='ทุ่น 1'):
    return bm.add_feature(label, geometry or point(), 'origin:declaration-1','operator','field_observation:2026')


def test_point_geometry_standard_order(bridge):
    bm,ms,_=bridge
    f=add(bm)['feature']
    assert f['geometry']['coordinates']==[103.197839,16.199682]
    assert f['kind']=='Point' and f['revision']==1
    assert f['metrics']['survey_accuracy']=='NOT_CERTIFIED'
    assert f['origin_ref']=='origin:declaration-1'
    assert f['semantic_links']==[]
    assert ms.context_snapshot([])==[]


def test_geometry_units_and_distance():
    assert 100< haversine_m([103,16],[103.001,16])<110
    m=geometry_metrics(line())
    assert 200<m['length_m_approx']<250
    assert geometry_metrics(polygon())['area_m2_approx']>0


@pytest.mark.parametrize('bad',[{'type':'Point','coordinates':[True,16]},
  {'type':'Point','coordinates':[103,float('nan')]},
  {'type':'Point','coordinates':[103,91]},
  {'type':'LineString','coordinates':[[103,16]]},
  {'type':'LineString','coordinates':[[103,16],[103,16]]},
  {'type':'Polygon','coordinates':[[[103,16],[104,16],[104,17]]]},
  {'type':'Polygon','coordinates':[[[103,16],[104,17],[104,16],[103,17],[103,16]]]},
  {'type':'MultiPolygon','coordinates':[]}])
def test_reject_invalid_geometries(bad):
    with pytest.raises(ValueError):validate_geometry(bad)


def test_revision_is_append_only(bridge):
    bm,_,audit=bridge
    f=add(bm)['feature']; fid=f['feature_id']
    old=bm.get_feature(fid)['geometry']
    r=bm.revise_geometry(fid,point(16.3,103.4),1,'GPS correction','operator')
    assert r['feature']['revision']==2
    assert r['feature']['geometry']!=old
    history=bm.history(fid)
    assert history['integrity']['status']=='PASS'
    assert json.loads(history['revisions'][0]['geometry_json'])==old
    assert audit.verify()[0]
    with pytest.raises(ValueError,match='revision_conflict'):
        bm.revise_geometry(fid,point(),1,'stale write','operator')


def test_cannot_change_feature_type(bridge):
    bm,_,_=bridge
    fid=add(bm)['feature']['feature_id']
    with pytest.raises(ValueError,match='geometry_type_change'):
        bm.revise_geometry(fid,line(),1,'wrong kind','operator')


def test_tamper_is_detected(bridge):
    bm,_,_=bridge
    fid=add(bm)['feature']['feature_id']
    with sqlite3.connect(bm.db_path) as db:
        db.execute('UPDATE bigmap_feature_revisions SET geometry_json=? WHERE feature_id=?',
                   (json.dumps(point(17,105)),fid))
    assert bm.verify_history(fid)['status']=='FAIL'


def test_reject_orphan_cid_and_origin_claim_only(bridge):
    bm,ms,audit=bridge
    fid=add(bm)['feature']['feature_id']
    with pytest.raises(KeyError):bm.link_to_meaning(fid,'NO_CORE','represents','origin:declaration','operator')
    ms.add_core('CID_BUOY','th','ทุ่นลอย','เครื่องหมายทางน้ำ',origin_ref='origin:canonical-ref')
    link=bm.link_to_meaning(fid,'CID_BUOY','represents','origin:declaration','operator')
    assert link['status']=='CANDIDATE'
    assert bm.features_for_cid('CID_BUOY')['features'][0]['feature_id']==fid
    assert ms.get_core('CID_BUOY')['semantic_coordinates'] is None
    assert ms.get_categories('CID_BUOY')==[]
    assert audit.verify()[0]


def test_cid_and_graph_stay_fixed_when_revising_feature(bridge):
    bm,ms,_=bridge
    ms.add_core('C1','th','ทุ่น','floating marker',origin_ref='o')
    ms.add_core('C2','th','แม่น้ำ','river',origin_ref='o')
    ms.add_edge('R1','C1','C2','located_in',origin_ref='o')
    fid=add(bm)['feature']['feature_id']
    bm.link_to_meaning(fid,'C1','located_at','origin-ref','operator')
    before=ms.get_core('C1');edge=ms.get_edge('R1')
    bm.revise_geometry(fid,point(16.25,103.3),1,'correction','operator')
    assert ms.get_core('C1')==before
    assert ms.get_edge('R1')==edge
    assert bm.get_feature(fid)['semantic_links'][0]['cid']=='C1'


def test_evidence_ref_must_exist(bridge):
    bm,ms,_=bridge
    ms.add_core('C','th','ทุ่น','marker',origin_ref='o')
    fid=add(bm)['feature']['feature_id']
    with pytest.raises(ValueError):bm.link_to_meaning(fid,'C','represents','o','operator','bad-evidence')
    ms.add_evidence('E','field_note','a dated note')
    result=bm.link_to_meaning(fid,'C','represents','o','operator','E')
    assert result['status']=='CANDIDATE'


def test_import_csv_export_coordinate_order(bridge,tmp_path):
    bm,_,_=bridge
    path=tmp_path/'input.csv'
    path.write_text('label,lat,lon\nทุ่น 1,16.199682,103.197839\nทุ่น 2,16.199754,103.197670\n',encoding='utf-8')
    result=bm.import_csv(path,'origin-declaration','operator')
    assert result['count']==2
    output=bm.export_csv(only_coords=True)
    assert output.startswith('lat,lon\r\n16.19968200,103.19783900')
    fc=bm.export_geojson()
    assert fc['type']=='FeatureCollection'
    assert fc['features'][0]['geometry']['coordinates']==[103.197839,16.199682]
    assert fc['features'][0]['properties']['survey_accuracy']=='NOT_CERTIFIED'


def test_import_csv_is_all_or_nothing(bridge,tmp_path):
    bm,_,_=bridge
    p=tmp_path/'bad.csv';p.write_text('lat,lon\n16.1,103.2\n999,103.1\n',encoding='utf-8')
    with pytest.raises(ValueError,match='csv_line_3'):bm.import_csv(p,'origin','operator')
    assert bm.list_features()['features']==[]


def test_import_geojson_polygon(bridge,tmp_path):
    bm,_,_=bridge
    path=tmp_path/'input.geojson'
    path.write_text(json.dumps({'type':'FeatureCollection','features':[{'type':'Feature','geometry':polygon(), 'properties':{'label':'เขตพื้นที่'}}]}))
    res=bm.import_geojson(path,'origin','operator')
    assert res['count']==1
    assert bm.list_features()['features'][0]['kind']=='Polygon'


def test_nearby_does_not_assert_semantics(bridge):
    bm,_,_=bridge
    add(bm)
    add(bm,point(17.2,104.2),'far')
    r=bm.nearby(16.199682,103.197839,100)
    assert len(r['matches'])==1
    assert r['not_a_semantic_fact'] is True
    assert r['distance_method']=='nearest_vertex_haversine'


def test_production_commands_fail_closed():
    for cmd in ('bigmap-add-point','bigmap-features','bigmap-export','bigmap-link','bigmap-import','bigmap-verify'):
        assert not cli_allowed(cmd,{'OLGM_ENV':'production'}),cmd
        assert cli_allowed(cmd,{'OLGM_ENV':'development'})
