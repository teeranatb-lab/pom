"""Independent local acceptance checks: WGS84 UTM dual coords and audited failures.

No production, GPS elevation or surveyed control-point certificate is implied.
"""
import csv
import io
import json
import sqlite3
import pytest
from olgm.utm_wgs84 import to_utm,from_utm,utm_zone,utm_epsg,project_geometry
from olgm.bigmap import BigMapMeaning
from olgm.meaning_space import MeaningSpace
from olgm.audit import AuditChain
from olgm.canti import CANTI
from olgm.agent import Agent
from olgm.otfa import OTFA
from olgm.observer import ModelBackend,DisabledBackend,Observer
from olgm.production import cli_allowed


@pytest.fixture
def setup(tmp_path):
    db=tmp_path/'map.db'; ms=MeaningSpace(db); audit=AuditChain(db)
    return BigMapMeaning(db,ms,audit),ms,audit


def test_utm48_from_buoy_with_independent_reference():
    r=to_utm(16.199682,103.197839)
    assert r['horizontal_crs']=='EPSG:32648'
    assert r['utm_zone']==48 and r['hemisphere']=='N'
    assert abs(r['X']-307349.6193)<.01 and abs(r['Y']-1791868.7574)<.01
    assert r['Z'] is None and r['z_status']=='NOT_PROVIDED'
    assert not r['height_is_vertical_transformed']


def test_reverse_exact_and_47_48_north_south():
    for lat,lon,zone,epsg in [(16.199682,103.197839,48,'EPSG:32648'),(15.0,101.0,47,'EPSG:32647'),(-12.0,104.0,48,'EPSG:32748')]:
        a=to_utm(lat,lon)
        assert a['utm_zone']==zone and a['horizontal_crs']==epsg
        b=from_utm(a['X'],a['Y'],zone,a['hemisphere'])
        assert abs(b['lat']-lat)<1e-9 and abs(b['lon']-lon)<1e-9


def test_utm_special_zones_norway_svalbard():
    assert utm_zone(60,5)==32
    assert utm_zone(77,18)==33
    assert utm_zone(77,26)==35
    assert utm_zone(0,180)==60
    assert utm_epsg(48,'S')=='EPSG:32748'


@pytest.mark.parametrize('lat,lon', [(85,103),(-81,103),(0,181),(0,float('nan')),(True,101)])
def test_reject_invalid_utm(lat,lon):
    with pytest.raises(ValueError):to_utm(lat,lon)


def test_no_automatic_zone_override_or_inferred_height():
    with pytest.raises(ValueError,match='utm_zone_outside_area_of_use'):to_utm(16.2,103.2,zone=47)
    with pytest.raises(ValueError,match='height_requires_explicit'):to_utm(16.2,103.2,0)
    # A point interpreted in a different zone can still be mathematically valid;
    # correctness needs provenance of the declared zone. Impossible to infer from X/Y alone.
    with pytest.raises(ValueError):from_utm(307349.619,1791868.75,0,'N')


def test_height_datum_explicit_and_not_transformed(setup):
    bm,ms,_=setup
    geom={'type':'Point','coordinates':[103.197839,16.199682,88.5]}
    with pytest.raises(ValueError,match='height_requires'):bm.add_feature('ทุ่น',geom,'ref','tester')
    f=bm.add_feature('ทุ่น',geom,'ref','tester',vertical_crs='EPSG:4979')['feature']
    assert f['utm']['vertical_crs']=='EPSG:4979'
    assert f['utm']['coordinates'][2]==88.5
    assert f['utm']['z_status']=='CARRIED_UNCHANGED_NOT_VERTICAL_TRANSFORMED'
    assert bm.verify_history(f['feature_id'])['status']=='PASS'
    with pytest.raises(ValueError):bm.revise_geometry(f['feature_id'],geom,1,'wrong_height_datum','tester')


def test_backward_compatible_schema_auto_migration_and_revision(setup):
    bm,ms,au=setup
    f=bm.add_feature('จุดเดิม',{'type':'Point','coordinates':[103.2,16.2]},'o','a')['feature']
    fid=f['feature_id'];previous_hash=f['record_hash']
    # Existing DB's vertical metadata need not be rewritten: older records verify unchanged.
    restored=BigMapMeaning(bm.db_path,ms,au)
    assert restored.get_feature(fid)['record_hash']==previous_hash
    revised=restored.revise_geometry(fid,{'type':'Point','coordinates':[103.21,16.21,80]},1,'corrected','a',vertical_crs='EPSG:4979')['feature']
    assert revised['revision']==2 and revised['vertical_crs']=='EPSG:4979'
    assert restored.verify_history(fid)['status']=='PASS'
    assert au.verify()[0]


def test_coordinate_and_meaning_xyz_remain_separate(setup):
    bm,ms,audit=setup
    ms.add_core('CID_B','th','แม่น้ำ','water',coords=[1,2,3],origin_ref='owner')
    ms.add_core('CID_C','th','ชายฝั่ง','boundary',coords=[4,5,6],origin_ref='owner')
    ms.add_edge('EBC','CID_B','CID_C','near',origin_ref='owner')
    geom={'type':'Point','coordinates':[103.197839,16.199682]}
    fid=bm.add_feature('ทุ่น',geom,'owner','test')['feature']['feature_id']
    bm.link_to_meaning(fid,'CID_B','located_at','owner','test')
    core_before=ms.get_core('CID_B');edge_before=ms.get_edge('EBC')
    revised=bm.revise_geometry(fid,{'type':'Point','coordinates':[103.21,16.21]},1,'new fix','test')['feature']
    assert revised['utm']['horizontal_crs']=='EPSG:32648'
    assert ms.get_core('CID_B')==core_before and ms.get_edge('EBC')==edge_before
    assert revised['utm']['derived_from_geometry_hash']==revised['geometry_hash']


def test_multi_utm_zone_geometry_never_misrepresented_as_one():
    geo={'type':'LineString','coordinates':[[101.9,16.0],[102.1,16.0]]}
    proj=project_geometry(geo)
    assert proj['horizontal_crs'] is None
    assert proj['zone_mode']=='MULTI_ZONE_PER_VERTEX'
    assert proj['horizontal_crs_per_vertex']==['EPSG:32647','EPSG:32648']
    assert proj['coordinates_are_metric'] is False


def test_dual_csv_export_import_roundtrip(setup,tmp_path):
    bm,ms,audit=setup
    bm.add_feature('ทุ่น1',{'type':'Point','coordinates':[103.197839,16.199682,10]},'owner','agent',vertical_crs='EPSG:4979')
    bm.add_feature('ทุ่น2',{'type':'Point','coordinates':[103.197670,16.199754]},'owner','agent')
    data=bm.export_dual_csv()
    rows=list(csv.DictReader(io.StringIO(data)))
    assert len(rows)==2 and rows[0]['horizontal_crs']=='EPSG:32648'
    assert rows[0]['Z']=='10.000' and rows[0]['vertical_crs']=='EPSG:4979'
    assert rows[1]['Z']=='' and rows[1]['vertical_crs']==''
    path=tmp_path/'dual.csv';path.write_text(data,encoding='utf-8')
    db=tmp_path/'second.db';other_ms=MeaningSpace(db);other=BigMapMeaning(db,other_ms,AuditChain(db))
    res=other.import_utm_csv(path,'owner','agent')
    assert res['count']==2
    geo=other.list_features()['features'][0]['geometry']['coordinates']
    assert abs(geo[0]-103.197839)<1e-7 and abs(geo[1]-16.199682)<1e-7
    assert other.verify_history()['status']=='PASS'


def test_bad_import_no_partial_writes(setup,tmp_path):
    bm,_,_=setup
    path=tmp_path/'bad.csv'
    path.write_text('X,Y,Z,utm_zone,hemisphere\n307349.619,1791868.757,,48,N\n307349.619,1791868.757,33,47,N\n')
    with pytest.raises(ValueError):bm.import_utm_csv(path,'o','a')
    assert bm.list_features()['features']==[]


def test_production_cli_still_default_deny():
    for cmd in ('bigmap-import-utm','bigmap-utm-point','bigmap-utm-inverse'):
        assert cli_allowed(cmd,{'OLGM_ENV':'production'}) is False


class FakeBackend(ModelBackend):
    def __init__(self,payload):self.payload=payload
    def complete(self,system,user):return json.dumps(self.payload)
    @property
    def name(self):return 'mock/not-live'


def example_obs(answer='possible'):
    return {'meaning_cores':[{'proposed_surface':'river','language':'en','definition':'river','role':'a'},
                             {'proposed_surface':'bank','language':'en','definition':'bank','role':'b'}],
            'relation':{'source':'river','target':'bank','type':'bounded_by','direction':'forward','confidence':.3,'evidence_ref':None},
            'composite':{'definition':answer},'provenance':{'unknowns':['unverified'],'rationale':'model'}}


def audit_events(db):
    with sqlite3.connect(db) as c:
        return c.execute('SELECT trace_id,event_type,payload FROM audit_chain ORDER BY seq').fetchall()


def test_denied_notimplemented_insufficient_all_audited(setup):
    bm,ms,audit=setup; canti=CANTI(ms.db_path)
    agent=Agent(ms,DisabledBackend(),audit,canti,OTFA(ms))
    assert agent.ask('hello')['status']=='DENIED'
    canti.grant('reason','agent.ask','local_only',60)
    assert agent.ask('a',allow_web=True)['status']=='NOT_IMPLEMENTED'
    assert agent.ask('not valid math','numeric')['status']=='INSUFFICIENT'
    assert agent.ask('x')['status']=='INSUFFICIENT'
    events=[json.loads(p) for _,e,p in audit_events(ms.db_path) if e=='AGENT_OUTCOME']
    assert [v['status'] for v in events]==['DENIED','NOT_IMPLEMENTED','INSUFFICIENT','INSUFFICIENT']
    assert audit.verify()[0]


def test_exception_does_not_leak_internal_message(setup):
    bm,ms,audit=setup
    class BadModel(ModelBackend):
        def complete(self,system,user):raise RuntimeError('api_key=SECRET_PRIVATE_VALUE')
    result=Observer(ms,BadModel(),audit).observe('T','t','q')
    assert 'SECRET_PRIVATE_VALUE' not in json.dumps(result)
    assert 'SECRET_PRIVATE_VALUE' not in json.dumps(audit_events(ms.db_path))


def test_observer_missing_relation_and_empty_candidate_fail_closed(setup):
    bm,ms,audit=setup;canti=CANTI(ms.db_path);canti.grant('reason','agent.ask','local',60)
    agent=Agent(ms,FakeBackend(example_obs(answer='')),audit,canti,OTFA(ms))
    assert agent.ask('foo')['status']=='INSUFFICIENT'
    assert agent.ask('foo')['reason']=='EMPTY_ANSWER_CANDIDATE'
    broken=example_obs();broken.pop('relation')
    result=Agent(ms,FakeBackend(broken),audit,canti,OTFA(ms)).ask('missing')
    assert result['status']=='INSUFFICIENT'
    assert audit.verify()[0]


def test_candidate_relation_id_is_persisted_not_verified(setup):
    bm,ms,audit=setup;canti=CANTI(ms.db_path);canti.grant('reason','agent.ask','local',60)
    agent=Agent(ms,FakeBackend(example_obs()),audit,canti,OTFA(ms))
    res=agent.ask('river banks')
    assert res['status']=='CANDIDATE' and res['answer_candidate']=='possible'
    ref=res['claim']['relation_id'];assert ref.startswith('obsrel_') and ref==res['candidate_relation_ref']
    with sqlite3.connect(ms.db_path) as db:
        row=db.execute('SELECT trace_id,status FROM observation_candidate_relations WHERE relation_ref=?',(ref,)).fetchone()
    assert row==(res['trace_id'],'CANDIDATE')
    assert res['otfa']['planes']['relation']['status']=='NOT_TESTED'
    assert ms.context_snapshot([])==[] # not inserted as verified semantic edge
    assert audit.verify()[0]


def test_dual_file_converter_preserves_source_and_never_overwrites(tmp_path):
    from olgm.utm_wgs84 import dual_csv
    source=tmp_path/'source.csv'
    source.write_text('lat,lon,Z,vertical_crs\n16.199682,103.197839,,\n',encoding='utf-8')
    out=tmp_path/'result.csv'
    result=dual_csv(source,out)
    assert result['status']=='EXPORTED' and result['points']==1
    assert source.read_text(encoding='utf-8').startswith('lat,lon')
    rows=list(csv.DictReader(io.StringIO(out.read_text(encoding='utf-8-sig'))))
    assert rows[0]['horizontal_crs']=='EPSG:32648' and rows[0]['Z']==''
    original=out.read_bytes()
    with pytest.raises(ValueError,match='output_exists'):dual_csv(source,out)
    assert out.read_bytes()==original
    source.write_text('lat,lon,Z,vertical_crs\nnot_a_latitude,103.1,,\n',encoding='utf-8')
    with pytest.raises(ValueError,match='csv_line_2_invalid'):dual_csv(source,tmp_path/'bad.csv')
    assert not (tmp_path/'bad.csv').exists()


def test_sqlite_backup_before_upgrade_is_verified_and_read_only(setup,tmp_path):
    from tools.backup_before_upgrade import backup
    bm,ms,audit=setup
    bm.add_feature('before',{'type':'Point','coordinates':[103.19,16.2]},'o','actor')
    before=bm.verify_history()
    result=backup(bm.db_path,tmp_path/'backups')
    assert result['status']=='BACKUP_VERIFIED'
    assert __import__('pathlib').Path(result['path']).is_file()
    assert bm.verify_history()==before
    assert audit.verify()[0]


def test_candidate_relation_tamper_detected(setup):
    _,ms,audit=setup
    canti=CANTI(ms.db_path);canti.grant('reason','agent.ask','dev',60)
    result=Agent(ms,FakeBackend(example_obs()),audit,canti,OTFA(ms)).ask('river bank')
    ref=result['candidate_relation_ref']
    with sqlite3.connect(ms.db_path) as db:
        db.execute('UPDATE observation_candidate_relations SET relation_json=? WHERE relation_ref=?',('tampered',ref))
    checked=OTFA(ms).verify({'relation_id':ref,'claim_type':'inferred','evidence_refs':[]})
    assert checked['planes']['relation']['status']=='INSUFFICIENT'
    assert checked['planes']['relation']['reason']=='candidate_relation_integrity_failed'
