"""G-06 actual code-level proof, separated from unsupported general AI claims."""
import json
import subprocess
import sys
from pathlib import Path
import pytest
from olgm.audit import AuditChain
from olgm.self_learn.primitives import PrimitiveRegistry
from olgm.self_learn.pipeline import Pipeline
from olgm.self_learn.curriculum import Curriculum,TASKS
from olgm.self_learn.evolution import Evolver,score,pareto_front
from olgm.self_learn.structural_growth import StructuralGrower
from olgm.self_learn.orchestrator_v2 import HeavyDutyLearnerV2
from olgm.self_learn.memory import PipelineMemory


def learner(tmp_path):
    return HeavyDutyLearnerV2(AuditChain(str(tmp_path/'a.db')),str(tmp_path/'state.json'))

def test_primitives_are_deterministic_and_bounded():
    r=PrimitiveRegistry()
    assert Pipeline(['double','plus_one']).execute(3,r)['result']==7
    assert Pipeline(['square','square']).execute(2000,r)['ok'] is False
    assert Pipeline(['evil']).execute(1,r)['ok'] is False
    with pytest.raises(ValueError):r.composition('double',['identity'])

def test_composition_equivalence_no_fake_discount():
    r=PrimitiveRegistry();g=StructuralGrower(r)
    p=g.propose_from_winner(['double','plus_one'])
    out=g.verify_and_register(p)
    assert out['status']=='REGISTERED'
    assert r[p.fn_name].cost==r['double'].cost+r['plus_one'].cost
    for x in range(-30,30):
        assert r.apply(p.fn_name,x)==r.apply('plus_one',r.apply('double',x))
    assert g.verify_and_register(p)['status']=='REJECTED'

def test_plateau_requires_history_not_single_fitness():
    r=PrimitiveRegistry();g=StructuralGrower(r,plateau_threshold=3)
    assert not g.detect_plateau([{'best_accuracy':1.0,'steps':['double','plus_one']}]*3)[0]
    assert g.detect_plateau([{'best_accuracy':1.0,'steps':['double','plus_one']}]*4)[0]
    assert not g.detect_plateau([{'best_accuracy':0.1,'steps':[]},{'best_accuracy':0.3,'steps':[]},
                                  {'best_accuracy':0.8,'steps':[]},{'best_accuracy':1.0,'steps':[]}])[0]

def test_evolution_is_real_and_not_constant():
    c=Curriculum();r=PrimitiveRegistry();ev=Evolver(r,pop_size=60,generations=12,seed=418)
    best,history=ev.evolve(c.train('affine'),warm_starts=[Pipeline(['identity'])])
    assert len(history)==12
    assert history[-1]['best_accuracy']>=history[0]['best_accuracy']
    assert score(best,c.train('affine'),r).accuracy>=0.8
    assert all('pareto_size' in row for row in history)

def test_pareto_tradeoff_not_a_scalar_label():
    r=PrimitiveRegistry();c=Curriculum();p1=Pipeline(['identity']);p2=Pipeline(['double','plus_one'])
    f=pareto_front([(p1,score(p1,c.train('affine'),r)),(p2,score(p2,c.train('affine'),r))])
    assert len(f)==2 # cheaper-but-less-accurate, accurate-but-more-expensive

def test_curriculum_disjoint_train_validate_holdout():
    c=Curriculum()
    for tag in TASKS:
        a={p.x for p in c.train(tag)};b={p.x for p in c.validate(tag)};d={p.x for p in c.holdout(tag)}
        assert not a&b and not a&d and not b&d
        # Attempt to inject a hidden sample into training is rejected.
        assert c.add_challenges(tag,list(d),10)==0
    tampered=c.serialize_train();tampered['affine'][0]['expected']=12345
    with pytest.raises(ValueError):c.restore_train(tampered)

def test_adversarial_challenges_are_reference_verified(tmp_path):
    l=learner(tmp_path)
    result=l.coevo.adapt_curriculum(l.curr,'affine',Pipeline(['identity']),l.registry,1)
    assert result['added']>0
    assert all(p.expected==l.curr._make('affine',p.x,'test').expected for p in l.curr.train('affine'))

def test_iteration_audit_promotion_and_holdout(tmp_path):
    a=AuditChain(str(tmp_path/'audit.db'))
    l=HeavyDutyLearnerV2(a,str(tmp_path/'state.json'))
    initial=l.report()['final_holdout_mean_before']
    for _ in range(6):l.cycle(n_generations=12,batch_size=10,pop_size=48)
    rep=l.report()
    assert rep['promotions']>=4
    assert rep['final_holdout_mean_after']>initial
    assert rep['final_holdout_delta']>0
    assert rep['status']=='EXPERIMENTAL_NOT_S10_CERTIFIED'
    assert a.verify()[0]

def test_real_growth_at_19_generations_and_resumption(tmp_path):
    a=AuditChain(str(tmp_path/'audit.db'));tracker=str(tmp_path/'state.json')
    l=HeavyDutyLearnerV2(a,tracker)
    for _ in range(19):last=l.cycle(12,10,48)
    assert last['growth']['action']=='ADDED_PRIMITIVE'
    rep=l.report(); assert rep['growth_count']>=1
    l2=HeavyDutyLearnerV2(a,tracker)
    assert len(l2.registry)==len(l.registry)
    assert l2.report()['final_holdout_mean_after']==rep['final_holdout_mean_after']
    assert l2.memory.rehydrate(l2.state['history'][0]['episode_id'],l2.registry)['status']=='REHYDRATED'
    assert a.verify()[0]

def test_no_source_or_canonical_mutation(tmp_path):
    import hashlib
    root=Path(__file__).resolve().parents[1]
    files=[root/'olgm'/'canonical.py',root/'olgm'/'methods.py',root/'runtime.py']
    before=[hashlib.sha256(f.read_bytes()).hexdigest() for f in files]
    l=learner(tmp_path);l.cycle(6,8,20)
    assert [hashlib.sha256(f.read_bytes()).hexdigest() for f in files]==before

def test_cross_intent_transfer_requires_evaluation(tmp_path):
    l=learner(tmp_path)
    a=l.cycle(10,10,40,intent='affine')
    b=l.cycle(10,10,40,intent='mirror')
    assert a['intent']!=b['intent']
    assert l.meta.transfer('mirror')
    assert b['validation_accuracy']>=score(Pipeline(['identity']),l.curr.validate('mirror'),l.registry).accuracy

def test_persistence_rejects_tampered_training_data(tmp_path):
    l=learner(tmp_path);l.cycle(6,8,20)
    saved=json.loads(l.tracker_path.read_text())
    saved['curriculum']['affine'][0]['expected']=9999
    l.tracker_path.write_text(json.dumps(saved))
    with pytest.raises(ValueError):HeavyDutyLearnerV2(l.audit,str(l.tracker_path))

def test_memory_pointer_rehydrate_rejects_missing_component(tmp_path):
    mem=PipelineMemory(tmp_path/'e.db')
    eid=mem.record('affine',['double','plus_one'],{'promoted':True,'validation_accuracy':1.0})
    assert mem.rehydrate(eid,PrimitiveRegistry())['status']=='REHYDRATED'
    eid2=mem.record('other',['nonexistent'],{'promoted':True,'validation_accuracy':0.5})
    assert mem.rehydrate(eid2,PrimitiveRegistry())['status']=='INCOMPLETE'
    with pytest.raises(ValueError):mem.record('a',['identity'],{'promoted':False,'validation_accuracy':0.0})

def test_cli_g06_uses_separate_temporary_database(tmp_path):
    root=Path(__file__).resolve().parents[1]
    import os
    env={**os.environ,'OLGM_DB':str(tmp_path/'olgm.db')}
    state=tmp_path/'g06.json'
    cmd=[sys.executable,str(root/'runtime.py'),'selflearn-v2-cycle','--gens','5','--batch','8',
         '--pop','20','--state',str(state)]
    r=subprocess.run(cmd,cwd=tmp_path,env=env,text=True,capture_output=True,timeout=40)
    assert r.returncode==0,r.stderr+r.stdout
    assert json.loads(r.stdout)['status']=='EXPERIMENTAL'
    rr=subprocess.run([sys.executable,str(root/'runtime.py'),'selflearn-v2-report','--state',str(state)],
                     cwd=tmp_path,env=env,text=True,capture_output=True,timeout=40)
    assert rr.returncode==0
    assert json.loads(rr.stdout)['generations']==1

def test_state_hash_bound_to_audit_and_tampering_fails_closed(tmp_path):
    a=AuditChain(str(tmp_path/'audit.db'))
    state=str(tmp_path/'state.json')
    l=HeavyDutyLearnerV2(a,state)
    l.cycle(5,8,20)
    assert HeavyDutyLearnerV2(a,state).verify_state_commit()['status']=='STATE_AUDIT_BOUND'
    content=json.loads(Path(state).read_text())
    content['champions']['affine']['steps']=['identity']
    Path(state).write_text(json.dumps(content))
    with pytest.raises(ValueError,match='g06_state_audit_hash_mismatch'):
        HeavyDutyLearnerV2(a,state)


def test_s10_explicitly_blocks_g06_self_certification(tmp_path):
    from olgm.s10 import RELEASE_GATES,evaluate
    from olgm.meaning_space import MeaningSpace
    from olgm.otfa import OTFA
    from olgm.pipeline import IntegratedRuntime
    from olgm.canti import CANTI
    from olgm.observer import DisabledBackend
    ms=MeaningSpace(str(tmp_path/'app.db'))
    audit=AuditChain(ms.db_path)
    rt=IntegratedRuntime(ms,DisabledBackend(),audit,CANTI(ms.db_path),OTFA(ms))
    report=evaluate(rt)
    assert any(g[0]=='S10-17' for g in RELEASE_GATES)
    assert any(g['gate_id']=='S10-17' and g['status']=='BLOCKED' for g in report['gates'])
    assert report['release_authorized'] is False
