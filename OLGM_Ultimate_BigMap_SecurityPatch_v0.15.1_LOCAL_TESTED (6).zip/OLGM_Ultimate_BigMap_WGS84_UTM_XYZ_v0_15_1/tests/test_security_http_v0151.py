"""Transport-layer regression for audited failures and no exception disclosure."""
import json
import os
from pathlib import Path
import socket
import sqlite3
import subprocess
import sys
import threading
import time
from http.server import ThreadingHTTPServer

import pytest
import requests

from console import create_handler
from runtime import build_runtime
from olgm.audit import AuditChain
from olgm.ui.service import ConsoleService


@pytest.fixture
def ui(tmp_path, monkeypatch):
    db = tmp_path / 'ui.db'
    monkeypatch.setenv('OLGM_DB', str(db))
    monkeypatch.setenv('OLGM_MODEL_PROVIDER', 'disabled')
    rt = build_runtime()
    service = ConsoleService(rt.ms.db_path, rt)
    server = ThreadingHTTPServer(('127.0.0.1', 0), create_handler(service, 'o' * 40, 0, 'a' * 40))
    # The CSRF origin must reference the actual port.
    server.RequestHandlerClass = create_handler(service, 'o' * 40, server.server_port, 'a' * 40)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f'http://127.0.0.1:{server.server_port}', db, rt
    finally:
        server.shutdown()
        server.server_close()
        thread.join(3)


def _events(db, event):
    with sqlite3.connect(db) as con:
        return [json.loads(row[0]) for row in con.execute('SELECT payload FROM audit_chain WHERE event_type=? ORDER BY seq', (event,))]


def test_console_rejections_are_in_audit_including_login_and_csrf(ui):
    url, db, rt = ui
    assert requests.get(url + '/api/ui/bootstrap').status_code == 401
    assert requests.post(url + '/api/ui/login', json={'token':'incorrect'}, headers={'X-OLGM-UI':'local-console'}).status_code == 401
    assert requests.post(url + '/api/ui/login', json={'token':'o'*40}).status_code == 403
    events = _events(db, 'HTTP_UI_OUTCOME')
    assert len(events) >= 3
    assert [e['http_status'] for e in events[-3:]] == [401, 401, 403]
    assert all('route_sha256' in e and 'method' in e for e in events)
    assert rt.audit.verify()[0]


def test_console_json_parser_does_not_expose_user_supplied_value(ui):
    url, db, rt = ui
    secret = 'PRIVATE_TOKEN_SHOULD_NOT_LEAK_3242'
    r = requests.post(url+'/api/ui/login', data='{"bad":' + secret + '}',
                      headers={'Content-Type':'application/json','X-OLGM-UI':'local-console'})
    assert r.status_code == 400
    assert r.json()['reason'] == 'INVALID_JSON_OR_FIELDS'
    assert secret not in r.text and secret not in json.dumps(_events(db,'HTTP_UI_OUTCOME'))
    assert rt.audit.verify()[0]


def test_console_fails_closed_if_audit_is_unavailable(ui, monkeypatch):
    url, db, rt = ui
    def broken_append(*args,**kwargs):
        raise OSError('SECRET_PATH_DO_NOT_RETURN')
    monkeypatch.setattr(rt.audit, 'append', broken_append)
    r=requests.get(url+'/api/ui/bootstrap')
    assert r.status_code == 503
    assert r.json() == {'status':'SERVICE_UNAVAILABLE','reason':'AUDIT_UNAVAILABLE'}
    assert 'SECRET_PATH' not in r.text


@pytest.fixture
def api(tmp_path):
    db=tmp_path/'api.db'
    root=Path(__file__).resolve().parents[1]
    with socket.socket() as s:
        s.bind(('127.0.0.1',0))
        port=s.getsockname()[1]
    token='testing_api_token_12345'
    env={**os.environ,'OLGM_DB':str(db),'OLGM_MODEL_PROVIDER':'disabled','OLGM_HTTP_TOKEN':token}
    proc=subprocess.Popen([sys.executable,str(root/'runtime.py'),'serve','--host','127.0.0.1','--port',str(port)],
                          cwd=tmp_path,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    url=f'http://127.0.0.1:{port}'
    try:
        for _ in range(100):
            if proc.poll() is not None:
                raise AssertionError('API server terminated unexpectedly')
            try:
                if requests.get(url+'/health',timeout=.5).status_code == 200:
                    break
            except requests.RequestException:
                time.sleep(.05)
        else: raise AssertionError('API server not ready')
        yield url,db,token
    finally:
        proc.terminate()
        try:proc.wait(5)
        except subprocess.TimeoutExpired:
            proc.kill();proc.wait(5)


def test_api_denial_and_bad_json_audited_without_exception_leak(api):
    url,db,token=api
    secret='PRIVATE_VALUE_abc54321'
    denied=requests.post(url+'/api/ask',json={'q':'hello'},headers={'X-OLGM-Token':'incorrect'},timeout=5)
    assert denied.status_code==401 and denied.json()['status']=='DENIED'
    invalid=requests.post(url+'/api/ask',data='{"q":'+secret+'}',headers={
        'Content-Type':'application/json','X-OLGM-Token':token},timeout=5)
    assert invalid.status_code==400 and invalid.json()['reason']=='INVALID_JSON_OR_FIELDS'
    not_implemented=requests.post(url+'/api/process',json={'q':'x'},headers={'X-OLGM-Token':token},timeout=5)
    # process may fail due to lack of CANTI; response must not advertise it as successful
    assert not_implemented.status_code in (200,403)
    events=_events(db,'HTTP_API_OUTCOME')
    assert len(events)>=2 and events[0]['http_status']==401 and events[1]['http_status']==400
    assert 'PRIVATE_VALUE' not in invalid.text and secret not in json.dumps(events)
    assert AuditChain(db).verify()[0]


def test_self_learning_rejects_unknown_primitive_without_echoing_exception():
    from olgm.self_learn.pipeline import Pipeline
    from olgm.self_learn.primitives import PrimitiveRegistry
    result = Pipeline(['unknown_internal_component']).execute(1, PrimitiveRegistry())
    assert result['ok'] is False
    assert result['reason'] == 'PIPELINE_EXECUTION_INVALID'
    assert 'KeyError' not in result['reason']
