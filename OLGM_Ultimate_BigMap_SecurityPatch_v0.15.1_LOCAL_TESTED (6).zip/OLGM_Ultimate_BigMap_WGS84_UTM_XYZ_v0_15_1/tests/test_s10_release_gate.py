"""S-10's key quality is to refuse a false full release."""
import copy
import hashlib
import json
import os
from pathlib import Path
import pytest
from olgm.audit import AuditChain
from olgm.meaning_space import MeaningSpace
from olgm.canti import CANTI
from olgm.otfa import OTFA
from olgm.pipeline import IntegratedRuntime
from olgm.observer import DisabledBackend
from olgm.checkpoints import STAGES
from olgm.s10 import evaluate,check_evidence_manifest,source_manifest


def runtime(tmp_path):
    ms=MeaningSpace(str(tmp_path/'s10.db'))
    audit=AuditChain(ms.db_path)
    return IntegratedRuntime(ms,DisabledBackend(),audit,CANTI(ms.db_path),OTFA(ms))


def test_blank_database_cannot_pass(tmp_path):
    rt=runtime(tmp_path)
    r=evaluate(rt)
    assert r['overall']=='NOT_PASSED'
    assert r['release_authorized'] is False
    assert r['counts']['passed']==0
    assert r['mechanical_checks']['audit_chain']['status']=='NOT_TESTED'
    assert r['mechanical_checks']['checkpoint_integrity']['status']=='NOT_TESTED'


def test_full_trace_is_not_equivalent_to_full_certification(tmp_path):
    rt=runtime(tmp_path)
    rt.canti.grant('reason','agent.ask','test',ttl=60)
    r=rt.process('1+2',intent_tag='numeric')
    assert len(r['checkpoints'])==len(STAGES)
    gate=evaluate(rt,trace_id=r['trace_id'])
    assert gate['mechanical_checks']['full_trace_recorded']['status']=='PASS'
    assert gate['mechanical_checks']['full_trace_recorded']['all_stages_pass'] is False
    assert gate['overall']=='NOT_PASSED'
    assert any('F-01' in g['nonpass_checkpoints'] for g in gate['gates'])


def test_unknown_trace_cannot_pass(tmp_path):
    rt=runtime(tmp_path)
    gate=evaluate(rt,trace_id='nonexistent-trace')
    assert gate['overall']=='NOT_PASSED'
    assert gate['mechanical_checks']['full_trace_recorded']['status']=='NOT_TESTED'


def test_missing_stage_declared_fail_not_pass(tmp_path):
    rt=runtime(tmp_path)
    rt.checkpoints.record('broken-trace','F-00','PASS',{},{} )
    gate=evaluate(rt,trace_id='broken-trace')
    assert gate['overall']=='FAIL'
    assert not gate['mechanical_checks']['full_trace_recorded']['all_stages_in_exact_order']


def test_tamper_checkpoint_blocks_release(tmp_path):
    import sqlite3
    rt=runtime(tmp_path)
    rt.canti.grant('reason','agent.ask','test',ttl=60)
    r=rt.process('1+2',intent_tag='numeric')
    with sqlite3.connect(rt.ms.db_path) as db:
        db.execute("UPDATE checkpoints SET status='PASS' WHERE trace_id=? AND stage='F-01'",(r['trace_id'],))
    result=evaluate(rt,trace_id=r['trace_id'])
    assert result['overall']=='FAIL'
    assert result['mechanical_checks']['checkpoint_integrity']['status']=='FAIL'


def test_unsigned_evidence_rejected(tmp_path):
    doc=tmp_path/'doc.json';doc.write_text('{"T06":"PASS"}')
    manifest=tmp_path/'manifest.json'
    manifest.write_text(json.dumps({'items':[{'gate_id':'S10-06','artifact':'doc.json',
            'sha256':hashlib.sha256(doc.read_bytes()).hexdigest(),
            'signer':'arbitrary','signature_hex':'abcd'}]}))
    result=check_evidence_manifest(manifest,tmp_path)
    assert result['status']=='FAIL'
    assert result['items'][0]['status']=='REJECTED'


def test_manifest_path_escape_rejected(tmp_path):
    outside=tmp_path.parent/('outside-'+tmp_path.name+'.txt')
    outside.write_text('unverified')
    manifest=tmp_path/'manifest.json'
    manifest.write_text(json.dumps({'items':[{'gate_id':'S10-06','artifact':'../'+outside.name,
            'sha256':hashlib.sha256(outside.read_bytes()).hexdigest(),
            'signer':'s','signature_hex':'deadbeef'}]}))
    try:
        assert check_evidence_manifest(manifest,tmp_path)['status']=='FAIL'
    finally:outside.unlink()


def test_signed_evidence_is_integrity_only(tmp_path):
    cryptography=pytest.importorskip('cryptography')
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization
    priv=Ed25519PrivateKey.generate()
    pub=priv.public_key().public_bytes(encoding=serialization.Encoding.Raw,
                                        format=serialization.PublicFormat.Raw).hex()
    proof=tmp_path/'evidence.json';proof.write_text('{"observation":"candidate"}')
    digest=hashlib.sha256(proof.read_bytes()).hexdigest()
    signed=f'OLGM-S10|S10-06|evidence.json|{digest}'.encode()
    item={'gate_id':'S10-06','artifact':'evidence.json','sha256':digest,
          'signer':'unverified-operator','signature_hex':priv.sign(signed).hex()}
    manifest=tmp_path/'manifest.json';manifest.write_text(json.dumps({'items':[item]}))
    valid=check_evidence_manifest(manifest,tmp_path,{'unverified-operator':pub})
    assert valid['status']=='INTEGRITY_VERIFIED'
    assert valid['independent_review']=='NOT_ESTABLISHED_BY_CRYPTOGRAPHY'
    proof.write_text('{"observation":"tampered"}')
    assert check_evidence_manifest(manifest,tmp_path,{'unverified-operator':pub})['status']=='FAIL'


def test_source_mismatch_test_capture_rejected(tmp_path):
    rt=runtime(tmp_path)
    f=tmp_path/'capture.json'
    f.write_text(json.dumps({'returncode':0,'failed':0,'passed':9000,'skipped':0,
             'stdout':'9000 passed','command':['python','-m','pytest','-q','-ra'],
             'source_sha256':{'runtime.py':'fake'}}))
    result=evaluate(rt,test_capture=f)
    assert result['mechanical_checks']['local_test_capture']['status']=='REJECTED'


def test_source_manifest_is_source_only(tmp_path):
    root=Path(__file__).resolve().parent.parent
    m=source_manifest(root)
    assert 'runtime.py' in m
    assert 'olgm/s10.py' in m
    assert 'olgm/self_learn/orchestrator_v2.py' in m
    assert all(not n.endswith(('.db','.key')) for n in m)
