"""Local mechanisms only: NOT proof of human-level Thai intelligence or production S10."""
import ast
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime,timedelta,timezone
from pathlib import Path
import pytest
from olgm.audit import AuditChain
from olgm.canti import CANTI
from olgm.intent import digest
from olgm.identity import SignedAuthorizations
from olgm.meaning_space import MeaningSpace
from olgm.thai.patterns import PATTERNS,stats
from olgm.thai.nlu import ThaiIntentRouter
from olgm.thai.text import normalize,similarity
from olgm.thai.responder import ThaiResponder,ThaiMath
from olgm.thai.learning import ThaiExampleMemory
from olgm.thai.lexicon import ThaiLexicon
from olgm.thai.sovereignty import OriginPolicy
from olgm.thai.codegen import PATTERNS as CODE_PATTERNS,SafeCodeGenerator,capabilities

@pytest.fixture
def context(tmp_path):
    db=str(tmp_path/'runtime.db')
    ms=MeaningSpace(db)
    audit=AuditChain(db)
    canti=CANTI(db)
    policy=OriginPolicy('origin-declaration-hash','canonical-file-hash')
    memory=ThaiExampleMemory(db,audit,canti,policy)
    return ms,audit,canti,memory

@pytest.fixture
def origin_key(context):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization
    ms,audit,canti,mem=context
    private=Ed25519PrivateKey.generate()
    public=private.public_key().public_bytes(encoding=serialization.Encoding.Raw,
                                            format=serialization.PublicFormat.Raw).hex()
    result=SignedAuthorizations(ms.db_path).enroll_public_key('registered-owner-key',public,'Origin','out-of-band-bootstrap')
    assert result['status']=='KEY_ENROLLED_LOCAL_TRUST_BOOTSTRAP'
    return private

def sign(private,receipt):return private.sign(digest(receipt).encode()).hex()
def expiry():return (datetime.now(timezone.utc)+timedelta(hours=1)).isoformat()

def test_catalog_is_large_but_claims_bounded():
    meta=stats()
    assert meta['intent_patterns']>=70
    assert meta['thai_and_english_triggers']>=250
    assert len(meta['groups'])>=10
    assert len(CODE_PATTERNS)>=35
    assert 'learn' in 'thai_learn'

@pytest.mark.parametrize('phrase,intent',[
    ('ช่วยวิเคราะห์เหตุผลความจำเป็นจัดซื้อ','procurement_need'),
    ('อธิปไตยทางปัญญากับผู้ริเริ่มแนวคิด','olgm_sovereign'),
    ('เช็กพิกัด utm','gis_crs'),
    ('สร้างฟังก์ชันคำนวณค่าเฉลี่ย','calculate'),
    ('ตรวจรับพัสดุภาครัฐ','procurement_inspection'),
    ('เขียนโค้ดภาษาไทย','code_write'),
    ('ขอให้ช่วยจัดประเภทวัสดุ','classify'),
])
def test_thai_intent_routing(phrase,intent):
    r=ThaiIntentRouter().detect(phrase)
    assert r['status']=='MATCHED_PATTERN'
    assert any(x['key']==intent for x in r['candidates']),r
    assert r['verified_understanding'] is False

def test_negations_do_not_invert_to_commands():
    r=ThaiIntentRouter().detect('ไม่ต้องเขียนโค้ด')
    assert r['intent']!='code_write'
    assert ThaiIntentRouter().detect('ไม่ให้เขียนโค้ด')['intent']!='code_write'

def test_unicode_and_thai_similarity():
    assert normalize('  ไทย    ภาษา  ')=='ไทย ภาษา'
    assert similarity('สวัสดีครับ','สวัสดีครับ')==1.0
    assert 0.0<similarity('สวัสดีครับ','สวัสดีค่ะ')<1.0

def test_thai_math_is_real_and_rejects_code():
    assert ThaiMath.compute('หนึ่ง บวก สอง')['result']=='3'
    assert ThaiMath.compute('๑๒ คูณ ๓')['result']=='36'
    assert ThaiMath.compute('คำนวณ (6+4)/2')['result']=='5'
    assert ThaiMath.compute('1 / 0')['status']=='MATH_REJECTED'
    assert ThaiMath.compute('__import__("os").system("echo bad")') is None
    assert ThaiMath.compute('2**100000')['status']=='MATH_REJECTED'

def test_thai_responder_no_facts_fabricated(context):
    ms,audit,canti,memory=context
    r=ThaiResponder(memory).answer('สวัสดี')
    assert 'สวัสดี' in r['answer_th']
    assert r['verified_fact'] is False
    assert not r['network_called'] and not r['model_called']
    r2=ThaiResponder(memory).answer('เรื่องลึกลับที่ไม่มีรูปแบบในระบบ')
    assert r2['status']=='INSUFFICIENT'
    assert 'ไม่' in r2['answer_th']
    r3=ThaiResponder(memory).answer('บอกแนวทางอธิปไตยทางปัญญา')
    assert 'Origin' in r3['answer_th']


def test_candidacy_does_not_affect_response_or_origin(context):
    ms,audit,canti,memory=context
    r=memory.propose('OLGM ฉบับทดลองคืออะไร','คำตอบทดลองไม่ใช่ข้อเท็จจริง','origin-ref','source-doc','owned-content','local')
    assert r['status']=='CANDIDATE'
    assert memory.approved_match('OLGM ฉบับทดลองคืออะไร') is None
    assert ThaiResponder(memory).answer('OLGM ฉบับทดลองคืออะไร')['status']!='ANSWER_FROM_APPROVED_EXAMPLE'
    assert audit.verify()[0]


def test_signed_origin_approves_learning_and_replay_rejected(context,origin_key):
    ms,audit,canti,memory=context
    entry=memory.propose('คำทดสอบการเรียนรู้ภาษาไทยเฉพาะกลุ่ม',
                         'เป็นคำอธิบายเฉพาะที่แหล่งต้นทางอนุมัติ','decl-01','doc-01','owned','operator')
    eid=entry['example_id']
    receipt=memory.approval_receipt(eid,'registered-owner-key',expiry())
    signature=sign(origin_key,receipt)
    assert memory.approve(eid,receipt,signature)['status']=='DENIED'  # missing CANTI
    canti.grant('sandbox_train','thai.examples','local-dev',ttl=300)
    wrong=dict(receipt,intent_hash='0'*64)
    assert memory.approve(eid,wrong,sign(origin_key,wrong))['status']=='DENIED'
    ok=memory.approve(eid,receipt,signature)
    assert ok['status']=='APPROVED_LOCAL_ORIGIN_KEY'
    assert memory.approve(eid,receipt,signature)['status']=='DENIED'
    found=memory.approved_match('คำทดสอบการเรียนรู้ภาษาไทยเฉพาะกลุ่ม')
    assert found['status']=='APPROVED_EXAMPLE_NOT_FACT'
    assert found['text']=='เป็นคำอธิบายเฉพาะที่แหล่งต้นทางอนุมัติ'
    assert ThaiResponder(memory).answer('คำทดสอบการเรียนรู้ภาษาไทยเฉพาะกลุ่ม')['status']=='ANSWER_FROM_APPROVED_EXAMPLE'
    assert audit.verify()[0]


def test_tampered_learning_entry_never_served(context,origin_key):
    ms,audit,canti,mem=context
    e=mem.propose('ต้นข้อความทดสอบ', 'คำตอบต้นฉบับ', 'origin','s','owned','local')
    canti.grant('sandbox_train','thai.examples','dev',ttl=300)
    receipt=mem.approval_receipt(e['example_id'],'registered-owner-key',expiry())
    assert mem.approve(e['example_id'],receipt,sign(origin_key,receipt))['status']=='APPROVED_LOCAL_ORIGIN_KEY'
    import sqlite3
    with sqlite3.connect(ms.db_path) as db:
        with pytest.raises(sqlite3.DatabaseError):
            db.execute("UPDATE thai_examples SET answer=? WHERE example_id=?",('คำตอบถูกแก้',e['example_id']))
        # Simulate privileged tampering after the attacker disables a local trigger.
        # Approval-bound hash must still prevent changed records from being served.
        db.execute('DROP TRIGGER thai_examples_no_update')
        db.execute("UPDATE thai_examples SET answer=?,content_hash=? WHERE example_id=?",
                   ('คำตอบถูกแก้',hashlib.sha256(b'fake_replacement').hexdigest(),e['example_id']))
    assert mem.approved_match('ต้นข้อความทดสอบ') is None


def test_no_origin_impersonation_and_no_outbound():
    policy=OriginPolicy('origin','canon')
    assert not policy.check('write','ORIGIN_ONLY',resource='core0')['allowed']
    assert not policy.check('learn','ORIGIN_ONLY',resource='origin_intent/extension')['allowed']
    assert not policy.check('read','PRIVATE',destination='public_api')['allowed']
    assert not policy.check('become_origin','PUBLIC')['allowed']
    assert policy.check('learn','INTERNAL')['allowed']


def test_thai_lexicon_links_existing_cid_without_rewriting(context,origin_key):
    ms,audit,canti,mem=context
    ms.add_core('C-WATER','th','น้ำ',definition='ของเหลว',origin_ref='origin')
    ms.add_core('C-RIVER','th','แม่น้ำ',definition='ทางน้ำไหล',origin_ref='origin')
    ms.add_edge('R1','C-WATER','C-RIVER','flows_to',origin_ref='origin')
    original_core=ms.get_core('C-WATER')
    original_edge=ms.get_edge('R1')
    lex=ThaiLexicon(ms,canti,audit)
    assert lex.propose('ธารา','missing','origin','doc','owned')['status']=='REJECTED'
    assert lex.propose('ธารา','C-WATER','origin','doc','owned')['status']=='DENIED'
    canti.grant('sandbox_write','thai.lexicon','dev',ttl=300)
    a=lex.propose('ธารา','C-WATER','origin','doc','owned')
    assert a['status']=='CANDIDATE'
    assert lex.resolve('ธารา')['status']=='NOT_FOUND'
    receipt=lex.approval_receipt(a['alias_id'],'registered-owner-key',expiry())
    assert lex.approve(a['alias_id'],receipt,sign(origin_key,receipt))['status']=='DENIED'
    canti.grant('sandbox_train','thai.lexicon','dev',ttl=300)
    assert lex.approve(a['alias_id'],receipt,sign(origin_key,receipt))['status']=='APPROVED_LINK'
    assert lex.resolve('ธารา')['cid']=='C-WATER'
    assert ms.get_core('C-WATER')==original_core
    assert ms.get_edge('R1')==original_edge
    assert audit.verify()[0]


def test_thai_alias_conflict_detected(context,origin_key):
    ms,audit,canti,mem=context
    ms.add_core('A','th','ก',origin_ref='origin')
    ms.add_core('B','th','ข',origin_ref='origin')
    canti.grant('sandbox_write','thai.lexicon','dev',300)
    canti.grant('sandbox_train','thai.lexicon','dev',300)
    lex=ThaiLexicon(ms,canti,audit)
    x=lex.propose('นามร่วม','A','origin','s','owned')['alias_id']
    y=lex.propose('นามร่วม','B','origin','s','owned')['alias_id']
    for aid,expected in ((x,'APPROVED_LINK'),(y,'DENIED')):
        receipt=lex.approval_receipt(aid,'registered-owner-key',expiry())
        result=lex.approve(aid,receipt,sign(origin_key,receipt))
        assert result['status']==expected
    assert lex.resolve('นามร่วม')['cid']=='A'

@pytest.mark.parametrize('name',list(CODE_PATTERNS))
def test_reviewed_code_template_executes_expected(name):
    from copy import deepcopy
    pattern=CODE_PATTERNS[name]
    cg=SafeCodeGenerator()
    result=cg.render(name,origin_ref='origin-001')
    assert result['status']=='CODE_CANDIDATE'
    assert hashlib.sha256(result['code'].encode()).hexdigest()==result['source_sha256']
    tree=ast.parse(result['code'])
    assert any(isinstance(node,ast.FunctionDef) and node.name=='process' for node in tree.body)
    # Execution ONLY of built-in audited static templates, not raw user-provided generated code.
    scope={}
    exec(compile(result['code'],'<reviewed-pattern>','exec'),scope)
    actual=scope['process'](deepcopy(pattern.sample_input))
    assert actual==pattern.sample_output,(name,actual,pattern.sample_output)


def test_codegen_cannot_inject_source_via_origin_ref():
    cg=SafeCodeGenerator()
    with pytest.raises(ValueError):
        cg.render('sum',origin_ref='"""\nimport os\n')
    with pytest.raises(ValueError):cg.render('sum_by_key',key='x\nimport os',origin_ref='origin')
    assert cg.render('unknown',origin_ref='origin')['status']=='UNSUPPORTED'
    assert cg.select('เขียนโค้ดหาผลรวมตัวเลข')['pattern']=='sum'
    assert cg.select('เขียนโค้ดเครื่องคำนวณควอนตัมใหม่')['status']=='UNSUPPORTED'


def test_saved_code_gated_and_no_overwrite(context,tmp_path):
    ms,audit,canti,mem=context
    gen=SafeCodeGenerator(tmp_path/'generated',canti)
    p=gen.render('sum',origin_ref='origin-decl')
    with pytest.raises(PermissionError):gen.save(p,'test_function.py')
    canti.grant('sandbox_write','thai.generated','dev',300)
    r=gen.save(p,'test_function.py')
    assert r['status']=='SAVED_CANDIDATE_NOT_EXECUTED'
    assert Path(r['file']).is_file()
    with pytest.raises(FileExistsError):gen.save(p,'test_function.py')
    with pytest.raises(ValueError):gen.save(p,'../outside.py')
    assert not (tmp_path/'outside.py').exists()


def test_cli_thai_process_from_other_folder(tmp_path):
    root=Path(__file__).resolve().parents[1]
    env={**os.environ,'OLGM_DB':str(tmp_path/'thai.db'),'OLGM_MODEL_PROVIDER':'disabled'}
    for cmd,expected in [(['thai-answer','๗ บวก ๘'],'15'),
                         (['thai-detect','ทำเอกสารตรวจรับพัสดุ'],'procurement_inspection'),
                         (['thai-patterns'],'intent_patterns'),
                         (['thai-code-list'],'reviewed_code_patterns')]:
        proc=subprocess.run([sys.executable,str(root/'runtime.py'),*cmd],cwd=tmp_path,
                            env=env,capture_output=True,text=True,timeout=20)
        assert proc.returncode==0,proc.stderr+proc.stdout
        assert expected in proc.stdout


def test_s10_thai_requirements_do_not_self_pass(context):
    from olgm.s10 import RELEASE_GATES,evaluate
    from olgm.pipeline import IntegratedRuntime
    from olgm.otfa import OTFA
    from olgm.observer import DisabledBackend
    ms,audit,canti,mem=context
    rt=IntegratedRuntime(ms,DisabledBackend(),audit,canti,OTFA(ms))
    report=evaluate(rt)
    gates={x['gate_id']:x for x in report['gates']}
    assert all(gates[k]['status']=='BLOCKED' for k in ('S10-18','S10-19','S10-20'))
    assert not report['release_authorized']

@pytest.mark.parametrize('steps,input_data,expected',[
    (['unique','sort'],[3,1,3,2],[1,2,3]),
    (['flatten','sum'],[[1,2],[3,4]],10),
    (['strip','lower'],'  HELLO ', 'hello'),
    (['positive','sum'],[-3,2,4],6),
    (['even','count'],[1,2,3,4],2),
    (['unique','sort_desc'],[1,1,3,2],[3,2,1]),
])
def test_composed_typed_code_is_executable(steps,input_data,expected):
    cg=SafeCodeGenerator()
    result=cg.render_pipeline(steps,origin_ref='origin-01')
    assert result['status']=='CODE_CANDIDATE',result
    ns={}
    exec(compile(result['code'],'<reviewed_pipeline>','exec'),ns)
    assert ns['process'](input_data)==expected
    assert result['structural_reuse']


def test_composed_code_rejects_bad_types_or_missing_contract():
    gen=SafeCodeGenerator()
    assert gen.render_pipeline(['sum','sort'],origin_ref='origin')['reason']=='type_mismatch'
    assert gen.render_pipeline(['sort_by_key','sum'],origin_ref='origin')['status']=='UNSUPPORTED'
    assert gen.render_pipeline(['unique'],origin_ref='origin')['status']=='UNSUPPORTED'
    with pytest.raises(ValueError):gen.render_pipeline(['sum','count'],origin_ref='\"\"\" injection')

def test_thai_response_uses_approved_lexicon(context,origin_key):
    ms,audit,canti,memory=context
    ms.add_core('WATER','th','น้ำ',definition='ของเหลวชนิดหนึ่ง',origin_ref='origin')
    canti.grant('sandbox_write','thai.lexicon','dev',300)
    canti.grant('sandbox_train','thai.lexicon','dev',300)
    lex=ThaiLexicon(ms,canti,audit)
    pending=lex.propose('ธารา','WATER','origin','source','owned')
    assert ThaiResponder(memory,lexicon=lex).answer('ธาราแปลว่าอะไร')['status']!='ANSWER_FROM_APPROVED_LEXICAL_LINK'
    receipt=lex.approval_receipt(pending['alias_id'],'registered-owner-key',expiry())
    assert lex.approve(pending['alias_id'],receipt,sign(origin_key,receipt))['status']=='APPROVED_LINK'
    reply=ThaiResponder(memory,lexicon=lex).answer('ธาราแปลว่าอะไร')
    assert reply['status']=='ANSWER_FROM_APPROVED_LEXICAL_LINK'
    assert reply['cid']=='WATER'
    assert 'ของเหลวชนิดหนึ่ง' in reply['answer_th']
    assert not reply['verified_fact']

def test_symbolic_code_synthesis_generates_program_from_examples():
    from olgm.thai.synthesis import ThaiProgramSynthesizer
    solver=ThaiProgramSynthesizer()
    result=solver.synthesize([[0,1],[1,3],[2,5],[3,7],[5,11]],
                              [[6,13],[8,17]],origin_ref='origin-test',max_depth=4)
    assert result['status']=='CODE_CANDIDATE',result
    assert result['training_accuracy']==1
    assert result['validation_accuracy']==1
    assert result['program_steps']
    ns={};exec(compile(result['code'],'<bounded_synthesis>','exec'),ns)
    assert ns['process'](23)==47


def test_symbolic_synthesis_abstains_when_no_exact_program():
    from olgm.thai.synthesis import ThaiProgramSynthesizer
    solver=ThaiProgramSynthesizer()
    result=solver.synthesize([[1,17],[2,71],[3,101]],origin_ref='origin-test',max_depth=1)
    assert result['status']=='NO_EXACT_PROGRAM'
    assert 'code' not in result
    with pytest.raises(ValueError):solver.synthesize([[1,2],[1,3]],origin_ref='origin-test')
    with pytest.raises(ValueError):solver.synthesize([[0,1]],[[0,1]],origin_ref='origin-test')

def test_approved_alias_is_append_only_and_hash_bound(context,origin_key):
    import sqlite3
    from olgm.thai.lexicon import alias_digest
    ms,audit,canti,mem=context
    ms.add_core('W','th','น้ำ',definition='ของเหลว',origin_ref='owner')
    canti.grant('sandbox_write','thai.lexicon','dev',300)
    canti.grant('sandbox_train','thai.lexicon','dev',300)
    lex=ThaiLexicon(ms,canti,audit)
    candidate=lex.propose('ธารา','W','owner','dictionary-source','owned')
    receipt=lex.approval_receipt(candidate['alias_id'],'registered-owner-key',expiry())
    assert lex.approve(candidate['alias_id'],receipt,sign(origin_key,receipt))['status']=='APPROVED_LINK'
    with sqlite3.connect(ms.db_path) as db:
        with pytest.raises(sqlite3.DatabaseError):
            db.execute('UPDATE thai_alias_candidates SET alias=? WHERE alias_id=?',
                       ('เปลี่ยนชื่อ',candidate['alias_id']))
        # Test privileged DB tampering after bypassing the local append-only trigger.
        db.execute('DROP TRIGGER thai_alias_candidates_no_update')
        forged_hash=alias_digest('เปลี่ยนชื่อ','th','W','owner','dictionary-source','owned')
        db.execute('UPDATE thai_alias_candidates SET alias=?,alias_normalized=?,content_hash=? WHERE alias_id=?',
                   ('เปลี่ยนชื่อ','เปลี่ยนชื่อ',forged_hash,candidate['alias_id']))
    assert lex.resolve('เปลี่ยนชื่อ')['status']=='TAMPERED'
    assert lex.resolve('ธารา')['status']=='NOT_FOUND'

def test_thai_runs_through_full_olgm_checkpoints(context):
    from olgm.pipeline import IntegratedRuntime
    from olgm.otfa import OTFA
    from olgm.observer import DisabledBackend
    from olgm.checkpoints import STAGES
    ms,audit,canti,mem=context
    rt=IntegratedRuntime(ms,DisabledBackend(),audit,canti,OTFA(ms))
    no_model=rt.process('หนึ่ง บวก สอง',intent_tag='thai',enable_model=True)
    assert no_model['status']=='DENIED' and 'Origin' in no_model['reason']
    no_permission=rt.process('หนึ่ง บวก สอง',intent_tag='thai')
    assert no_permission['status']=='DENIED'
    canti.grant('reason','agent.ask','local-dev',ttl=300)
    out=rt.process('หนึ่ง บวก สอง',intent_tag='thai',origin_ref='decl-ref')
    assert out['status']=='DETERMINISTIC_RESULT',out.get('proof_type')
    assert out['answer']=='ผลการคำนวณคือ 3'
    assert out['thai_layer']['status']=='DETERMINISTIC_ANSWER'
    assert [r['stage'] for r in out['checkpoints']]==list(STAGES)
    assert out['gate_s10']=='NOT_PASSED'
    assert not out['can_execute_external_action']
    assert audit.verify()[0]
