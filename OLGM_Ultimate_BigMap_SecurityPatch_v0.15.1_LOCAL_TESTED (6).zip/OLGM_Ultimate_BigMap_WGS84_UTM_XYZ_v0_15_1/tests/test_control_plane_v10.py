"""Control-plane tests: run offline, no actual clicks, no real user data or plugins."""
import json
import sqlite3
from datetime import datetime,timezone,timedelta
import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
from olgm.meaning_space import MeaningSpace
from olgm.audit import AuditChain
from olgm.canti import CANTI
from olgm.intent import IntentLedger
from olgm.identity import SignedAuthorizations
from olgm.control import ResourceRegistry, ControlPlane, ConnectorDispatcher, LocalComputer
from olgm.control.registry import digest
from olgm.production import cli_allowed

@pytest.fixture
def setup(tmp_path):
    path=str(tmp_path/'test.sqlite3')
    MeaningSpace(path)
    audit=AuditChain(path)
    intent=IntentLedger(path,audit)
    canti=CANTI(path)
    keys=SignedAuthorizations(path)
    reg=ResourceRegistry(path)
    ctl=ControlPlane(path,reg,intent,canti,keys,audit)
    # These are locally generated TEST keys, not a verified Origin identity.
    sk=Ed25519PrivateKey.generate()
    pub=sk.public_key().public_bytes(encoding=serialization.Encoding.Raw,
                                     format=serialization.PublicFormat.Raw).hex()
    keys.enroll_public_key('test-origin',pub,'Origin','test-bootstrap')
    i=intent.create('operator','test-origin-ref','ตรวจสอบสถานะเครื่อง',task_type='WORK')
    return locals()


def register(s, resource='computer.xadmin-v1', kind='computer', actions=None, classification='INTERNAL'):
    actions=actions or ['computer.status','computer.screenshot','computer.click','computer.type']
    return s['reg'].register(resource,kind,'X-admin','local-desktop',actions,classification,
                             'origin-ref-local','user-declared-source','OFFLINE')


def propose(s,resource='computer.xadmin-v1',action='computer.status',args=None,key='k1'):
    return s['ctl'].propose(s['i']['intent_id'],s['i']['intent_hash'],resource,action,
                            {} if args is None else args,'operator',key)


def approve(s,plan_id,resource='computer.xadmin-v1',scope='computer_view',principal='test-origin'):
    s['canti'].grant(scope,resource,'test-only',ttl=120)
    r=s['ctl'].receipt(plan_id,principal,(datetime.now(timezone.utc)+timedelta(minutes=3)).isoformat(),'test-approval')
    assert r['status']=='SIGN_THIS_EXACT_PAYLOAD'
    sig=s['sk'].sign(digest(r['receipt']).encode()).hex()
    return s['ctl'].approve(plan_id,r['receipt'],sig),r['receipt'],sig


def test_register_and_list_resources(setup):
    s=setup
    assert register(s)['status']=='REGISTERED_DECLARATION_ONLY'
    assert register(s)['status']=='UNCHANGED'
    assert s['reg'].list('computer')['resources'][0]['connection_state']=='OFFLINE'
    assert register(s,actions=['computer.status'])['status']=='DENIED'


def test_protected_resource_and_invalid_scope(setup):
    s=setup
    with pytest.raises(ValueError):register(s,resource='core0.secret')
    with pytest.raises(ValueError):register(s,actions=['os.shell'])
    with pytest.raises(ValueError):register(s,classification='UNRESTRICTED')


def test_unregistered_action_is_denied(setup):
    s=setup
    register(s,actions=['computer.status'])
    p=propose(s,action='computer.click',args={'x':1,'y':1})
    assert p['status']=='DENIED'


def test_approve_requires_canti_and_signature(setup):
    s=setup;register(s)
    p=propose(s)
    r=s['ctl'].receipt(p['plan_id'],'test-origin',
                      (datetime.now(timezone.utc)+timedelta(minutes=3)).isoformat(),'a')['receipt']
    signature=s['sk'].sign(digest(r).encode()).hex()
    assert s['ctl'].approve(p['plan_id'],r,signature)['reason']=='CANTI_missing_exact_scope'
    s['canti'].grant('computer_view','computer.xadmin-v1','test',120)
    assert s['ctl'].approve(p['plan_id'],dict(r,args_digest='0'*64),signature)['status']=='DENIED'
    assert s['ctl'].approve(p['plan_id'],r,'00'*64)['status']=='DENIED'
    assert s['ctl'].approve(p['plan_id'],r,signature)['status']=='APPROVED'
    assert s['ctl'].approve(p['plan_id'],r,signature)['status']=='DENIED'


def test_origin_role_required_for_control(setup):
    s=setup;register(s)
    sk2=Ed25519PrivateKey.generate()
    s['keys'].enroll_public_key('reviewer-approver',
        sk2.public_key().public_bytes(encoding=serialization.Encoding.Raw,
           format=serialization.PublicFormat.Raw).hex(),'approver','test')
    p=propose(s,action='computer.click',args={'x':2,'y':3})
    s['canti'].grant('computer_control','computer.xadmin-v1','test',120)
    r=s['ctl'].receipt(p['plan_id'],'reviewer-approver',
                      (datetime.now(timezone.utc)+timedelta(minutes=3)).isoformat(),'a')['receipt']
    assert s['ctl'].approve(p['plan_id'],r,sk2.sign(digest(r).encode()).hex())['reason']=='origin_signature_required_for_sensitive_action'


def test_queue_dispatch_works_once(setup):
    s=setup;register(s)
    p=propose(s)
    assert approve(s,p['plan_id'])[0]['status']=='APPROVED'
    assert s['ctl'].enqueue(p['plan_id'])['status']=='QUEUED'
    result=s['ctl'].work_batch(ConnectorDispatcher(computer=LocalComputer('/tmp/no-screenshot',False)))
    assert result['results'][0]['status']=='BLOCKED'
    assert result['results'][0]['result']['status']=='NOT_CONNECTED'
    assert s['ctl'].work_once(ConnectorDispatcher())['status']=='IDLE'
    assert s['audit'].verify()[0]


def test_cancel_cannot_undo_effect(setup):
    s=setup;register(s)
    p=propose(s)
    assert approve(s,p['plan_id'])[0]['status']=='APPROVED'
    assert s['ctl'].enqueue(p['plan_id'])['status']=='QUEUED'
    assert s['ctl'].cancel(p['plan_id'])['status']=='CANCELLED'
    assert s['ctl'].work_once(ConnectorDispatcher())['status']=='IDLE'
    assert s['ctl'].cancel(p['plan_id'])['status']=='DENIED'


def test_future_scheduling_priority_and_retry(setup):
    s=setup;register(s)
    p=propose(s);approve(s,p['plan_id'])
    future=(datetime.now(timezone.utc)+timedelta(days=2)).isoformat()
    assert s['ctl'].enqueue(p['plan_id'],future,2)['status']=='QUEUED'
    assert s['ctl'].work_once(ConnectorDispatcher())['status']=='IDLE'
    assert s['ctl'].enqueue(p['plan_id'])['status']=='DENIED'


def test_stale_intent_after_approval_blocks_dispatch(setup):
    s=setup;register(s)
    p=propose(s);approve(s,p['plan_id'])
    s['ctl'].enqueue(p['plan_id'])
    s['intent'].revise(s['i']['intent_id'],'ยกเลิกการเข้าถึงเครื่อง',reason='change',
                       expected_hash=s['i']['intent_hash'],actor='operator')
    o=s['ctl'].work_once(ConnectorDispatcher())
    assert o['status']=='BLOCKED' and o['result']['status']=='ROOT_REENTRY'


def test_revoked_grant_blocks_dispatch(setup):
    s=setup;register(s)
    p=propose(s)
    approved,_,_=approve(s,p['plan_id'])
    assert approved['status']=='APPROVED'
    s['ctl'].enqueue(p['plan_id'])
    with sqlite3.connect(s['path']) as db:
        db.execute("UPDATE permissions SET revoked_at='2026-01-01T00:00:00+00:00' WHERE action_scope='computer_view'")
    o=s['ctl'].work_once(ConnectorDispatcher())
    assert o['status']=='BLOCKED' and o['result']['reason']=='CANTI_grant_expired_or_revoked'


def test_idempotent_proposals_and_nonce_replay(setup):
    s=setup;register(s)
    p=propose(s,key='same')
    p2=propose(s,key='same')
    assert p2['plan_id']==p['plan_id'] and p2['idempotent']
    app,r,sig=approve(s,p['plan_id'])
    assert app['status']=='APPROVED'
    q=propose(s,key='different')
    assert s['ctl'].approve(q['plan_id'],r,sig)['status']=='DENIED'


def test_plugin_and_space_adapters_are_explicit(setup):
    s=setup
    s['reg'].register('plugin.example-v1','plugin','Example','connected-provider',
                     ['plugin.describe','plugin.invoke'],'INTERNAL','ref','source','DECLARED',targets=['example.read'])
    p=propose(s,'plugin.example-v1','plugin.describe',{},'plugin1')
    approve(s,p['plan_id'],'plugin.example-v1','plugin_read')
    s['ctl'].enqueue(p['plan_id'])
    assert s['ctl'].work_once(ConnectorDispatcher())['result']['status']=='NOT_CONNECTED'
    s['reg'].register('space.example-v1','space','Space','connected-provider',
                     ['space.read'],'INTERNAL','ref','source','DECLARED',targets=['page1'])
    q=propose(s,'space.example-v1','space.read',{'page_id':'page1'},'space1')
    approve(s,q['plan_id'],'space.example-v1','space_read')
    s['ctl'].enqueue(q['plan_id'])
    seen=[]
    def handler(action,args,idempotency_key):
        seen.append((action,args,idempotency_key))
        return {'status':'EXECUTED','page_hash':'abc','scope':'mock_only'}
    resp=s['ctl'].work_once(ConnectorDispatcher(handlers={'space.example-v1':handler}))
    assert resp['status']=='COMPLETED' and len(seen)==1
    assert seen[0][1]=={'page_id':'page1'}


def test_space_write_needs_revision_and_origin_signature(setup):
    s=setup
    s['reg'].register('space.private-v1','space','S','provider',['space.write'],
                     'ORIGIN_ONLY','o','src','DECLARED',targets=['p'])
    with pytest.raises(ValueError):propose(s,'space.private-v1','space.write',{'page_id':'p','content':'a'},'1')
    p=propose(s,'space.private-v1','space.write',{'page_id':'p','content':'a','expected_revision':'v2'},'2')
    assert p['status']=='PENDING_APPROVAL'


def test_computer_disabled_never_captures(setup,tmp_path):
    root=tmp_path/'screens'
    c=LocalComputer(root,enabled=False)
    assert c.dispatch('computer.screenshot',{})['status']=='NOT_CONNECTED'
    assert not root.exists()


def test_unknown_outcome_is_not_retried(setup):
    s=setup
    s['reg'].register('space.example-v1','space','S','provider',['space.read'],
                     'INTERNAL','o','src','DECLARED',targets=['p'])
    p=propose(s,'space.example-v1','space.read',{'page_id':'p'},'k')
    approve(s,p['plan_id'],'space.example-v1','space_read')
    s['ctl'].enqueue(p['plan_id'])
    def explode(*args,**kwargs):raise RuntimeError('network_unknown')
    o=s['ctl'].work_once(ConnectorDispatcher(handlers={'space.example-v1':explode}))
    assert o['status']=='UNKNOWN_OUTCOME'
    assert s['ctl'].work_once(ConnectorDispatcher())['status']=='IDLE'


def test_production_blocks_all_mutations():
    for cmd in ['control-register','control-propose','control-approve','control-enqueue',
                'control-worker-step','control-cancel']:
        assert not cli_allowed(cmd,{'OLGM_ENV':'production'})
    assert cli_allowed('control-status',{'OLGM_ENV':'production'})
    assert cli_allowed('control-resources',{'OLGM_ENV':'production'})


def test_revoked_approval_key_blocks_dispatch(setup):
    s=setup;register(s)
    p=propose(s);approve(s,p['plan_id']);s['ctl'].enqueue(p['plan_id'])
    with sqlite3.connect(s['path']) as db:
        db.execute("UPDATE trusted_public_keys SET revoked_at='2026-01-01T00:00:00+00:00' WHERE principal='test-origin'")
    assert s['ctl'].work_once(ConnectorDispatcher())['result']['reason']=='approval_key_revoked_or_missing'


def test_builtin_skills_dispatch_and_scope_isolation(setup):
    from olgm.control.skills import BuiltinSkillExecutor,SKILLS,installed_skill_id
    s=setup
    sk=BuiltinSkillExecutor(s['reg'],s['ctl'],s['audit'],s['intent'],s['canti'])
    assert sk.install('queue_health','origin')['status']=='REGISTERED_DECLARATION_ONLY'
    skill_id=installed_skill_id('queue_health')
    p=propose(s,resource=skill_id,action='skill.run',args={},key='skill1')
    approve(s,p['plan_id'],skill_id,'skill_run')
    s['ctl'].enqueue(p['plan_id'])
    handler=lambda action,args,idempotency_key:sk.handler('queue_health',action,args,idempotency_key)
    o=s['ctl'].work_once(ConnectorDispatcher(handlers={skill_id:handler}))
    assert o['status']=='COMPLETED'
    assert 'PENDING_APPROVAL' not in o['result']['states'] or isinstance(o['result']['states'],dict)
    assert sk.handler('queue_health','skill.run',{'skill_id':'inventory'},'x')['status']=='DENIED'


def test_production_blocks_skill_install():
    assert not cli_allowed('control-install-skill',{'OLGM_ENV':'production'})


def test_plugin_tool_allowlist_required_and_enforced(setup):
    s=setup
    with pytest.raises(ValueError,match='explicit_tool'):
        s['reg'].register('plugin.example-v1','plugin','Example','provider',
                 ['plugin.invoke'],'INTERNAL','origin','source')
    s['reg'].register('plugin.example-v1','plugin','Example','provider',
            ['plugin.invoke'],'INTERNAL','origin','source',targets=['documents.search'])
    assert propose(s,'plugin.example-v1','plugin.invoke',{'tool':'admin.delete'},'bad')['reason']=='plugin_tool_not_allowlisted'
    assert propose(s,'plugin.example-v1','plugin.invoke',{'tool':'documents.search'},'good')['status']=='PENDING_APPROVAL'


def test_space_page_isolation(setup):
    s=setup
    s['reg'].register('space.example-v1','space','Example','provider',
          ['space.read'],'PRIVATE','origin','src',targets=['page1'])
    assert propose(s,'space.example-v1','space.read',{'page_id':'page2'},'unknown')['reason']=='space_page_not_allowlisted'
    with pytest.raises(ValueError,match='space_read_exact_page'):
        propose(s,'space.example-v1','space.read',{'page_id':'page1','export':'everything'},'unknown2')
    assert propose(s,'space.example-v1','space.read',{'page_id':'page1'},'known')['status']=='PENDING_APPROVAL'


def test_queued_actions_recheck_resource_digest(setup):
    s=setup;register(s)
    p=propose(s);approve(s,p['plan_id']);s['ctl'].enqueue(p['plan_id'])
    with sqlite3.connect(s['path']) as db:
        db.execute('UPDATE access_resources SET entry_digest=? WHERE resource_id=?',('0'*64,'computer.xadmin-v1'))
    o=s['ctl'].work_once(ConnectorDispatcher())
    assert o['status']=='BLOCKED' and o['result']['reason']=='resource_digest_changed'


def test_bad_screenshot_and_keyboard_parameters(setup):
    s=setup;register(s)
    with pytest.raises(ValueError,match='screenshot_no_args'):
        propose(s,action='computer.screenshot',args={'path':'/etc/passwd'})
    with pytest.raises(ValueError,match='invalid_click'):
        propose(s,action='computer.click',args={'x':True,'y':50})
    with pytest.raises(ValueError,match='possible_secret'):
        propose(s,action='computer.type',args={'text':'password=topsecret'})


def test_registry_metadata_tamper_is_fail_closed(setup):
    s=setup;register(s)
    with sqlite3.connect(s['path']) as db:
        db.execute("UPDATE access_resources SET actions_json=? WHERE resource_id=?",
                   (json.dumps(['computer.status','computer.click','computer.type','computer.screenshot','os.shell']),
                    'computer.xadmin-v1'))
    assert s['reg'].get('computer.xadmin-v1') is None
    assert s['reg'].list()['integrity_failures']==1
    assert propose(s)['reason']=='resource_not_registered'
