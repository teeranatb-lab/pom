"""Create a verified SQLite snapshot before altering a local OLGM schema.

Does NOT modify source, Canonical, Archive, origin roles or computer services.
Usage: python tools/backup_before_upgrade.py --db local_data/olgm.db --out local_data/backups
"""
import argparse
import hashlib
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path


def sha256(path):
    digest=hashlib.sha256()
    with open(path,'rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            digest.update(block)
    return digest.hexdigest()


def backup(db_path, out_dir):
    db_path=Path(db_path)
    if not db_path.exists():return {'status':'NEW_DATABASE','message':'no_existing_database'}
    out_dir=Path(out_dir);out_dir.mkdir(parents=True,exist_ok=True)
    label=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    target=out_dir/(db_path.stem+'.before_utm_v015.'+label+'.sqlite3')
    try:
        with sqlite3.connect(f'file:{db_path.resolve()}?mode=ro',uri=True,timeout=20) as src:
            source_ok=src.execute('PRAGMA integrity_check').fetchone()[0]
            if source_ok!='ok':raise ValueError('source_database_integrity_not_ok')
            with sqlite3.connect(target,timeout=20) as out:
                src.backup(out,pages=256,sleep=.02)
        with sqlite3.connect(f'file:{target.resolve()}?mode=ro',uri=True) as check:
            restored_ok=check.execute('PRAGMA integrity_check').fetchone()[0]
            if restored_ok!='ok':raise ValueError('snapshot_integrity_not_ok')
        return {'status':'BACKUP_VERIFIED','path':str(target),'sha256':sha256(target),
                'created_at':datetime.now(timezone.utc).isoformat(),'source_unchanged':True}
    except Exception:
        target.unlink(missing_ok=True)
        raise


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--db',required=True)
    parser.add_argument('--out',required=True)
    args=parser.parse_args()
    print(json.dumps(backup(args.db,args.out),indent=2,ensure_ascii=False))
