"""Restricted candidate-generating agent; no silent semantic mutations."""
import ast
import operator
import re
import uuid
from .observer import Observer
from .episodic import EpisodicMemory
from .methods import select_methods


_BINOPS={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,
        ast.Div:operator.truediv,ast.FloorDiv:operator.floordiv,ast.Mod:operator.mod}
_UNARYOPS={ast.UAdd:operator.pos,ast.USub:operator.neg}


def _arithmetic(expression):
    """Small, safe arithmetic expression evaluator: no names, calls or powers."""
    if len(expression)>80 or not re.fullmatch(r'[0-9.\s+*/%()\-]+',expression):
        raise ValueError('unsupported arithmetic input')
    def evaluate(node, depth=0):
        if depth>20:
            raise ValueError('too deep')
        if isinstance(node,ast.Expression):
            return evaluate(node.body,depth+1)
        if isinstance(node,ast.Constant) and type(node.value) in (float,int):
            if abs(node.value)>1e12: raise ValueError('number too large')
            return node.value
        if isinstance(node,ast.BinOp) and type(node.op) in _BINOPS:
            result=_BINOPS[type(node.op)](evaluate(node.left,depth+1),evaluate(node.right,depth+1))
            if abs(result)>1e15: raise ValueError('result too large')
            return result
        if isinstance(node,ast.UnaryOp) and type(node.op) in _UNARYOPS:
            return _UNARYOPS[type(node.op)](evaluate(node.operand,depth+1))
        raise ValueError('unsupported math syntax')
    return evaluate(ast.parse(expression,mode='eval'))


class Agent:
    def __init__(self, ms, model, audit, canti, otfa):
        self.ms,self.audit,self.canti,self.otfa=ms,audit,canti,otfa
        self.observer=Observer(ms,model,audit)
        self.episodic=EpisodicMemory(ms.db_path,ms)

    def _end(self,trace_id,result):
        """Audit every control-plane outcome before exposing it to caller."""
        self.audit.append(trace_id,'AGENT_OUTCOME',{
            'status':result.get('status','UNKNOWN'),
            'reason_code':result.get('reason'),
            'candidate_relation_ref':result.get('candidate_relation_ref'),
            'has_answer':bool(result.get('answer') or result.get('answer_candidate')),
        })
        return result

    def ask(self, question, intent_tag='true', candidate_cids=None, allow_web=False):
        trace_id=str(uuid.uuid4())
        self.audit.append(trace_id,'AGENT_REQUEST',{'intent_tag':intent_tag,
            'request_sha256':__import__('hashlib').sha256(str(question).encode()).hexdigest(),
            'web_requested':bool(allow_web)})
        if not self.canti.check('reason','agent.ask')['allowed']:
            return self._end(trace_id,{'status':'DENIED','reason':'CANTI_no_grant','trace_id':trace_id})
        if allow_web:
            return self._end(trace_id,{'status':'NOT_IMPLEMENTED','reason':'web_tool_not_wired','trace_id':trace_id})
        try:methods=select_methods(intent_tag)
        except (ValueError,TypeError):
            return self._end(trace_id,{'status':'INSUFFICIENT','reason':'INVALID_INTENT_TAG','trace_id':trace_id})
        if intent_tag=='numeric':
            try:
                result=_arithmetic(question)
            except (ValueError,ZeroDivisionError,OverflowError,SyntaxError,TypeError):
                return self._end(trace_id,{'status':'INSUFFICIENT','reason':'INVALID_NUMERIC_EXPRESSION','trace_id':trace_id})
            answer=f'{result:g}' if isinstance(result,float) else str(result)
            self.audit.append(trace_id,'DETERMINISTIC_MATH',{'expression_sha256':__import__('hashlib').sha256(question.encode()).hexdigest(),'answer':answer})
            return self._end(trace_id,{'status':'DETERMINISTIC_RESULT','trace_id':trace_id,
                    'answer':answer,'method':'safe_arithmetic','methods_planned':methods,
                    'proof_level':'computed_locally'})
        try:
            obs=self.observer.observe(trace_id,intent_tag,question,candidate_cids)
            if not isinstance(obs,dict) or obs.get('status')!='CANDIDATE_OBSERVATION':
                return self._end(trace_id,{'status':'INSUFFICIENT','reason':(obs.get('reason') if isinstance(obs,dict) else 'OBSERVER_INVALID_RESULT'),
                                           'trace_id':trace_id,'observation':obs})
            rel=obs.get('relation')
            if not isinstance(rel,dict) or not isinstance(rel.get('type'),str) or not rel['type']:
                return self._end(trace_id,{'status':'INSUFFICIENT','reason':'OBSERVER_MISSING_RELATION','trace_id':trace_id})
            reference=obs.get('candidate_relation_ref')
            if not isinstance(reference,str) or not reference.startswith('obsrel_'):
                return self._end(trace_id,{'status':'INSUFFICIENT','reason':'RELATION_NOT_TRACEABLE','trace_id':trace_id})
            candidate=(obs.get('composite') or {}).get('definition')
            if not isinstance(candidate,str) or not candidate.strip():
                return self._end(trace_id,{'status':'INSUFFICIENT','reason':'EMPTY_ANSWER_CANDIDATE','trace_id':trace_id,
                                           'candidate_relation_ref':reference})
            claim={'text':question,'claim_type':'inferred','evidence_refs':
                   [rel['evidence_ref']] if rel.get('evidence_ref') else [],'relation_id':reference}
            verdict=self.otfa.verify(claim)
            cores=obs.get('meaning_cores') or []
            names=[str(c.get('cid') or c.get('proposed_surface') or 'unknown') for c in cores if isinstance(c,dict)]
            result={'status':'CANDIDATE','trace_id':trace_id,'intent':intent_tag,
                    'methods_planned':methods,'answer_candidate':candidate,'candidate_relation_ref':reference,
                    'claim':claim,'observation':obs,'otfa':verdict,
                    'ai_recommendation':{'status':'CANDIDATE',
                        'text':f'Explore {rel["type"]} between '+', '.join(names[:2])},
                    'unknowns':(obs.get('provenance') or {}).get('unknowns') or []}
            self.audit.append(trace_id,'ANSWER_CANDIDATE',
                              {'answer_candidate_sha256':__import__('hashlib').sha256(candidate.encode()).hexdigest(),
                               'candidate_relation_ref':reference,'otfa':verdict['overall']})
            return self._end(trace_id,result)
        except Exception:
            return self._end(trace_id,{'status':'INSUFFICIENT','reason':'INTERNAL_PROCESSING_ERROR','trace_id':trace_id})
