"""WGS84 geographic <-> UTM coordinates; height remains vertical-datum qualified.

EPSG:4326 is lat/lon geographic 2D, EPSG:4979 is WGS84 geographic 3D,
EPSG:326xx / 327xx are 2D UTM projected CRS. The added Z is *not* part
of these UTM EPSG identifiers. It is carried unchanged with an explicit
vertical CRS; geoid conversion is never silently performed.
"""
from __future__ import annotations
from functools import lru_cache
import math

WGS84_GEOGRAPHIC = 'EPSG:4326'
WGS84_3D = 'EPSG:4979'
VALID_VERTICAL_CRS = {
    'EPSG:4979': 'WGS84_ellipsoidal_height',
    'EPSG:5773': 'EGM96_geoid_height',
    'EPSG:3855': 'EGM2008_geoid_height',
}


def _num(value, minimum, maximum, name):
    if type(value) not in (float, int) or not math.isfinite(value) or not minimum <= value <= maximum:
        raise ValueError(f'invalid_{name}')
    return float(value)


def require_vertical_crs(z, vertical_crs):
    if z is not None:
        _num(z, -12000, 100000, 'height')
        if vertical_crs not in VALID_VERTICAL_CRS:
            raise ValueError('height_requires_explicit_supported_vertical_crs')
    elif vertical_crs is not None and vertical_crs not in VALID_VERTICAL_CRS:
        raise ValueError('unsupported_vertical_crs')
    return vertical_crs


def utm_zone(lat, lon):
    """UTM standard zone selection incl. Norway/Svalbard exceptions."""
    lat = _num(lat, -80, 84, 'utm_latitude')
    lon = _num(lon, -180, 180, 'longitude')
    zone = min(60, max(1, int((lon + 180) // 6) + 1))
    if 56 <= lat < 64 and 3 <= lon < 12:
        zone = 32
    if 72 <= lat <= 84:
        for start, end, special in ((0,9,31),(9,21,33),(21,33,35),(33,42,37)):
            if start <= lon < end:
                zone = special
                break
    return zone


def utm_epsg(zone, hemisphere='N'):
    if type(zone) is not int or not 1 <= zone <= 60 or hemisphere not in ('N','S'):
        raise ValueError('invalid_utm_zone_or_hemisphere')
    return f'EPSG:{(32600 if hemisphere == "N" else 32700) + zone}'


@lru_cache(maxsize=150)
def _transformer(epsg, direction):
    try:
        from pyproj import Transformer
    except ImportError as exc:
        raise RuntimeError('pyproj_required') from exc
    return Transformer.from_crs('EPSG:4326' if direction == 'forward' else epsg,
                                epsg if direction == 'forward' else 'EPSG:4326',
                                always_xy=True)


def to_utm(lat, lon, z=None, vertical_crs=None, zone=None):
    lat = _num(lat, -80, 84, 'utm_latitude')
    lon = _num(lon, -180, 180, 'longitude')
    if z is not None:
        _num(z, -12000, 100000, 'height')
    require_vertical_crs(z, vertical_crs)
    natural_zone = utm_zone(lat, lon)
    if zone is not None and (type(zone) is not int or zone != natural_zone):
        raise ValueError('utm_zone_outside_area_of_use')
    hemisphere = 'N' if lat >= 0 else 'S'
    epsg = utm_epsg(natural_zone, hemisphere)
    x, y = _transformer(epsg, 'forward').transform(lon, lat, errcheck=True)
    if not all(math.isfinite(v) for v in (x,y)):
        raise ValueError('projected_coordinate_nonfinite')
    return {'lat': lat, 'lon': lon, 'X': x, 'Y': y, 'Z': None if z is None else float(z),
            'utm_zone': natural_zone, 'hemisphere': hemisphere, 'horizontal_crs': epsg,
            'source_crs': WGS84_3D if z is not None and vertical_crs == WGS84_3D else WGS84_GEOGRAPHIC,
            'vertical_crs': vertical_crs if z is not None else None,
            'z_status': 'NOT_PROVIDED' if z is None else 'CARRIED_UNCHANGED_NOT_VERTICAL_TRANSFORMED',
            'horizontal_units': 'metre', 'vertical_units': 'metre',
            'height_is_vertical_transformed': False, 'survey_accuracy': 'NOT_CERTIFIED'}


def from_utm(x, y, zone, hemisphere='N', z=None, vertical_crs=None):
    x = _num(x, -1000000, 3000000, 'easting')
    y = _num(y, -1000000, 12000000, 'northing')
    require_vertical_crs(z, vertical_crs)
    epsg = utm_epsg(zone, hemisphere)
    lon, lat = _transformer(epsg, 'reverse').transform(x, y, errcheck=True)
    if not all(math.isfinite(v) for v in (lon, lat)) or not -80 <= lat <= 84:
        raise ValueError('projected_coordinate_outside_valid_utm_latitude')
    if utm_zone(lat, lon) != zone or ('N' if lat >= 0 else 'S') != hemisphere:
        raise ValueError('utm_coordinate_outside_zone_area_of_use')
    result = to_utm(lat, lon, z, vertical_crs)
    result['X'], result['Y'] = x, y
    return result


def project_geometry(geometry, vertical_crs=None):
    typ = geometry['type']
    positions = ([geometry['coordinates']] if typ == 'Point' else
                 (geometry['coordinates'] if typ == 'LineString' else geometry['coordinates'][0]))
    projected = [to_utm(p[1], p[0], p[2] if len(p) == 3 else None, vertical_crs) for p in positions]
    zones = sorted({p['horizontal_crs'] for p in projected})
    coords = [[p['X'], p['Y']] + ([p['Z']] if p['Z'] is not None else []) for p in projected]
    coords = coords[0] if typ == 'Point' else ([coords] if typ == 'Polygon' else coords)
    return {'type': typ, 'coordinates': coords,
            'horizontal_crs': zones[0] if len(zones) == 1 else None,
            'zone_mode': 'SINGLE_ZONE' if len(zones) == 1 else 'MULTI_ZONE_PER_VERTEX',
            'horizontal_crs_per_vertex': [p['horizontal_crs'] for p in projected],
            'utm_zone_per_vertex': [p['utm_zone'] for p in projected],
            'hemisphere_per_vertex': [p['hemisphere'] for p in projected],
            'vertical_crs': vertical_crs,
            'z_status': 'NOT_PROVIDED' if all(p['Z'] is None for p in projected) else 'CARRIED_UNCHANGED_NOT_VERTICAL_TRANSFORMED',
            'coordinates_are_metric': len(zones) == 1,
            'survey_accuracy': 'NOT_CERTIFIED',
            'note': 'Per-vertex X/Y cannot form a single projected geometry across UTM zones' if len(zones) > 1 else 'Projected metric coordinates; Z is separate vertical reference'}


def dual_csv(source_file, destination_file, *, lat_col='lat', lon_col='lon', z_col='Z', vertical_crs_col='vertical_crs'):
    """Atomic source-to-destination point conversion, never in-place.

    Field-ready metadata only; not field-accuracy certification. Strictly
    requires geodetic WGS84 source columns (decimal degrees).
    """
    import csv
    import os
    import tempfile
    from pathlib import Path
    source=Path(source_file);dest=Path(destination_file)
    if source.resolve()==dest.resolve():raise ValueError('input_output_same_path')
    if not source.is_file() or source.stat().st_size>4*1024*1024:raise ValueError('source_missing_or_over_4mb')
    if dest.exists():raise ValueError('output_exists_no_implicit_overwrite')
    if not dest.parent.is_dir():raise ValueError('destination_parent_missing')
    with source.open('r',encoding='utf-8-sig',newline='') as src:
        reader=csv.DictReader(src)
        if not reader.fieldnames or not {lat_col,lon_col}.issubset(reader.fieldnames):
            raise ValueError('wgs84_lat_lon_columns_required')
        columns=['lat','lon','X','Y','Z','utm_zone','hemisphere','horizontal_crs','vertical_crs','survey_accuracy']
        rows=[]
        for i,row in enumerate(reader,2):
            try:
                lat=float(row[lat_col]);lon=float(row[lon_col])
                rawz=row.get(z_col)
                z=None if rawz in (None,'') else float(rawz)
                vertical_crs=row.get(vertical_crs_col) or None
                p=to_utm(lat,lon,z,vertical_crs)
            except (ValueError,TypeError) as exc:
                raise ValueError(f'csv_line_{i}_invalid') from exc
            rows.append([f'{lat:.8f}',f'{lon:.8f}',f'{p["X"]:.3f}',f'{p["Y"]:.3f}',
                         '' if p['Z'] is None else f'{p["Z"]:.3f}',p['utm_zone'],p['hemisphere'],
                         p['horizontal_crs'],p['vertical_crs'] or '',p['survey_accuracy']])
    # Write to a sibling temp file, then replace new output only after success.
    fd,temp_path=tempfile.mkstemp(prefix='.olgm-utm-',suffix='.csv.tmp',dir=dest.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8-sig',newline='') as output:
            writer=csv.writer(output,lineterminator='\r\n')
            writer.writerow(columns);writer.writerows(rows)
            output.flush();os.fsync(output.fileno())
        # Exclusive create prevents a race that os.replace would otherwise overwrite.
        created=False
        try:
            with dest.open('xb') as final:
                created=True
                with open(temp_path,'rb') as inp:
                    for block in iter(lambda:inp.read(1024*1024),b''):
                        final.write(block)
                final.flush();os.fsync(final.fileno())
        except Exception:
            if created:dest.unlink(missing_ok=True)
            raise
        os.unlink(temp_path)
    except BaseException:
        try:os.unlink(temp_path)
        except FileNotFoundError:pass
        raise
    return {'status':'EXPORTED','points':len(rows),'path':str(dest),
            'horizontal_datum':'WGS84','zone':'AUTO_PER_POINT','survey_accuracy':'NOT_CERTIFIED'}
