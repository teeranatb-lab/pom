"""Read-side adapters and allowlisted local workflows for the OLGM control console.

The UI does not bypass CANTI, create an Origin identity, enable a model, or execute tools.
"""
from __future__ import annotations
import json
import os
import sqlite3
from datetime import datetime,timezone
from .settings import SettingsStore

MODULES = [
 ('overview','ภาพรวมระบบ','Overview','home','main','local'),
 ('thai','ผู้ช่วยภาษาไทย','Thai Assistant','message-circle','main','local'),
 ('intent','Intent Lock','เจตนาและข้อจำกัด','target','meaning','local'),
 ('meaning','Meaning Space','แก่นและเส้นสัมพันธ์','network','meaning','local'),
 ('observer','AI Observer','กลไกสังเกต','eye','meaning','model'),
 ('otfa','OTFA / Evidence','พิสูจน์ข้อเท็จจริง','shield-check','meaning','local'),
 ('origin','Origin & Canonical','อธิปไตยทางปัญญา','landmark','meaning','protected'),
 ('code','Code Studio','สร้าง Python จากรูปแบบ','code','learning','local'),
 ('selflearn','G-06 Self-Learning','เรียนรู้และเสนอแพตช์','brain','learning','local'),
 ('benchmarks','Benchmarks','ประเมินประสิทธิภาพ','chart-no-axes-column','learning','partial'),
 ('gis','BigMap ↔ Meaning Space','WGS84 Lat/Lon + UTM XYZ + CID','map','learning','partial'),
 ('multimodal','Multimodal','ภาพและเสียง','image','learning','partial'),
 ('control','Control Plane','คุมทรัพยากรและสิทธิ์','blocks','operations','local'),
 ('computers','Computer Access','เครื่องและหน้าจอ','monitor','operations','bridge'),
 ('plugins','Plugins','เครื่องมือเชื่อมต่อ','plug','operations','bridge'),
 ('spaces','Spaces','พื้นที่ข้อมูลและหน้า','layers','operations','bridge'),
 ('skills','Skills Catalog','ชุดทักษะใช้งาน','wand-sparkles','operations','local'),
 ('queue','Work Queue','งานและการอนุมัติ','list-todo','operations','local'),
 ('canti','CANTI & Approvals','สิทธิ์และคำสั่ง','lock-keyhole','operations','local'),
 ('valueguard','ValueGuard','เกณฑ์เกินล้านบาท','gem','governance','local'),
 ('s10','S-10 Release Gate','Production Acceptance','badge-check','governance','partial'),
 ('audit','Audit & Provenance','บันทึกและความถูกต้อง','scroll-text','governance','local'),
 ('models','Model Gateway','Ollama / API','cpu','governance','model'),
 ('backup','Backup / Restore','การสำรองและกู้คืน','hard-drive','governance','partial'),
 ('settings','การตั้งค่าทุกระดับ','Settings','sliders-horizontal','governance','local'),
]
MODULE_BY_KEY={m[0]:dict(key=m[0],title=m[1],subtitle=m[2],icon=m[3],group=m[4],kind=m[5]) for m in MODULES}
GROUPS={'main':'พื้นที่ทำงาน','meaning':'อธิปไตยและความหมาย','learning':'การเรียนรู้และสร้างสรรค์',
        'operations':'เครื่องมือและการปฏิบัติ','governance':'กำกับและตั้งค่า'}

# Whitelisted views only. No raw arbitrary SQL from the network, and no personal records.
DATASETS={
 'intent':('intent_events',('intent_id','revision','task_type','statement','created_at')),
 'meaning':('meaning_cores',('cid','language','surface_form','definition','revision','created_at')),
 'otfa':('evidence',('evidence_ref','source_type','source_url','license','retrieved_at')),
 'origin':('canonical_events',('seq','reason','state_hash','created_at')),
 'selflearn':('audit_chain',('seq','event_type','created_at')),
 'control':('access_resources',('resource_id','kind','display_name','provider','connection_state','recorded_at')),
 'computers':('access_resources',('resource_id','display_name','provider','connection_state','recorded_at')),
 'plugins':('access_resources',('resource_id','display_name','provider','connection_state','recorded_at')),
 'spaces':('access_resources',('resource_id','display_name','provider','connection_state','recorded_at')),
 'skills':('access_resources',('resource_id','display_name','provider','connection_state','recorded_at')),
 'queue':('control_plans',('plan_id','resource_id','action','state','priority','created_at')),
 'canti':('permissions',('grant_id','action_scope','resource','granted_at','expires_at','revoked_at')),
 'valueguard':('value_cases',('case_id','forecast_thb','channel','created_at')),
 'audit':('audit_chain',('seq','event_type','trace_id','created_at')),
}
RESOURCE_FILTER={'computers':'computer','plugins':'plugin','spaces':'space','skills':'skill'}

class ConsoleService:
    def __init__(self,db_path,rt):
        self.db_path=str(db_path);self.rt=rt
        self.settings=SettingsStore(db_path,audit=rt.audit)
        from olgm.control.registry import ResourceRegistry
        from olgm.control.plane import ControlPlane
        from olgm.valueguard.policy import ValueGuard
        self.registry=ResourceRegistry(db_path)
        self.control=ControlPlane(db_path,self.registry,rt.intent,rt.canti,rt.signatures,rt.audit)
        self.valueguard=ValueGuard(db_path,audit=rt.audit)
        from olgm.gpt_skills import GPTSkillStudy
        self.gpt_skills=GPTSkillStudy(db_path,audit=rt.audit,signatures=rt.signatures)
        self.gpt_skills.import_snapshot()

    def _db(self):
        db=sqlite3.connect(self.db_path,timeout=10)
        db.row_factory=sqlite3.Row
        return db
    def _count(self,table):
        # All table names are hardcoded below; never interpolate client input.
        with self._db() as db:
            if not db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone():
                return None
            return db.execute('SELECT COUNT(*) FROM '+table).fetchone()[0]
    def _dataset(self,key,limit=45):
        if key not in DATASETS:return []
        table,cols=DATASETS[key]
        with self._db() as db:
            if not db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone():return []
            query='SELECT '+','.join(cols)+' FROM '+table
            args=[]
            if key in RESOURCE_FILTER:query+=' WHERE kind=?';args.append(RESOURCE_FILTER[key])
            if key=='selflearn':query+=" WHERE event_type LIKE 'G06%' OR event_type LIKE 'STRUCTURAL%' OR event_type LIKE '%LEARN%'"
            sort='seq' if key in ('audit','selflearn','origin') else 'created_at' if 'created_at' in cols else 'recorded_at' if 'recorded_at' in cols else 'granted_at' if 'granted_at' in cols else 'retrieved_at' if 'retrieved_at' in cols else None
            if sort:query+=' ORDER BY '+sort+' DESC'
            query+=' LIMIT ?';args.append(max(1,min(int(limit),100)))
            rows=db.execute(query,tuple(args)).fetchall()
        return [dict(r) for r in rows]
    def _connection(self,key,rows):
        if key in ('computers','plugins','spaces'):
            if not rows:return 'NOT_CONNECTED'
            if all(r.get('connection_state')!='CONNECTED' for r in rows):return 'NOT_CONNECTED'
            return 'DECLARED_CONNECTED_NOT_LIVE_VERIFIED'
        if key in ('observer','models'):
            provider=os.getenv('OLGM_MODEL_PROVIDER','disabled')
            return 'DISABLED' if provider=='disabled' else 'CONFIGURED_NOT_TESTED'
        if key in ('gis','multimodal','benchmarks','backup'):
            return 'PARTIAL_NOT_LIVE_VERIFIED'
        if key=='s10':return 'NOT_PASSED'
        if key=='origin':return 'PROTECTED_READ_ONLY'
        return 'LOCAL_AVAILABLE'
    def overview(self):
        counts={
         'cores':self._count('meaning_cores'), 'relations':self._count('semantic_edges'),
         'intent_events':self._count('intent_events'), 'evidence':self._count('evidence'),
         'audit_events':self._count('audit_chain'), 'resources':self._count('access_resources'),
         'control_plans':self._count('control_plans'), 'value_cases':self._count('value_cases'),
         'thai_examples':self._count('thai_examples')}
        try: audit_ok, audit_msg=self.rt.audit.verify()
        except (sqlite3.Error,OSError,ValueError) as ex:audit_ok=False;audit_msg=type(ex).__name__
        try: canonical=self.rt.canonical.verify()
        except (sqlite3.Error,ValueError) as ex:canonical={'status':'FAIL','reason':type(ex).__name__}
        try:settings=self.settings.verify()
        except (sqlite3.Error,ValueError) as ex:settings={'status':'FAIL','reason':type(ex).__name__}
        return {'counts':counts,'audit':{'status':'PASS' if audit_ok else 'FAIL','detail':audit_msg},
                'canonical':canonical,'ui_settings':settings,
                'model_provider':('disabled' if os.getenv('OLGM_MODEL_PROVIDER','disabled')=='disabled' else 'configured_not_live_verified'),
                'origin_email':'teeranat.b@gmail.com','s10':'NOT_PASSED',
                'control_live_connections_verified':False,
                'recorded_at':datetime.now(timezone.utc).isoformat()}
    def module(self,key):
        if key not in MODULE_BY_KEY:raise KeyError('unknown_module')
        rows=self._dataset(key)
        result={'module':MODULE_BY_KEY[key],'connection':self._connection(key,rows), 'records':rows,
                'count':len(rows),'is_truncated':len(rows)==45,
                'caveat':'UI ไม่ให้สิทธิ์เข้าถึงหรืออนุมัติ Runtime ด้วยตนเอง; สถานะจากทะเบียนไม่ใช่ผลการเชื่อมต่อสด'}
        if key=='meaning':
            with self._db() as db:
                edges=db.execute('SELECT edge_id,source_cid,target_cid,relation_type,verification_status FROM semantic_edges ORDER BY created_at DESC LIMIT 60').fetchall()
                cores=db.execute('SELECT cid,surface_form,semantic_coordinates FROM meaning_cores ORDER BY created_at DESC LIMIT 70').fetchall()
            result['graph']={'cores':[dict(x) for x in cores],'edges':[dict(x) for x in edges]}
        elif key=='skills':
            from olgm.control.skills import BuiltinSkillExecutor
            result['skills_catalog']=BuiltinSkillExecutor.catalog()
            result['gpt_skills']=self.gpt_skills.catalog(limit=100)
            result['learning_summary']=self.gpt_skills.learning_summary()
        elif key=='code':
            from olgm.thai.codegen import PATTERNS
            result['patterns']=[{'key':p.key,'description_th':p.description_th} for p in PATTERNS.values()]
        elif key=='thai':
            from olgm.thai.patterns import stats
            result['pattern_stats']=stats()
        elif key=='s10':
            from olgm.s10 import RELEASE_GATES
            result['gates']=[{'id':g[0],'title':g[1],'references':g[2],'status':'NOT_PASSED'} for g in RELEASE_GATES]
        elif key=='valueguard':
            from olgm.valueguard.policy import THRESHOLD_THB,OWNER_EMAIL
            result['policy']={'threshold_thb':str(THRESHOLD_THB),'owner_email':OWNER_EMAIL,'status':'STAGING_NOT_LIVE'}
        elif key=='origin':
            result['canonical_verification']=self.rt.canonical.verify()
        elif key=='audit':
            try:ok,msg=self.rt.audit.verify();result['verification']={'status':'PASS' if ok else 'FAIL','message':msg}
            except sqlite3.Error as exc:result['verification']={'status':'FAIL','message':type(exc).__name__}
        return result
    def thai_answer(self,question):
        if not isinstance(question,str) or not question.strip() or len(question)>2500:raise ValueError('question_required_max_2500')
        from olgm.thai.learning import ThaiExampleMemory
        from olgm.thai.lexicon import ThaiLexicon
        from olgm.thai.responder import ThaiResponder
        memory=ThaiExampleMemory(self.db_path)
        lexicon=ThaiLexicon(self.rt.ms,self.rt.canti,self.rt.audit)
        return ThaiResponder(memory,lexicon=lexicon).answer(question.strip())
    def code(self,request='',pattern='',key=None,size=2,page=1,value=None):
        from olgm.thai.codegen import SafeCodeGenerator
        g=SafeCodeGenerator()
        if pattern:
            return g.render(pattern,key=key,size=int(size),page=int(page),value=value,origin_ref='ui:local-pattern-candidate')
        if not request or not isinstance(request,str) or len(request)>2000:raise ValueError('request_required_max_2000')
        s=g.select(request)
        if s['status']!='MATCHED':return s
        return g.render(s['pattern'],origin_ref='ui:local-pattern-candidate')
    def create_intent(self,statement,actor,task_type='CHAT'):
        if not isinstance(statement,str) or not 1<=len(statement.strip())<=2000:raise ValueError('intent_statement_required_max_2000')
        if task_type not in ('CHAT','WORK'):raise ValueError('invalid_task_type')
        return self.rt.intent.create(actor=actor,origin_ref='ui:origin_not_identity_verified',
                                     statement=statement.strip(),task_type=task_type)
    def propose_control(self,form,actor):
        required=('intent_id','intent_hash','resource_id','action')
        if any(not isinstance(form.get(k),str) or not form.get(k) for k in required):raise ValueError('missing_control_plan_fields')
        import uuid
        return self.control.propose(form['intent_id'],form['intent_hash'],form['resource_id'],form['action'],
                                    form.get('args') or {},requested_by=actor,idempotency_key=str(uuid.uuid4()))
    def register_resource(self,form):
        required=('resource_id','kind','display_name','provider','source_ref')
        if any(not isinstance(form.get(k),str) or not form.get(k) for k in required):raise ValueError('missing_resource_metadata')
        if form.get('connection_state','NOT_CONNECTED')!='NOT_CONNECTED':
            raise PermissionError('ui_cannot_claim_connected')
        return self.registry.register(form['resource_id'],form['kind'],form['display_name'],form['provider'],
                                      form.get('actions') or [],form.get('classification','INTERNAL'),
                                      ownership_ref='ui:ownership_not_verified',source_ref=form['source_ref'],
                                      connection_state='NOT_CONNECTED',targets=form.get('targets') or [])

    def skill_match(self,question):
        return self.gpt_skills.recommend(question,limit=8)

    def skill_lesson_candidate(self,body,actor):
        return self.gpt_skills.propose_lesson(
            body.get('uri'),body.get('example_text'),body.get('source_ref'),
            body.get('origin_ref'),body.get('rights_basis','UNKNOWN'),actor)
