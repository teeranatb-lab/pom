"""Append-only UI configuration inheritance. No Origin authority or production release here."""
from __future__ import annotations
import hashlib
import json
import sqlite3
from datetime import datetime, timezone


def utc(): return datetime.now(timezone.utc).isoformat()
def canonical(x): return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
def digest(x): return hashlib.sha256(canonical(x).encode()).hexdigest()

# key, Thai label, category, kind, default, choices/min/max, risk
_SPEC = [
 ('appearance.theme','โหมดสี','appearance','select','dark',['dark','light','system'],'safe'),
 ('appearance.accent','สีเน้น','appearance','select','violet',['violet','teal','blue','amber'],'safe'),
 ('appearance.density','ความหนาแน่น','appearance','select','comfortable',['comfortable','compact'],'safe'),
 ('appearance.font_scale','ขนาดตัวอักษร (%)','appearance','number',100,[85,125],'safe'),
 ('appearance.sidebar_collapsed','ย่อเมนูด้านข้าง','appearance','boolean',False,None,'safe'),
 ('appearance.reduce_motion','ลดภาพเคลื่อนไหว','appearance','boolean',False,None,'safe'),
 ('appearance.show_tooltips','แสดงคำอธิบาย','appearance','boolean',True,None,'safe'),
 ('appearance.homepage','หน้าเริ่มต้น','appearance','select','overview',['overview','thai','intent','meaning','control','settings'],'safe'),
 ('language.interface','ภาษาหน้าจอ','language','select','th',['th','en'],'safe'),
 ('language.answer','ภาษาที่ใช้ตอบ','language','select','th',['th','en','auto'],'safe'),
 ('language.thai_normalize','ปรับ Unicode ภาษาไทย','language','boolean',True,None,'safe'),
 ('language.show_provenance','แสดงที่มาคำตอบ','language','boolean',True,None,'safe'),
 ('language.warn_unknowns','แสดงสิ่งที่ยังไม่ทราบ','language','boolean',True,None,'safe'),
 ('workflow.default_task','ประเภทงานเริ่มต้น','workflow','select','CHAT',['CHAT','WORK'],'safe'),
 ('workflow.confirm_before_write','ยืนยันก่อนเขียนข้อมูล','workflow','boolean',True,None,'restricted'),
 ('workflow.queue_limit','จำนวนงานแสดงต่อหน้า','workflow','number',20,[5,100],'safe'),
 ('workflow.notify_on_hold','แจ้งเมื่อถูกพักงาน','workflow','boolean',True,None,'safe'),
 ('workflow.history_limit','จำนวนเหตุการณ์แสดง','workflow','number',30,[10,100],'safe'),
 ('meaning.graph_labels','แสดงชื่อบนกราฟ','meaning','boolean',True,None,'safe'),
 ('meaning.graph_max_nodes','จำนวนแก่นบนกราฟ','meaning','number',30,[8,80],'safe'),
 ('meaning.show_coordinates','แสดงพิกัดความหมาย','meaning','boolean',False,None,'safe'),
 ('meaning.preserve_cid','รักษา CID เดิมเสมอ','meaning','boolean',True,None,'locked'),
 ('meaning.allow_silent_replace','อนุญาตเขียนทับความหมายแบบเงียบ','meaning','boolean',False,None,'locked'),
 ('verification.show_three_planes','แสดงการพิสูจน์ 3 ระนาบ','verification','boolean',True,None,'safe'),
 ('verification.require_evidence','ต้องมีหลักฐานก่อนรับรอง','verification','boolean',True,None,'locked'),
 ('verification.show_rejected_paths','แสดงเส้นทางที่ปฏิเสธ','verification','boolean',True,None,'safe'),
 ('verification.s10_requires_external','ต้องมีหลักฐานภายนอกก่อน S-10 PASS','verification','boolean',True,None,'locked'),
 ('models.preferred_provider','Provider ที่ต้องการ','models','select','disabled',['disabled','ollama','openai'],'restricted'),
 ('models.default_temperature','ค่า Temperature ที่เสนอ','models','number',0.2,[0,1],'restricted'),
 ('models.external_egress','เปิดส่งข้อมูลออกภายนอก','models','boolean',False,None,'locked'),
 ('models.offline_first','ใช้ Local ก่อน','models','boolean',True,None,'safe'),
 ('control.default_deny','ปฏิเสธการดำเนินการหากไม่มีสิทธิ์','control','boolean',True,None,'locked'),
 ('control.require_signed_approval','ต้องลงนามก่อนปฏิบัติการ','control','boolean',True,None,'locked'),
 ('control.show_connection_states','แสดงสถานะ Connector','control','boolean',True,None,'safe'),
 ('control.queue_autorun','ให้คิวดำเนินการเอง','control','boolean',False,None,'restricted'),
 ('control.computer_click_enabled','เปิดการคลิกเครื่องจริง','control','boolean',False,None,'locked'),
 ('control.space_write_enabled','เปิดเขียน Space จริง','control','boolean',False,None,'locked'),
 ('security.session_minutes','เวลา Session (นาที)','security','number',60,[15,180],'restricted'),
 ('security.audit_required','บันทึก Audit ทุกการเปลี่ยนแปลง','security','boolean',True,None,'locked'),
 ('security.mask_personal_data','ปิดบังข้อมูลส่วนบุคคล','security','boolean',True,None,'locked'),
 ('security.canonical_read_only','Canonical / Archive ห้ามเขียนทับ','security','boolean',True,None,'locked'),
 ('security.core0_no_api','Core 0 ไม่มี API ให้แก้ไข','security','boolean',True,None,'locked'),
 ('security.enable_remote_ui','เปิด UI ให้เข้าถึงจาก WAN','security','boolean',False,None,'locked'),
 ('valueguard.threshold_thb','เกณฑ์แจ้งมูลค่า (บาท)','valueguard','number',1000000,[1000000,1000000],'locked'),
 ('valueguard.origin_email','อีเมล Origin','valueguard','text','teeranat.b@gmail.com',None,'locked'),
 ('valueguard.owner_first','แจ้ง Origin ก่อนผู้ใช้ภายนอก','valueguard','boolean',True,None,'locked'),
 ('valueguard.show_forecast_disclaimer','ระบุมูลค่าเป็นเพียงประมาณการ','valueguard','boolean',True,None,'locked'),
 ('notifications.desktop','การแจ้งเตือนบนหน้าจอ','notifications','boolean',True,None,'safe'),
 ('notifications.sound','เสียงแจ้งเตือน','notifications','boolean',False,None,'safe'),
 ('notifications.show_high_value','แสดงกรณี ValueGuard','notifications','boolean',True,None,'safe'),
 ('backup.show_backup_status','แสดงสถานะสำรองข้อมูล','backup','boolean',True,None,'safe'),
 ('backup.verify_before_restore','ตรวจไฟล์ก่อนกู้คืน','backup','boolean',True,None,'locked'),
 ('backup.target_directory','โฟลเดอร์สำรองที่ต้องการ (ข้อเสนอ)','backup','text','',None,'restricted'),
]

SPEC = {k: dict(key=k,label=label,category=category,type=kind,default=default,choices=opts if kind=='select' else None,
                minimum=(opts[0] if kind=='number' else None),maximum=(opts[1] if kind=='number' else None),risk=risk,
                description=('นโยบายล็อก ไม่สามารถเปลี่ยนจาก UI' if risk=='locked' else
                             'คำขอเปลี่ยนต้องผ่านการตรวจรับ Origin ก่อนนำไปใช้' if risk=='restricted' else
                             'การตั้งค่า UI/Workflow เท่านั้น ไม่ยกระดับสิทธิ์ Runtime'))
        for k,label,category,kind,default,opts,risk in _SPEC}

CATEGORY_LABELS = {
 'appearance':'รูปลักษณ์','language':'ภาษาและคำตอบ','workflow':'กระบวนงาน',
 'meaning':'Meaning Space','verification':'การพิสูจน์','models':'โมเดลและการเชื่อมต่อ',
 'control':'การควบคุม','security':'ความปลอดภัย','valueguard':'ValueGuard',
 'notifications':'การแจ้งเตือน','backup':'สำรองและกู้คืน'
}

class SettingsStore:
    """Append-only events; explicit actor and optimistic revision. Risky changes are proposals only."""
    def __init__(self, db_path, audit=None):
        self.path=str(db_path);self.audit=audit
        with self._db() as db:
            db.executescript('''
             CREATE TABLE IF NOT EXISTS ui_setting_events(
              seq INTEGER PRIMARY KEY AUTOINCREMENT,
              scope TEXT NOT NULL, scope_id TEXT NOT NULL, key TEXT NOT NULL,
              value_json TEXT, operation TEXT NOT NULL CHECK(operation IN ('set','inherit')),
              state TEXT NOT NULL CHECK(state IN ('APPLIED','AWAITING_ORIGIN')),
              actor TEXT NOT NULL, reason TEXT NOT NULL,
              parent_hash TEXT NOT NULL, self_hash TEXT NOT NULL,
              created_at TEXT NOT NULL
             );
             CREATE INDEX IF NOT EXISTS ix_ui_settings_scope ON ui_setting_events(scope,scope_id,key,seq);
            ''')
    def _db(self):
        db=sqlite3.connect(self.path,timeout=12)
        db.row_factory=sqlite3.Row
        db.execute('PRAGMA busy_timeout=12000')
        return db
    @staticmethod
    def _validate(key,val):
        if key not in SPEC: raise ValueError('unknown_setting_key')
        s=SPEC[key];t=s['type']
        if t=='boolean' and type(val) is not bool: raise ValueError('expected_boolean')
        if t=='number' and (type(val) not in (int,float) or not s['minimum']<=val<=s['maximum']): raise ValueError('number_out_of_range')
        if t=='select' and val not in s['choices']: raise ValueError('invalid_choice')
        if t=='text' and (not isinstance(val,str) or len(val)>160 or '\x00' in val):raise ValueError('invalid_text')
        return s
    @staticmethod
    def _authorize(scope,scope_id,role,user_id):
        if scope not in ('workspace','role','user'):raise PermissionError('scope_not_allowed')
        if role not in ('admin','operator','viewer'): raise PermissionError('unsupported_ui_role')
        if scope=='user':
            if scope_id!=user_id:raise PermissionError('can_only_edit_own_user_settings')
        elif role!='admin':raise PermissionError('workspace_and_role_scope_require_admin')
        if scope=='workspace' and scope_id!='default':raise PermissionError('only_default_workspace_available')
        if scope=='role' and scope_id not in ('admin','operator','viewer'):raise PermissionError('invalid_role_scope')
    def _rows(self):
        with self._db() as db:
            return [dict(r) for r in db.execute('SELECT * FROM ui_setting_events ORDER BY seq').fetchall()]
    def history(self,limit=50):
        with self._db() as db:
            rows=db.execute('''SELECT seq,scope,scope_id,key,operation,state,actor,reason,created_at,self_hash
                                FROM ui_setting_events ORDER BY seq DESC LIMIT ?''',(min(max(int(limit),1),200),)).fetchall()
        return [dict(r) for r in rows]
    def verify(self):
        prev='0'*64
        for r in self._rows():
            if r['parent_hash']!=prev:return {'status':'FAIL','at':r['seq'],'reason':'parent_hash_mismatch'}
            payload={k:r[k] for k in ('seq','scope','scope_id','key','value_json','operation','state','actor','reason','created_at','parent_hash')}
            if digest(payload)!=r['self_hash']:return {'status':'FAIL','at':r['seq'],'reason':'event_hash_mismatch'}
            prev=r['self_hash']
        return {'status':'PASS','events':len(self._rows()),'head_hash':prev}
    def _active(self):
        entries={}
        for r in self._rows():
            if r['state']=='APPLIED':entries[(r['scope'],r['scope_id'],r['key'])]=r
        return entries
    def effective(self,role,user_id):
        active=self._active()
        result={}
        for k,s in SPEC.items():
            value=s['default'];source='default';seq=0
            for scope,scid in [('workspace','default'),('role',role),('user',user_id)]:
                event=active.get((scope,scid,k))
                if event and event['operation']=='set':
                    value=json.loads(event['value_json']);source=scope;seq=event['seq']
                # inherit removes only this layer; preserve inherited lower levels
            result[k]={'value':value,'source':source,'revision':seq,'risk':s['risk']}
        return result
    def view(self,role,user_id,scope='user',scope_id=None):
        scope_id=scope_id or (user_id if scope=='user' else role if scope=='role' else 'default')
        if scope!='user' and role!='admin':
            # Read-only effective view for nonadmin; not raw settings of another user.
            scope='user';scope_id=user_id
        if scope=='user' and scope_id!=user_id:
            raise PermissionError('cannot_read_other_user_settings')
        active=self._active();eff=self.effective(role,user_id)
        overrides={}
        for k in SPEC:
            row=active.get((scope,scope_id,k))
            overrides[k]={'value':json.loads(row['value_json']) if row and row['operation']=='set' else None,
                          'revision':row['seq'] if row else 0,'mode':row['operation'] if row else 'inherit'}
        return {'schema':list(SPEC.values()),'categories':CATEGORY_LABELS,'scope':scope,'scope_id':scope_id,
                'role':role,'user_id':user_id,'effective':eff,'overrides':overrides,
                'history':self.history(30),'integrity':self.verify()}
    def _append(self,scope,scope_id,key,value,op,state,actor,reason,expected_revision):
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            latest=db.execute('''SELECT seq FROM ui_setting_events WHERE scope=? AND scope_id=? AND key=?
                                 AND state='APPLIED' ORDER BY seq DESC LIMIT 1''',(scope,scope_id,key)).fetchone()
            actual=latest['seq'] if latest else 0
            if actual!=expected_revision:raise ValueError('STALE_SETTING_RELOAD_REQUIRED')
            prev=db.execute('SELECT self_hash FROM ui_setting_events ORDER BY seq DESC LIMIT 1').fetchone()
            parent=prev['self_hash'] if prev else '0'*64
            when=utc(); vj=canonical(value) if op=='set' else None
            cur=db.execute('''INSERT INTO ui_setting_events(scope,scope_id,key,value_json,operation,state,actor,reason,parent_hash,self_hash,created_at)
                              VALUES(?,?,?,?,?,?,?,?,?,?,?)''',(scope,scope_id,key,vj,op,state,actor,reason,parent,'PENDING',when))
            seq=cur.lastrowid
            payload=dict(seq=seq,scope=scope,scope_id=scope_id,key=key,value_json=vj,operation=op,state=state,
                         actor=actor,reason=reason,created_at=when,parent_hash=parent)
            h=digest(payload)
            db.execute('UPDATE ui_setting_events SET self_hash=? WHERE seq=?',(h,seq))
        if self.audit:self.audit.append('ui-setting-'+str(seq),'UI_SETTING_EVENT',{'seq':seq,'scope':scope,'key':key,'state':state,'hash':h})
        return {'status':state,'seq':seq,'event_hash':h,'key':key,'scope':scope}
    def change(self,scope,scope_id,key,value,actor,role,user_id,reason,expected_revision=0):
        self._authorize(scope,scope_id,role,user_id)
        s=self._validate(key,value)
        if s['risk']=='locked':raise PermissionError('immutable_policy_cannot_be_changed_from_ui')
        if not isinstance(reason,str) or not reason.strip() or len(reason)>400:raise ValueError('reason_required_max_400')
        state='AWAITING_ORIGIN' if s['risk']=='restricted' else 'APPLIED'
        return self._append(scope,scope_id,key,value,'set',state,actor,reason,int(expected_revision))
    def reset(self,scope,scope_id,key,actor,role,user_id,reason,expected_revision=0):
        self._authorize(scope,scope_id,role,user_id)
        if key not in SPEC:raise ValueError('unknown_setting_key')
        if SPEC[key]['risk']=='locked':raise PermissionError('immutable_policy_cannot_be_changed_from_ui')
        if not isinstance(reason,str) or not reason.strip():raise ValueError('reason_required')
        state='AWAITING_ORIGIN' if SPEC[key]['risk']=='restricted' else 'APPLIED'
        return self._append(scope,scope_id,key,None,'inherit',state,actor,reason,int(expected_revision))
    def rollback(self,seq,actor,role,user_id,reason,expected_revision):
        with self._db() as db:
            r=db.execute('SELECT * FROM ui_setting_events WHERE seq=?',(int(seq),)).fetchone()
            if not r:raise ValueError('event_not_found')
            r=dict(r)
            old=db.execute("SELECT * FROM ui_setting_events WHERE scope=? AND scope_id=? AND key=? AND seq<? AND state='APPLIED' ORDER BY seq DESC LIMIT 1",
                 (r['scope'],r['scope_id'],r['key'],r['seq'])).fetchone()
        self._authorize(r['scope'],r['scope_id'],role,user_id)
        if r['state']!='APPLIED':raise ValueError('cannot_rollback_unapproved_proposal')
        # Restore the state prior to the selected event; append a new event, never overwrite.
        if old and old['operation']=='set':
            return self.change(r['scope'],r['scope_id'],r['key'],json.loads(old['value_json']),
                               actor,role,user_id,reason,int(expected_revision))
        return self.reset(r['scope'],r['scope_id'],r['key'],actor,role,user_id,reason,int(expected_revision))
