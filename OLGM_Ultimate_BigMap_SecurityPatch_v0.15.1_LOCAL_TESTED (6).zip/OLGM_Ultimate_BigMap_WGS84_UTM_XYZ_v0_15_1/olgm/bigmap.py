"""BigMap ↔ Meaning Space bridge (WGS84 geography != semantic (x,y,z)).

Immutable feature IDs, append-only geometry revisions, candidate-only semantic links,
independent provenance, and offline spatial queries. No implicit Core 0 access,
Origin impersonation, canonical writes or external GIS services.

GeoJSON coordinates use [longitude, latitude]; UI/CSV use latitude,longitude.
Distances are approximate geodesic computations and never survey certifications.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from .utm_wgs84 import project_geometry, require_vertical_crs, from_utm

WGS84 = 'EPSG:4326'
RADIUS_M = 6371008.8
KINDS = {'Point', 'LineString', 'Polygon'}
ZERO = '0' * 64
MAX_VERTICES = 5000
MAX_IMPORTED_FEATURES = 2000


def now():
    return datetime.now(timezone.utc).isoformat()


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def sha256(value: str) -> str:
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def _numeric(v, low, high, label):
    if type(v) not in (float, int) or not math.isfinite(v) or not low <= v <= high:
        raise ValueError(f'{label}_invalid_or_out_of_range')
    return float(v)


def _pos(pt):
    if not isinstance(pt, (list, tuple)) or len(pt) not in (2, 3):
        raise ValueError('GeoJSON_position_must_be_lon_lat_or_lon_lat_height')
    lon = _numeric(pt[0], -180, 180, 'lon')
    lat = _numeric(pt[1], -90, 90, 'lat')
    result = [lon, lat]
    if len(pt) == 3:
        # Height has no assumed vertical datum. Metadata must describe any meaning.
        result.append(_numeric(pt[2], -12000, 100000, 'height'))
    return result


def _distinct_horizontal(points):
    return len({tuple(p[:2]) for p in points})


def _crosses(a, b, c, d):
    def orientation(p, q, r):
        v = (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0])
        return 0 if abs(v) < 1e-12 else (1 if v > 0 else -1)
    # Reject proper crossings; touching on nonadjacent edges is also disallowed.
    def on_segment(p, q, r):
        return min(p[0],r[0])-1e-12 <= q[0] <= max(p[0],r[0])+1e-12 and min(p[1],r[1])-1e-12 <= q[1] <= max(p[1],r[1])+1e-12
    o1,o2,o3,o4 = orientation(a,b,c),orientation(a,b,d),orientation(c,d,a),orientation(c,d,b)
    if o1 != o2 and o3 != o4: return True
    return ((o1==0 and on_segment(a,c,b)) or (o2==0 and on_segment(a,d,b))
            or (o3==0 and on_segment(c,a,d)) or (o4==0 and on_segment(c,b,d)))


def validate_geometry(geometry):
    """Allow point, simple line and single-ring polygon; reject malformed input.

    Polygons need an explicitly closed ring. Complex holes and multi-polygons are
    intentionally unsupported rather than silently discarded.
    """
    if not isinstance(geometry, dict) or geometry.get('type') not in KINDS:
        raise ValueError('unsupported_geometry_type')
    typ = geometry['type']; raw = geometry.get('coordinates')
    if typ == 'Point':
        coords = _pos(raw)
    elif typ == 'LineString':
        if not isinstance(raw, list) or not 2 <= len(raw) <= MAX_VERTICES:
            raise ValueError('line_must_have_2_to_5000_vertices')
        coords = [_pos(p) for p in raw]
        if _distinct_horizontal(coords) < 2:
            raise ValueError('line_requires_two_distinct_positions')
    else:
        if not isinstance(raw, list) or len(raw) != 1 or not isinstance(raw[0], list):
            raise ValueError('polygon_single_outer_ring_only')
        if not 4 <= len(raw[0]) <= MAX_VERTICES:
            raise ValueError('polygon_ring_length_invalid')
        ring = [_pos(p) for p in raw[0]]
        if ring[0][:2] != ring[-1][:2] or _distinct_horizontal(ring[:-1]) < 3:
            raise ValueError('polygon_must_be_closed_with_three_distinct_vertices')
        for i in range(len(ring)-1):
            if ring[i][:2] == ring[i+1][:2]:
                raise ValueError('zero_length_polygon_edge')
        if max(p[0] for p in ring) - min(p[0] for p in ring) > 180:
            raise ValueError('polygon_crossing_antimeridian_not_supported')
        # Edges that do not share a vertex must not intersect.
        for i in range(len(ring)-1):
            for j in range(i+2, len(ring)-1):
                if i == 0 and j == len(ring)-2: continue
                if _crosses(ring[i],ring[i+1],ring[j],ring[j+1]):
                    raise ValueError('polygon_self_intersection')
        coords = [ring]
    geom = {'type':typ, 'coordinates':coords}
    if len({len(p) for p in _positions(geom)}) > 1:
        raise ValueError('mixed_2d_3d_coordinates_not_supported')
    return geom


def _positions(geometry):
    typ = geometry['type']; v=geometry['coordinates']
    return [v] if typ=='Point' else (v if typ=='LineString' else v[0])


def haversine_m(a, b):
    lat1,lat2=math.radians(a[1]),math.radians(b[1])
    dlat=lat2-lat1; dlon=math.radians(b[0]-a[0])
    x=math.sin(dlat/2)**2+math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2
    return RADIUS_M*2*math.asin(min(1,math.sqrt(x)))


def geometry_metrics(geometry):
    """Informational spherical metrics; no survey-precision claim."""
    typ=geometry['type']; pos=_positions(geometry)
    lons=[p[0] for p in pos];lats=[p[1] for p in pos]
    bbox=[min(lons),min(lats),max(lons),max(lats)]
    length=sum(haversine_m(a,b) for a,b in zip(pos,pos[1:])) if typ!='Point' else 0.0
    area=0.0
    if typ=='Polygon':
        for a,b in zip(pos,pos[1:]):
            dl=math.radians(b[0]-a[0])
            area += dl*(2+math.sin(math.radians(a[1]))+math.sin(math.radians(b[1])))
        area=abs(area)*RADIUS_M*RADIUS_M/2
    return {'bbox_lonlat':bbox, 'vertex_count':len(pos), 'length_m_approx':round(length,3),
            'area_m2_approx':round(area,3), 'method':'spherical_approximation',
            'survey_accuracy':'NOT_CERTIFIED'}


class BigMapMeaning:
    """Data-plane bridge. `origin_ref` is *provenance*, never proof of Origin identity."""
    def __init__(self, db_path, meaning_space=None, audit=None):
        self.db_path=str(db_path);self.ms=meaning_space;self.audit=audit
        with self._db() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS bigmap_features (
                feature_id TEXT PRIMARY KEY,
                kind TEXT NOT NULL CHECK(kind IN ('Point','LineString','Polygon')),
                label TEXT NOT NULL,
                origin_ref TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                classification TEXT NOT NULL DEFAULT 'INTERNAL',
                created_by TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS bigmap_feature_revisions (
                feature_id TEXT NOT NULL,
                revision INTEGER NOT NULL,
                geometry_json TEXT NOT NULL,
                geometry_hash TEXT NOT NULL,
                prev_hash TEXT NOT NULL,
                record_hash TEXT NOT NULL,
                reason TEXT NOT NULL,
                recorded_by TEXT NOT NULL,
                created_at TEXT NOT NULL,
                PRIMARY KEY(feature_id,revision),
                FOREIGN KEY(feature_id) REFERENCES bigmap_features(feature_id)
            );
            CREATE TABLE IF NOT EXISTS bigmap_meaning_links (
                link_id TEXT PRIMARY KEY,
                feature_id TEXT NOT NULL,
                cid TEXT NOT NULL,
                relation_type TEXT NOT NULL,
                context TEXT NOT NULL,
                evidence_ref TEXT,
                origin_ref TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status='CANDIDATE'),
                created_by TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(feature_id) REFERENCES bigmap_features(feature_id),
                FOREIGN KEY(cid) REFERENCES meaning_cores(cid)
            );
            CREATE INDEX IF NOT EXISTS bigmap_link_cid_idx ON bigmap_meaning_links(cid);
            CREATE INDEX IF NOT EXISTS bigmap_revisions_idx ON bigmap_feature_revisions(feature_id,revision);
            ''')
            cols={r[1] for r in db.execute('PRAGMA table_info(bigmap_feature_revisions)')}
            if 'vertical_crs' not in cols:
                db.execute('ALTER TABLE bigmap_feature_revisions ADD COLUMN vertical_crs TEXT')

    def _db(self):
        db=sqlite3.connect(self.db_path,timeout=15)
        db.row_factory=sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        db.execute('PRAGMA busy_timeout=15000')
        return db

    @staticmethod
    def _label(x):
        if not isinstance(x,str) or not 1 <= len(x.strip()) <= 120:
            raise ValueError('label_required_max_120')
        return x.strip()

    @staticmethod
    def _ref(x, field):
        if not isinstance(x,str) or not 1 <= len(x.strip()) <= 200:
            raise ValueError(f'{field}_required_max_200')
        return x.strip()

    @staticmethod
    def _classification(x):
        if x not in {'PUBLIC','INTERNAL','PRIVATE','CONFIDENTIAL','ORIGIN_ONLY'}:
            raise ValueError('classification_invalid')
        return x

    def _append_revision(self, db, feature_id, revision, geom, reason, actor, prev, vertical_crs=None):
        at=now(); gj=canonical_json(geom); gh=sha256(gj)
        record={'feature_id':feature_id,'revision':revision,'geometry_hash':gh,
                'prev_hash':prev,'reason':reason,'recorded_by':actor,'created_at':at}
        if vertical_crs is not None: record['vertical_crs']=vertical_crs
        rh=sha256(canonical_json(record))
        db.execute('''INSERT INTO bigmap_feature_revisions
                     (feature_id,revision,geometry_json,geometry_hash,prev_hash,record_hash,reason,recorded_by,created_at,vertical_crs)
                     VALUES (?,?,?,?,?,?,?,?,?,?)''',
                   (feature_id,revision,gj,gh,prev,rh,reason,actor,at,vertical_crs))
        return rh

    def add_feature(self,label,geometry,origin_ref,created_by,source_ref='local_capture',classification='INTERNAL',vertical_crs=None):
        geom=validate_geometry(geometry)
        require_vertical_crs(_positions(geom)[0][2] if len(_positions(geom)[0])==3 else None, vertical_crs)
        label=self._label(label);origin_ref=self._ref(origin_ref,'origin_ref')
        created_by=self._ref(created_by,'created_by');source_ref=self._ref(source_ref,'source_ref')
        classification=self._classification(classification)
        fid='geo_'+uuid.uuid4().hex;at=now()
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute('INSERT INTO bigmap_features VALUES (?,?,?,?,?,?,?,?)',
                       (fid,geom['type'],label,origin_ref,source_ref,classification,created_by,at))
            self._append_revision(db,fid,1,geom,'created',created_by,ZERO,vertical_crs)
        if self.audit:self.audit.append(fid,'BIGMAP_FEATURE_CREATED',{'feature_id':fid,'geometry_hash':sha256(canonical_json(geom))})
        return {'status':'RECORDED','feature':self.get_feature(fid)}

    def revise_geometry(self,feature_id,geometry,expected_revision,reason,actor,vertical_crs=None):
        geom=validate_geometry(geometry)
        require_vertical_crs(_positions(geom)[0][2] if len(_positions(geom)[0])==3 else None,vertical_crs)
        reason=self._ref(reason,'reason');actor=self._ref(actor,'actor')
        if type(expected_revision)!=int or expected_revision<1:raise ValueError('valid_expected_revision_required')
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            base=db.execute('SELECT kind FROM bigmap_features WHERE feature_id=?',(feature_id,)).fetchone()
            if not base:raise KeyError('feature_not_found')
            if geom['type']!=base['kind']:raise ValueError('geometry_type_change_requires_new_feature')
            last=db.execute('SELECT revision,record_hash FROM bigmap_feature_revisions WHERE feature_id=? ORDER BY revision DESC LIMIT 1',(feature_id,)).fetchone()
            if last['revision']!=expected_revision:raise ValueError('revision_conflict')
            self._append_revision(db,feature_id,expected_revision+1,geom,reason,actor,last['record_hash'],vertical_crs)
        if self.audit:self.audit.append(feature_id,'BIGMAP_FEATURE_REVISED',{'feature_id':feature_id,'revision':expected_revision+1,'geometry_hash':sha256(canonical_json(geom))})
        return {'status':'REVISED','feature':self.get_feature(feature_id)}

    def get_feature(self,feature_id,include_links=True):
        with self._db() as db:
            row=db.execute('''SELECT f.*,r.revision,r.geometry_json,r.geometry_hash,r.record_hash,r.vertical_crs,r.created_at AS revised_at
                FROM bigmap_features f JOIN bigmap_feature_revisions r ON r.feature_id=f.feature_id
                WHERE f.feature_id=? ORDER BY r.revision DESC LIMIT 1''',(feature_id,)).fetchone()
            if not row:return None
            links=[dict(r) for r in db.execute('SELECT * FROM bigmap_meaning_links WHERE feature_id=? ORDER BY created_at,link_id',(feature_id,))] if include_links else []
        d=dict(row);d['geometry']=json.loads(d.pop('geometry_json'))
        d['metrics']=geometry_metrics(d['geometry']);d['semantic_links']=links
        try:
            d['utm']=project_geometry(d['geometry'],d.get('vertical_crs'))
            d['utm']['derived_from_geometry_hash']=d['geometry_hash']
            d['utm']['feature_revision']=d['revision']
        except (ValueError,RuntimeError) as exc:
            d['utm']={'status':'NOT_AVAILABLE','reason_code':'UTM_PROJECTION_FAILED'}
        return d

    def list_features(self,limit=300,kind=None):
        if type(limit)!=int or not 1<=limit<=MAX_IMPORTED_FEATURES:raise ValueError('invalid_limit')
        if kind and kind not in KINDS:raise ValueError('invalid_kind')
        with self._db() as db:
            ids=[r[0] for r in db.execute('SELECT feature_id FROM bigmap_features '+('WHERE kind=? ' if kind else '')+'ORDER BY created_at,feature_id LIMIT ?',((kind,limit) if kind else (limit,))).fetchall()]
        return {'status':'LOCAL_DATA','crs':WGS84,'geojson_order':'lon,lat','ui_csv_order':'lat,lon',
                'features':[self.get_feature(fid) for fid in ids], 'survey_accuracy':'NOT_CERTIFIED'}

    def link_to_meaning(self,feature_id,cid,relation_type,origin_ref,created_by,evidence_ref=None,context='geographic_context'):
        """Adds CANDIDATE link only. Does not edit semantic core/edge/coordinates."""
        if not self.ms:raise RuntimeError('meaning_space_required')
        if not self.get_feature(feature_id,include_links=False):raise KeyError('feature_not_found')
        if not isinstance(cid,str) or not self.ms.get_core(cid):raise KeyError('meaning_cid_not_found')
        if relation_type not in {'located_at','represents','part_of','near','flows_along','bounds','observed_at'}:
            raise ValueError('relation_type_not_allowed')
        origin_ref=self._ref(origin_ref,'origin_ref');created_by=self._ref(created_by,'created_by')
        context=self._ref(context,'context')
        if evidence_ref is not None and not self.ms.get_evidence(evidence_ref):
            raise ValueError('evidence_ref_not_in_meaning_space')
        lid='link_'+uuid.uuid4().hex
        with self._db() as db:
            db.execute('INSERT INTO bigmap_meaning_links VALUES(?,?,?,?,?,?,?,?,?,?)',
                       (lid,feature_id,cid,relation_type,context,evidence_ref,origin_ref,'CANDIDATE',created_by,now()))
        if self.audit:self.audit.append(lid,'BIGMAP_MEANING_LINK_CANDIDATE',{'link_id':lid,'feature_id':feature_id,'cid':cid,'status':'CANDIDATE'})
        return {'status':'CANDIDATE','link_id':lid,'feature_id':feature_id,'cid':cid,
                'message':'This is a geographic-to-semantic association, not verified semantic truth'}

    def features_for_cid(self,cid,limit=300):
        if not self.ms or not self.ms.get_core(cid):raise KeyError('meaning_cid_not_found')
        with self._db() as db:
            rows=db.execute('SELECT DISTINCT feature_id FROM bigmap_meaning_links WHERE cid=? ORDER BY feature_id LIMIT ?', (cid,min(max(int(limit),1),1000))).fetchall()
        return {'cid':cid,'semantic_core':self.ms.get_core(cid),
                'features':[self.get_feature(r[0]) for r in rows],
                'status':'CANDIDATE_LINKS_NOT_VERIFIED'}

    def history(self,feature_id):
        if not self.get_feature(feature_id,include_links=False):raise KeyError('feature_not_found')
        with self._db() as db:
            rows=[dict(r) for r in db.execute('SELECT * FROM bigmap_feature_revisions WHERE feature_id=? ORDER BY revision',(feature_id,))]
        return {'feature_id':feature_id,'revisions':rows,'integrity':self.verify_history(feature_id)}

    def verify_history(self,feature_id=None):
        with self._db() as db:
            ids=[feature_id] if feature_id else [r[0] for r in db.execute('SELECT feature_id FROM bigmap_features')]
            for fid in ids:
                rows=db.execute('SELECT * FROM bigmap_feature_revisions WHERE feature_id=? ORDER BY revision',(fid,)).fetchall()
                if not rows:return {'status':'FAIL','feature_id':fid,'reason':'missing_revisions'}
                prev=ZERO
                for expected_rev,r in enumerate(rows,1):
                    try: geom=validate_geometry(json.loads(r['geometry_json']))
                    except (ValueError,TypeError,KeyError):return {'status':'FAIL','feature_id':fid,'reason':'invalid_geometry'}
                    rec={'feature_id':fid,'revision':r['revision'],'geometry_hash':r['geometry_hash'],
                         'prev_hash':r['prev_hash'],'reason':r['reason'],
                         'recorded_by':r['recorded_by'],'created_at':r['created_at']}
                    if r['vertical_crs'] is not None:
                        rec['vertical_crs']=r['vertical_crs']
                        try: require_vertical_crs(_positions(geom)[0][2] if len(_positions(geom)[0])==3 else None,r['vertical_crs'])
                        except ValueError: return {'status':'FAIL','feature_id':fid,'reason':'vertical_reference_invalid'}
                    if (r['revision']!=expected_rev or r['prev_hash']!=prev
                        or sha256(canonical_json(geom))!=r['geometry_hash']
                        or sha256(canonical_json(rec))!=r['record_hash']):
                        return {'status':'FAIL','feature_id':fid,'reason':'revision_hash_or_chain_mismatch','revision':r['revision']}
                    prev=r['record_hash']
                # Detect truncated revision tails when the independent runtime audit row survives.
                # This is still not proof against an attacker who can rewrite BOTH ledgers.
                if self.audit:
                    events=db.execute('''SELECT event_type,payload FROM audit_chain
                        WHERE trace_id=? AND event_type IN ('BIGMAP_FEATURE_CREATED','BIGMAP_FEATURE_REVISED')
                        ORDER BY seq''',(fid,)).fetchall()
                    if not events:return {'status':'FAIL','feature_id':fid,'reason':'missing_audit_receipts'}
                    expected_updates={}
                    for ev in events:
                        try: payload=json.loads(ev['payload'])
                        except (TypeError,ValueError):return {'status':'FAIL','feature_id':fid,'reason':'audit_payload_unreadable'}
                        if ev['event_type']=='BIGMAP_FEATURE_REVISED':
                            expected_updates[payload.get('revision')]=payload.get('geometry_hash')
                        elif ev['event_type']=='BIGMAP_FEATURE_CREATED':
                            if payload.get('geometry_hash')!=sha256(rows[0]['geometry_json']):
                                return {'status':'FAIL','feature_id':fid,'reason':'creation_audit_mismatch'}
                    if len(rows)!=1+len(expected_updates):
                        return {'status':'FAIL','feature_id':fid,'reason':'revision_audit_count_mismatch'}
                    for rec in rows[1:]:
                        if expected_updates.get(rec['revision'])!=rec['geometry_hash']:
                            return {'status':'FAIL','feature_id':fid,'reason':'revision_audit_hash_mismatch'}
        return {'status':'PASS','features_checked':len(ids),'note':'two local ledgers checked; external attestation still required'}

    def nearby(self,lat,lon,radius_m=1000,limit=30):
        lat=_numeric(lat,-90,90,'lat');lon=_numeric(lon,-180,180,'lon')
        radius_m=_numeric(radius_m,0,100000,'radius_m')
        query=[lon,lat]
        found=[]
        for f in self.list_features(limit=MAX_IMPORTED_FEATURES)['features']:
            # Minimal vertex distance: candidate proximity, not an edge/area distance.
            dist=min(haversine_m(query,p) for p in _positions(f['geometry']))
            if dist<=radius_m:found.append({'feature_id':f['feature_id'],'label':f['label'],
                    'vertex_distance_m_approx':round(dist,3), 'kind':f['kind']})
        found.sort(key=lambda x:(x['vertex_distance_m_approx'],x['feature_id']))
        return {'status':'SPATIAL_CANDIDATES','distance_method':'nearest_vertex_haversine',
                'not_a_semantic_fact':True,'matches':found[:min(max(int(limit),1),500)]}

    def export_geojson(self,limit=MAX_IMPORTED_FEATURES):
        data=self.list_features(limit=limit)
        return {'type':'FeatureCollection','name':'OLGM BigMap WGS84','features':[
            {'type':'Feature','id':f['feature_id'],'geometry':f['geometry'],'properties':{
                'label':f['label'],'kind':f['kind'],'origin_ref':f['origin_ref'],
                'source_ref':f['source_ref'],'revision':f['revision'],'classification':f['classification'],
                'semantic_cids':[l['cid'] for l in f['semantic_links']],
                'semantic_links_status':'CANDIDATE' if f['semantic_links'] else 'NONE',
                'vertical_crs':f.get('vertical_crs'),'utm_zone_mode':f['utm'].get('zone_mode'),
                'utm_horizontal_crs':f['utm'].get('horizontal_crs'),
                'survey_accuracy':'NOT_CERTIFIED'}} for f in data['features']]}

    def export_dual_csv(self,only_coords=False):
        """WGS84 geographic + WGS84 UTM X/Y and explicitly qualified Z.

        One row per point; for paths/polygons use the GeoJSON source and utm
        per-vertex representation, not a single-zone implicit CSV.
        """
        stream=io.StringIO(newline='');w=csv.writer(stream,lineterminator='\r\n')
        cols=['lat','lon','X','Y','Z','utm_zone','hemisphere','horizontal_crs','vertical_crs']
        if not only_coords:cols=['feature_id','label']+cols+['revision','geometry_hash','origin_ref','source_ref']
        w.writerow(cols)
        for f in self.list_features(limit=MAX_IMPORTED_FEATURES,kind='Point')['features']:
            u=f['utm'];p=f['geometry']['coordinates']
            if u.get('status')=='NOT_AVAILABLE':raise ValueError('utm_not_available_for_feature:'+f['feature_id'])
            vals=[f'{p[1]:.8f}',f'{p[0]:.8f}',f'{u["coordinates"][0]:.3f}',f'{u["coordinates"][1]:.3f}',
                  '' if len(u['coordinates'])==2 else f'{u["coordinates"][2]:.3f}',
                  u['utm_zone_per_vertex'][0],u['hemisphere_per_vertex'][0],u['horizontal_crs'],u['vertical_crs'] or '']
            if not only_coords:vals=[f['feature_id'],f['label']]+vals+[f['revision'],f['geometry_hash'],f['origin_ref'],f['source_ref']]
            w.writerow(vals)
        return stream.getvalue()

    def import_utm_csv(self,path,origin_ref,actor,vertical_crs=None,source_ref=None,classification='INTERNAL'):
        """Import X/Y/Z in metres with zone and hemisphere on every row."""
        src=Path(path)
        if not src.is_file() or src.stat().st_size>4*1024*1024:raise ValueError('csv_missing_or_exceeds_4MB')
        contents=src.read_text(encoding='utf-8-sig');r=csv.DictReader(io.StringIO(contents))
        if not r.fieldnames:raise ValueError('empty_csv')
        cols={str(c).strip().lower():c for c in r.fieldnames if c}
        if not {'x','y','utm_zone','hemisphere'}.issubset(cols):raise ValueError('utm_csv_requires_X_Y_utm_zone_hemisphere')
        rows=[]
        for i,row in enumerate(r,2):
            try:
                x=float(row[cols['x']]);y=float(row[cols['y']]);zone=int(row[cols['utm_zone']]);hemi=row[cols['hemisphere']].strip().upper()
                rawz=row.get(cols.get('z',''),None)
                z=float(rawz) if rawz not in ('',None) else None
                meta=row.get(cols.get('vertical_crs',''),None) or vertical_crs
                pt=from_utm(x,y,zone,hemi,z,meta)
            except (ValueError,TypeError) as exc:raise ValueError(f'utm_csv_line_{i}_invalid') from exc
            label=row.get(cols.get('label',''),None) or f'จุด {i-1}'
            rows.append((label,{'type':'Point','coordinates':[pt['lon'],pt['lat']] + ([z] if z is not None else [])},meta if z is not None else None))
        return self._bulk_add(rows,origin_ref,actor,source_ref or 'utm_csv:'+sha256(contents),classification)

    def export_csv(self,only_coords=False):
        stream=io.StringIO(newline='');w=csv.writer(stream,lineterminator='\r\n')
        header=['lat','lon'] if only_coords else ['feature_id','label','lat','lon','revision','origin_ref','source_ref']
        w.writerow(header)
        for f in self.list_features(limit=MAX_IMPORTED_FEATURES,kind='Point')['features']:
            lon,lat=f['geometry']['coordinates'][:2]
            w.writerow([f'{lat:.8f}',f'{lon:.8f}'] if only_coords else
                [f['feature_id'],f['label'],f'{lat:.8f}',f'{lon:.8f}',f['revision'],f['origin_ref'],f['source_ref']])
        return stream.getvalue()

    def _bulk_add(self,rows,origin_ref,actor,source_ref,classification='INTERNAL'):
        if not rows or len(rows)>MAX_IMPORTED_FEATURES:raise ValueError('import_count_must_be_1_to_2000')
        origin_ref=self._ref(origin_ref,'origin_ref');actor=self._ref(actor,'actor')
        source_ref=self._ref(source_ref,'source_ref');classification=self._classification(classification)
        validated=[]
        for row in rows:
            label,geometry=row[:2]; vertical_crs=row[2] if len(row)>2 else None
            geom=validate_geometry(geometry)
            require_vertical_crs(_positions(geom)[0][2] if len(_positions(geom)[0])==3 else None,vertical_crs)
            validated.append((self._label(label),geom,vertical_crs))
        imported=[]
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            for label,geom,vertical_crs in validated:
                fid='geo_'+uuid.uuid4().hex
                db.execute('INSERT INTO bigmap_features VALUES (?,?,?,?,?,?,?,?)',
                           (fid,geom['type'],label,origin_ref,source_ref,classification,actor,now()))
                self._append_revision(db,fid,1,geom,'import',actor,ZERO,vertical_crs)
                imported.append(fid)
        if self.audit:
            for fid,(_,geom,_) in zip(imported,validated):
                self.audit.append(fid,'BIGMAP_FEATURE_CREATED',
                                  {'feature_id':fid,'geometry_hash':sha256(canonical_json(geom)),'via':'import'})
            self.audit.append('bigmap_import','BIGMAP_IMPORT',
                              {'count':len(imported),'ids_hash':sha256(canonical_json(imported))})
        return {'status':'IMPORTED','count':len(imported),'feature_ids':imported,'crs':WGS84}

    def import_csv(self,path,origin_ref,actor,source_ref=None,classification='INTERNAL'):
        src=Path(path)
        if not src.is_file() or src.stat().st_size>4*1024*1024:raise ValueError('csv_missing_or_exceeds_4MB')
        contents=src.read_text(encoding='utf-8-sig')
        r=csv.DictReader(io.StringIO(contents))
        if not r.fieldnames:raise ValueError('empty_csv')
        cols={c.casefold().strip():c for c in r.fieldnames if c}
        lat_col=cols.get('lat') or cols.get('latitude')
        lon_col=cols.get('lon') or cols.get('longitude')
        if not lat_col or not lon_col:raise ValueError('csv_requires_lat_lon_columns')
        rows=[]
        for i,row in enumerate(r,2):
            if len(rows)>=MAX_IMPORTED_FEATURES:raise ValueError('csv_too_many_points')
            try:
                lat=_numeric(float(row[lat_col]),-90,90,'lat')
                lon=_numeric(float(row[lon_col]),-180,180,'lon')
            except (TypeError,ValueError) as e:raise ValueError(f'csv_line_{i}_invalid_lat_lon') from e
            label=(row.get(cols.get('label','')) or row.get(cols.get('name','')) or f'จุด {i-1}')
            rawz=row.get(cols.get('z',''),None)
            z=float(rawz) if rawz not in (None,'') else None
            vertical_crs=row.get(cols.get('vertical_crs',''),None)
            rows.append((label,{'type':'Point','coordinates':[lon,lat]+([z] if z is not None else [])},vertical_crs or None))
        return self._bulk_add(rows,origin_ref,actor,source_ref or 'csv:'+sha256(contents),classification)

    def import_geojson(self,path,origin_ref,actor,source_ref=None,classification='INTERNAL'):
        src=Path(path)
        if not src.is_file() or src.stat().st_size>4*1024*1024:raise ValueError('geojson_missing_or_exceeds_4MB')
        raw=src.read_text(encoding='utf-8-sig')
        doc=json.loads(raw)
        if not isinstance(doc,dict) or doc.get('type')!='FeatureCollection' or not isinstance(doc.get('features'),list):
            raise ValueError('feature_collection_required')
        rows=[]
        for i,f in enumerate(doc['features'],1):
            if not isinstance(f,dict) or f.get('type')!='Feature':raise ValueError('invalid_feature')
            props=f.get('properties') or {}
            if not isinstance(props,dict):raise ValueError('invalid_properties')
            rows.append((str(props.get('label') or f'วัตถุ {i}'),f.get('geometry'),props.get('vertical_crs')))
        return self._bulk_add(rows,origin_ref,actor,source_ref or 'geojson:'+sha256(raw),classification)
