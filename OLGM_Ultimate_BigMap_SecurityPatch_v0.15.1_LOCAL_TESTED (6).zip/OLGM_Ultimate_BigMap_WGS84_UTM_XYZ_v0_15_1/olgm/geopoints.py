"""WGS84 decimal-degree geographic point register for the OLGM local console.

Coordinate convention in UI, API and CSV: latitude,longitude (lat,lon).
GeoJSON uses the required standard geometry ordering [longitude,latitude].
Does not edit Meaning Space, Canonical, or other GIS/survey data.
"""
from __future__ import annotations
import math
import sqlite3
import uuid
from datetime import datetime,timezone

CRS='EPSG:4326'


def validate_latlon(lat,lon):
    """Validate WGS84 geographic coordinates; explicitly disallow bool and NaN."""
    if type(lat) not in (int,float) or type(lon) not in (int,float):
        raise ValueError('numeric_lat_lon_required')
    if not (math.isfinite(lat) and math.isfinite(lon)):
        raise ValueError('finite_lat_lon_required')
    if not (-90<=lat<=90 and -180<=lon<=180):
        raise ValueError('lat_lon_out_of_range')
    return float(lat),float(lon)


def point_info(lat,lon):
    lat,lon=validate_latlon(lat,lon)
    from .utm_wgs84 import to_utm
    try:
        projected=to_utm(lat,lon)
    except (ValueError,RuntimeError):
        projected={'status':'NOT_AVAILABLE','reason_code':'UTM_NOT_AVAILABLE_FOR_GEOGRAPHIC_POSITION'}
    return {'lat':lat,'lon':lon,'crs':CRS,'coordinate_order':'lat,lon',
            'units':'decimal_degrees','display':f'{lat:.6f}, {lon:.6f}',
            'geojson':{'type':'Point','coordinates':[lon,lat]},'utm':projected} 


class GeoPointStore:
    """Append-only point register; stores no converted UTM values by default."""
    def __init__(self,db_path,audit=None):
        self.db_path=str(db_path)
        self.audit=audit
        with self._db() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS geographic_points (
                point_id TEXT PRIMARY KEY,
                label TEXT NOT NULL,
                lat REAL NOT NULL CHECK(lat >= -90 AND lat <= 90),
                lon REAL NOT NULL CHECK(lon >= -180 AND lon <= 180),
                crs TEXT NOT NULL CHECK(crs = 'EPSG:4326'),
                coordinate_order TEXT NOT NULL CHECK(coordinate_order = 'lat,lon'),
                created_by TEXT NOT NULL,
                created_at TEXT NOT NULL
            )''')
    def _db(self):
        return sqlite3.connect(self.db_path,timeout=15)

    def add(self,label,lat,lon,actor):
        lat,lon=validate_latlon(lat,lon)
        if not isinstance(label,str) or len(label.strip())>80:
            raise ValueError('label_must_be_string_0_to_80_chars')
        if not isinstance(actor,str) or not actor or len(actor)>80:
            raise ValueError('invalid_actor')
        name=label.strip() or 'จุดพิกัด'
        pid=uuid.uuid4().hex
        at=datetime.now(timezone.utc).isoformat()
        with self._db() as db:
            db.execute('INSERT INTO geographic_points VALUES(?,?,?,?,?,?,?,?)',
                       (pid,name,lat,lon,CRS,'lat,lon',actor,at))
        # The audit references a point identifier, never the full location or actor token.
        if self.audit:
            self.audit.append(pid,'GEO_POINT_ADDED',{'point_id':pid,'crs':CRS})
        return {'status':'RECORDED','point':{'point_id':pid,'label':name,'created_at':at,**point_info(lat,lon)}}

    def list(self,limit=300):
        limit=min(max(int(limit),1),1000)
        with self._db() as db:
            rows=db.execute('''SELECT point_id,label,lat,lon,crs,created_at
                               FROM geographic_points ORDER BY created_at,point_id LIMIT ?''',(limit,)).fetchall()
        return {'status':'LOCAL_DATA','crs':CRS,'coordinate_order':'lat,lon',
                'points':[{'point_id':pid,'label':label,'created_at':at,**point_info(lat,lon)}
                          for pid,label,lat,lon,crs,at in rows],
                'basemap':'NOT_CONFIGURED','survey_accuracy':'NOT_CERTIFIED'}
