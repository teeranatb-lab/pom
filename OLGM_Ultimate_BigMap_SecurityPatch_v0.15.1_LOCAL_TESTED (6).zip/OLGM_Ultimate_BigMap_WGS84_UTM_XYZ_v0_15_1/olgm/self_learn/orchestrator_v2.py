"""G-06 safe local experiment in bounded symbolic program evolution.

This module evolves deterministic transformations, not general autonomous intelligence.
Protected Canonical/Origin and source files are never modified. An experimental
registry grows only after semantic equivalence tests; production activation needs
separate human approval. Final holdout is only evaluated by report(), never cycle().
"""
from __future__ import annotations
import json
import os
import sqlite3
import hashlib
from pathlib import Path
import tempfile
from datetime import datetime,timezone
from .primitives import PrimitiveRegistry
from .curriculum import Curriculum,TASKS
from .pipeline import Pipeline
from .evolution import Evolver,score
from .structural_growth import StructuralGrower
from .coevolution import CoEvolution
from .meta import MetaRouter
from .reflection import Reflector
from .memory import PipelineMemory

def utc():return datetime.now(timezone.utc).isoformat()

class HeavyDutyLearnerV2:
    def __init__(self,audit,tracker_path='selflearn_v2_state.json',memory_path=None):
        self.audit=audit;self.tracker_path=Path(tracker_path).resolve()
        self.registry=PrimitiveRegistry()
        self.state=self._load()
        self.verify_state_commit()
        self.registry.restore(self.state.get('primitives_added',[]))
        self.curr=Curriculum(seed=42)
        if self.state.get('curriculum'):
            self.curr.restore_train(self.state['curriculum'])
        self.meta=MetaRouter()
        for intent,episode in self.state.get('champions',{}).items():
            self.meta.update(intent,episode['steps'],episode['validation_accuracy'])
        self.grower=StructuralGrower(self.registry)
        self.coevo=CoEvolution(seed=42+self.state['generation'])
        self.memory=PipelineMemory(memory_path or str(self.tracker_path.with_suffix('.sqlite')))

    def _load(self):
        if not self.tracker_path.exists():
            return {'schema':2,'generation':0,'version':'0.7.0',
                    'champions':{},'history':[],'primitives_added':[],
                    'curriculum':None,'baseline':None,'status':'EXPERIMENTAL'}
        data=json.loads(self.tracker_path.read_text(encoding='utf-8'))
        if data.get('schema')!=2:raise ValueError('state_schema_mismatch')
        return data
    def verify_state_commit(self):
        # Links the persisted learner snapshot to the append-only audit chain.
        # A same-host attacker who can rewrite BOTH the DB and state still needs
        # an external, independently held anchor to prevent full rollback.
        if not self.state['generation']:
            return {'status':'NEW_EMPTY_STATE'}
        ok,detail=self.audit.verify()
        if not ok:raise ValueError('g06_audit_chain_corrupt:'+detail)
        with sqlite3.connect(self.audit.db_path) as db:
            row=db.execute("SELECT payload FROM audit_chain WHERE event_type='G06_STATE_COMMIT' ORDER BY seq DESC LIMIT 1").fetchone()
        if not row:raise ValueError('g06_state_missing_audit_commit')
        expected=json.loads(row[0]); actual=hashlib.sha256(
            json.dumps(self.state,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
        if expected.get('generation')!=self.state['generation'] or expected.get('state_sha256')!=actual:
            raise ValueError('g06_state_audit_hash_mismatch')
        return {'status':'STATE_AUDIT_BOUND','generation':self.state['generation']}

    def _save(self):
        self.tracker_path.parent.mkdir(parents=True,exist_ok=True)
        fd,name=tempfile.mkstemp(prefix='.olgm_state_',dir=self.tracker_path.parent)
        try:
            with os.fdopen(fd,'w',encoding='utf-8') as f:
                json.dump(self.state,f,ensure_ascii=False,sort_keys=True,indent=2)
                f.flush();os.fsync(f.fileno())
            os.replace(name,self.tracker_path)
        finally:
            if os.path.exists(name):os.unlink(name)

    def cycle(self,n_generations=15,batch_size=8,pop_size=40,intent=None):
        if not 1<=n_generations<=200 or not 4<=pop_size<=300 or not 2<=batch_size<=100:
            raise ValueError('budget_out_of_range')
        gen_id=self.state['generation']+1
        intent=intent or list(TASKS)[(gen_id-1)%len(TASKS)]
        if intent not in TASKS:raise ValueError('unknown_symbolic_task')
        trace=f'G06_GEN_{gen_id:04d}_{intent}'
        all_train=self.curr.train(intent)
        # GP sees training only. Stratify all stored examples when batch is small.
        problems=all_train if batch_size>=len(all_train) else [all_train[(i*len(all_train))//batch_size] for i in range(batch_size)]
        baseline=Pipeline(['identity'])
        old=self.state['champions'].get(intent)
        incumbent=Pipeline(old['steps']) if old else baseline
        warm=[incumbent,*self.meta.transfer(intent)]
        self.audit.append(trace,'G06_START',{'gen':gen_id,'intent':intent,'training_n':len(problems),
                     'source':'synthetic_oracle','baseline':list(incumbent.steps)})
        evo=Evolver(self.registry,pop_size,generations=n_generations,seed=417+gen_id)
        evolved,log=evo.evolve(problems,warm)
        train_score=score(evolved,self.curr.train(intent),self.registry)
        valid_score=score(evolved,self.curr.validate(intent),self.registry)
        inc_train=score(incumbent,self.curr.train(intent),self.registry)
        inc_valid=score(incumbent,self.curr.validate(intent),self.registry)
        # Promote only when no validation or training accuracy regresses.
        # Require strict gain in accuracy or lower cost at equal accuracy.
        can_promote=(train_score.accuracy>=inc_train.accuracy and
                     valid_score.accuracy>=inc_valid.accuracy and
                     (train_score.accuracy>inc_train.accuracy or
                      valid_score.accuracy>inc_valid.accuracy or
                      (train_score.accuracy==inc_train.accuracy and
                       valid_score.accuracy==inc_valid.accuracy and train_score.cost<inc_train.cost)))
        winner=evolved if can_promote else incumbent
        winner_train=score(winner,self.curr.train(intent),self.registry)
        winner_valid=score(winner,self.curr.validate(intent),self.registry)
        reflection=Reflector().analyze(winner,self.curr.train(intent),self.registry)
        record={'gen':gen_id,'intent':intent,'proposed_steps':list(evolved.steps),
                'selected_steps':list(winner.steps),'steps':list(winner.steps),'best_accuracy':winner_train.accuracy,
                'candidate_training_accuracy':train_score.accuracy,
                'candidate_validation_accuracy':valid_score.accuracy,
                'validation_accuracy':winner_valid.accuracy,'candidate_cost':train_score.cost,
                'selected_cost':winner_train.cost,'promoted':bool(can_promote),
                'reason':'validated_no_regression' if can_promote else 'no_verified_benefit',
                'at':utc()}
        if can_promote:
            self.state['champions'][intent]={'steps':list(winner.steps),
                 'training_accuracy':winner_train.accuracy,
                 'validation_accuracy':winner_valid.accuracy,
                 'cost':winner_train.cost,'gen':gen_id}
            self.meta.update(intent,winner.steps,winner_valid.accuracy)
            self.state['version']='0.7.'+str(sum(1 for row in self.state['history'] if row.get('promoted'))+1)
            eid=self.memory.record(intent,winner.steps,{'promoted':True,
                   'validation_accuracy':winner_valid.accuracy,'generation':gen_id,
                   'evaluation_split':'validation_not_final_holdout'})
            record['episode_id']=eid
        # Plateau of sustained training accuracy. Always compare same intent and
        # never claim growth alone means better generalization.
        same_intent=[r for r in self.state['history'] if r['intent']==intent]
        is_plateau,steps=self.grower.detect_plateau(same_intent+[record])
        growth={'action':'none'}
        if is_plateau and steps:
            proposal=self.grower.propose_from_winner(steps)
            if proposal:
                growth=self.grower.verify_and_register(proposal)
                growth['action']='ADDED_PRIMITIVE' if growth['status']=='REGISTERED' else 'REJECTED'
                growth['proposal_id']=proposal.proposal_id
            else:growth={'action':'PLATEAU_NO_COMPOSABLE_PAIR'}
        record['growth']=growth['action']
        # Automated adversarial curriculum is a training expansion, cannot touch fixed validation/test.
        adapt=self.coevo.adapt_curriculum(self.curr,intent,winner,self.registry,gen_id)
        record['challenge_added']=adapt['added']
        self.state['generation']=gen_id
        self.state['history'].append(record)
        self.state['primitives_added']=self.registry.serialize_growth()
        self.state['curriculum']=self.curr.serialize_train()
        self._save()
        self.audit.append(trace,'G06_RESULT',{'record':record,'growth':growth,'coevo':adapt,
                    'evolution_tail':log[-1],'reflection_count':reflection['error_count']})
        state_digest=hashlib.sha256(json.dumps(self.state,sort_keys=True,ensure_ascii=False,
                             separators=(',',':')).encode()).hexdigest()
        self.audit.append(trace,'G06_STATE_COMMIT',{'generation':gen_id,
                  'state_sha256':state_digest,'source':'local_experimental_state'})
        return {'trace':trace,'gen':gen_id,'intent':intent,'status':'EXPERIMENTAL',
               'promoted':can_promote,'training_accuracy':winner_train.accuracy,
               'validation_accuracy':winner_valid.accuracy,
               'best_steps':list(winner.steps),'growth':growth,'coevo':adapt,
               'reflection':reflection,'evolution_log':log,
               'final_holdout_exposed_to_training':False}

    def report(self):
        self.verify_state_commit()
        # Called after cycles. Final holdout is never used for selection. However,
        # repeated human examination of report before future training can leak it.
        rows=[]
        for intent in TASKS:
            baseline=score(Pipeline(['identity']),self.curr.holdout(intent),self.registry)
            champ=self.state['champions'].get(intent)
            trained=score(Pipeline(champ['steps']) if champ else Pipeline(['identity']),
                          self.curr.holdout(intent),self.registry)
            rows.append({'intent':intent,'baseline_final_accuracy':baseline.accuracy,
                         'trained_final_accuracy':trained.accuracy,
                         'delta_accuracy':round(trained.accuracy-baseline.accuracy,4),
                         'steps':champ['steps'] if champ else ['identity'],
                         'test_count':len(self.curr.holdout(intent))})
        avg_before=sum(r['baseline_final_accuracy'] for r in rows)/len(rows)
        avg_after=sum(r['trained_final_accuracy'] for r in rows)/len(rows)
        return {'status':'EXPERIMENTAL_NOT_S10_CERTIFIED','generations':self.state['generation'],
                'version':self.state['version'],'base_primitives':9,
                'primitives_total':len(self.registry),'primitives_added':self.state['primitives_added'],
                'promotions':sum(bool(r['promoted']) for r in self.state['history']),
                'growth_count':len(self.state['primitives_added']),
                'final_holdout_mean_before':round(avg_before,5),
                'final_holdout_mean_after':round(avg_after,5),
                'final_holdout_delta':round(avg_after-avg_before,5),
                'per_intent':rows,'history':self.state['history'],
                'meta_report':self.meta.report(),
                'limitations':['finite human-defined primitives and synthetic oracle tasks',
                    'new composite shortcuts do not increase primitive expressive power',
                    'single final holdout is not independent external verification',
                    'repeated reporting before further training risks test leakage',
                    'no GPU/model weight training and no unattended production code self-edit']}
