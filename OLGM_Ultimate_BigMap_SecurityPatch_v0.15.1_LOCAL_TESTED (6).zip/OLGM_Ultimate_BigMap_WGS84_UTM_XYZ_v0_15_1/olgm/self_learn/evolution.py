"""Genetic programming using tournament selection, crossover and mutation.
Fitness is training-set correctness; promotion uses separate holdout.
"""
import random
from dataclasses import dataclass
from .pipeline import Pipeline

@dataclass(frozen=True)
class Score:
    accuracy:float
    cost:int
    complexity:int
    @property
    def scalar(self):return round(self.accuracy - self.cost*0.001 - self.complexity*0.0001,6)


def score(pipeline,problems,registry):
    if not problems:raise ValueError('empty_eval_set')
    correct=0
    for p in problems:
        result=pipeline.execute(p.x,registry)
        correct+=int(result['ok'] and result['result']==p.expected)
    return Score(correct/len(problems),pipeline.cost(registry),len(pipeline.steps))


def pareto_front(scored):
    # Pareto maximize accuracy and minimize cost/complexity
    def dominates(a,b):
        aa,bb=a[1],b[1]
        return aa.accuracy>=bb.accuracy and aa.cost<=bb.cost and aa.complexity<=bb.complexity and (
            aa.accuracy>bb.accuracy or aa.cost<bb.cost or aa.complexity<bb.complexity)
    return [(p,s) for i,(p,s) in enumerate(scored) if not any(j!=i and dominates(other,(p,s)) for j,other in enumerate(scored))]

class Evolver:
    def __init__(self,registry,pop_size=60,generations=15,seed=42):
        if pop_size<4 or generations<1:raise ValueError('bad_evolution_budget')
        self.registry=registry;self.pop_size=pop_size;self.generations=generations
        self.rng=random.Random(seed)
    def _random(self):
        return Pipeline([self.rng.choice(self.registry.names()) for _ in range(self.rng.randint(1,4))])
    def _mutate(self,p):
        s=list(p.steps); r=self.rng.random()
        if r<.33 and len(s)<6:s.insert(self.rng.randrange(len(s)+1),self.rng.choice(self.registry.names()))
        elif r<.66 and len(s)>1:s.pop(self.rng.randrange(len(s)))
        else:s[self.rng.randrange(len(s))]=self.rng.choice(self.registry.names())
        return Pipeline(s)
    def _cross(self,a,b):
        cuta=self.rng.randrange(len(a.steps)+1);cutb=self.rng.randrange(len(b.steps)+1)
        s=list(a.steps[:cuta]+b.steps[cutb:])
        return Pipeline(s[:6] if s else [self.rng.choice(self.registry.names())])
    def evolve(self, problems, warm_starts=()):
        population=[Pipeline(p.steps) for p in warm_starts if p and p.steps]
        while len(population)<self.pop_size:population.append(self._random())
        log=[]; champion=None; champ_score=None
        for generation in range(self.generations):
            ranked=sorted([(p,score(p,problems,self.registry)) for p in population],
                key=lambda t:(-t[1].accuracy,t[1].cost,t[1].complexity,t[0].steps))
            candidate,metric=ranked[0]
            if champ_score is None or (metric.accuracy,-metric.cost,-metric.complexity)>(champ_score.accuracy,-champ_score.cost,-champ_score.complexity):
                champion,champ_score=candidate,metric
            log.append({'generation':generation+1,'best_accuracy':champ_score.accuracy,
                        'best_cost':champ_score.cost,'pareto_size':len(pareto_front(ranked))})
            elites=[p for p,_ in ranked[:max(2,self.pop_size//5)]]
            nextpop=list(elites)
            while len(nextpop)<self.pop_size:
                if self.rng.random()<.28:
                    p=self._cross(self.rng.choice(elites),self.rng.choice(elites))
                else:p=self._mutate(self.rng.choice(elites))
                nextpop.append(p)
            # A small amount of fresh diversity to limit premature convergence.
            for i in range(min(3,len(nextpop))):nextpop[-1-i]=self._random()
            population=nextpop
        return champion,log
