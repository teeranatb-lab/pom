"""Failure evidence, not self-reported introspective accuracy."""
class Reflector:
    def analyze(self,pipeline,problems,registry):
        failures=[]
        for p in problems:
            r=pipeline.execute(p.x,registry)
            if not r['ok'] or r['result']!=p.expected:
                failures.append({'x':p.x,'expected':p.expected,'actual':r.get('result'),'reason':r.get('reason')})
        return {'finding':'counterexamples_found' if failures else 'none_on_this_set',
                'failures':failures[:10],'error_count':len(failures),'set_size':len(problems)}
