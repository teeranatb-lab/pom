"""SQLite episode pointers to primitive identifiers, not arbitrary executable source."""
import json,sqlite3,hashlib
from datetime import datetime,timezone

class PipelineMemory:
    def __init__(self,path):
        self.path=str(path)
        with self._conn() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS pipeline_episodes (
                episode_id TEXT PRIMARY KEY, intent TEXT NOT NULL, steps_json TEXT NOT NULL,
                evidence_hash TEXT NOT NULL, validation_accuracy REAL NOT NULL,
                created_at TEXT NOT NULL)''')
    def _conn(self):return sqlite3.connect(self.path,timeout=10)
    def record(self,intent,steps,report):
        if not report.get('promoted'):raise ValueError('only_promoted_episodes')
        data=json.dumps({'intent':intent,'steps':list(steps),'evidence':report},ensure_ascii=False,sort_keys=True)
        eid=hashlib.sha256(data.encode()).hexdigest()[:24]
        with self._conn() as db:
            db.execute('INSERT OR IGNORE INTO pipeline_episodes VALUES(?,?,?,?,?,?)',
                       (eid,intent,json.dumps(list(steps)),hashlib.sha256(json.dumps(report,sort_keys=True).encode()).hexdigest(),
                        report['validation_accuracy'],datetime.now(timezone.utc).isoformat()))
        return eid
    def rehydrate(self,eid,registry):
        with self._conn() as db:
            row=db.execute('SELECT intent,steps_json,evidence_hash,validation_accuracy FROM pipeline_episodes WHERE episode_id=?',(eid,)).fetchone()
        if not row:return {'status':'NOT_FOUND'}
        intent,steps,h,accuracy=row
        names=json.loads(steps)
        if not all(n in registry for n in names):return {'status':'INCOMPLETE','reason':'missing_primitive_pointer'}
        return {'status':'REHYDRATED','intent':intent,'steps':names,'evidence_hash':h,'validation_accuracy':accuracy}
