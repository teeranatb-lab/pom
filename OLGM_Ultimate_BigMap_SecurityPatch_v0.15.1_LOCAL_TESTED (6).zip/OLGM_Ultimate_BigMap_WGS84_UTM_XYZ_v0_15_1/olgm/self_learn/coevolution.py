"""Bounded curriculum adaptation and adversarial challenge generation."""
import random

class CoEvolution:
    def __init__(self,seed=42):self.rng=random.Random(seed)
    def adapt_curriculum(self,curr,intent,champion,registry,gen):
        existing={p.x for p in curr.train(intent)}|{p.x for p in curr.validate(intent)}|{p.x for p in curr.holdout(intent)}
        pool=[x for x in range(-100,101) if x not in existing]
        self.rng.shuffle(pool)
        failures=[]
        for x in pool[:100]:
            truth=curr._make(intent,x,'oracle').expected
            got=champion.execute(x,registry)
            if not got['ok'] or got['result']!=truth:failures.append(x)
        if failures:
            n=curr.add_challenges(intent,failures[:5],gen)
            return {'action':'adversarial_counterexamples','added':n,'tested_inputs':min(100,len(pool)),
                    'source':'trusted_oracle_not_holdout'}
        # No artificial hardening if the candidate already generalizes over generated range.
        return {'action':'no_counterexamples','added':0,'tested_inputs':min(100,len(pool))}
