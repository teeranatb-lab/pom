"""Plateau discovery and semantics-preserving composition of existing primitives.
Composition expands search vocabulary but does NOT automatically improve function expressivity.
"""
from dataclasses import dataclass,asdict
import hashlib
from .pipeline import Pipeline

@dataclass(frozen=True)
class NewPrimitiveProposal:
    proposal_id:str
    parent_steps:tuple[str,...]
    components:tuple[str,...]
    fn_name:str
    rationale:str
    status:str='PROPOSED'
    def to_dict(self):return asdict(self)

class StructuralGrower:
    def __init__(self,registry,plateau_threshold=3,epsilon=0.005):
        self.registry=registry;self.threshold=plateau_threshold;self.epsilon=epsilon
    def detect_plateau(self,history):
        if len(history)<self.threshold+1:return False,None
        recent=[h['best_accuracy'] for h in history[-(self.threshold+1):]]
        return max(recent)-min(recent)<self.epsilon,history[-1]['steps']
    def propose_from_winner(self,steps):
        if len(steps)<2:return None
        candidate=[]
        for i in range(len(steps)-1):
            a,b=steps[i:i+2];name=f'{a}_then_{b}'
            if len(name)>100:continue
            if a in self.registry and b in self.registry and name not in self.registry:
                candidate.append((self.registry[a].cost+self.registry[b].cost,a,b,name))
        if not candidate:return None
        _,a,b,name=min(candidate)
        pid=hashlib.sha256(f'{name}|{tuple(steps)}'.encode()).hexdigest()[:20]
        return NewPrimitiveProposal(pid,tuple(steps),(a,b),name,
                 'Composed existing verified unary operators. No speculative 10% cost discount.')
    def verify_and_register(self,proposal):
        if proposal.fn_name in self.registry:return {'status':'REJECTED','reason':'already_exists'}
        a,b=proposal.components
        if a not in self.registry or b not in self.registry:return {'status':'REJECTED','reason':'missing_parent'}
        # Verify equivalence against independent explicit composition on broad integer domain.
        candidates={-100,-89,-41,-10,-2,-1,0,1,2,10,41,89,100}
        candidates.update(range(-20,21))
        for x in candidates:
            try:
                expected=self.registry.apply(b,self.registry.apply(a,x))
            except ValueError:continue
            # Stateful source of actual function: built only from fixed known registry.
            if type(expected) is not int:return {'status':'REJECTED','reason':'non_integer'}
        primitive=self.registry.composition(proposal.fn_name,proposal.components)
        for x in candidates:
            try: expected=self.registry.apply(b,self.registry.apply(a,x))
            except ValueError:continue
            result=self.registry.apply(primitive.name,x)
            if result!=expected:
                self.registry._items.pop(primitive.name,None)
                return {'status':'REJECTED','reason':'equivalence_failed'}
        return {'status':'REGISTERED','name':primitive.name,'cost':primitive.cost,
                'equivalence_cases':len(candidates),'note':'vocabulary growth; no proven heldout lift'}
