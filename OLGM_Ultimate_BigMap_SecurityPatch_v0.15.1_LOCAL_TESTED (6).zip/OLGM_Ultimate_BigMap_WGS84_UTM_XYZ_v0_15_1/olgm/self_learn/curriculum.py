"""Synthetic task generator with fixed hidden holdout distinct from evolving training.

The task functions are human-programmed oracles. Synthetic evidence is NOT a claim
about unsupervised general intelligence; no test-label leakage into search.
"""
from dataclasses import dataclass,asdict
import random
from .pipeline import Pipeline
from .primitives import PrimitiveRegistry

TASKS={
    'affine': ('double','plus_one'),
    'magnitude': ('absolute','double'),
    'parity_shift': ('mod_two','plus_one'),
    'squared_shift': ('square','plus_one'),
    'mirror': ('negate','plus_one'),
    'cubic_affine': ('triple','plus_one'),
}
@dataclass(frozen=True)
class Problem:
    intent:str
    x:int
    expected:int
    source:str
    difficulty:int
    def to_dict(self):return asdict(self)

class Curriculum:
    def __init__(self, seed=42):
        self.rng=random.Random(seed)
        self.registry=PrimitiveRegistry()
        self.samples={}
        self.hidden={}
        self.validation={}
        for intent in TASKS:
            train_x=[-10,-7,-4,-1,0,1,3,6,9,12]
            hidden_x=[-19,-13,-8,-3,2,5,11,17,23]  # fixed final test, not for model selection
            validation_x=[-16,-11,-5,4,15,20]  # model-selection check, disjoint from train and final
            self.samples[intent]=[self._make(intent,x,'training_oracle') for x in train_x]
            self.hidden[intent]=[self._make(intent,x,'holdout_oracle') for x in hidden_x]
            self.validation[intent]=[self._make(intent,x,'validation_oracle') for x in validation_x]
    def _make(self,intent,x,source):
        answer=Pipeline(TASKS[intent]).execute(x,self.registry)
        assert answer['ok']
        return Problem(intent,x,answer['result'],source,abs(x))
    def train(self,intent):return list(self.samples[intent])
    def holdout(self,intent):return list(self.hidden[intent])
    def validate(self,intent):return list(self.validation[intent])
    def add_challenges(self,intent,inputs,gen):
        existing={p.x for p in self.samples[intent]}
        added=0
        for x in inputs:
            reserved={p.x for p in self.hidden[intent]}|{p.x for p in self.validation[intent]}
            if type(x) is int and -100<=x<=100 and x not in existing and x not in reserved:
                self.samples[intent].append(self._make(intent,x,f'adversarial_gen_{gen}'))
                existing.add(x);added+=1
        return added
    def serialize_train(self):return {k:[p.to_dict() for p in v] for k,v in self.samples.items()}
    def restore_train(self,data):
        for intent,items in data.items():
            if intent not in TASKS:raise ValueError('unknown_intent')
            new=[];seen=set()
            for raw in items:
                p=Problem(**raw)
                if p.intent!=intent or p.expected!=self._make(intent,p.x,'oracle').expected or p.x in seen:
                    raise ValueError('invalid_training_evidence')
                protected={z.x for z in self.hidden[intent]}|{z.x for z in self.validation[intent]}
                if p.source in ('holdout_oracle','validation_oracle') or p.x in protected:
                    raise ValueError('holdout_or_validation_contamination')
                new.append(p);seen.add(p.x)
            self.samples[intent]=new
