"""Typed, deterministic primitives; composed operators are declarative and restorable.

This is symbolic program synthesis in a restricted integer domain, NOT an LLM.
No source code is ever evaluated from experiment state files.
"""
from dataclasses import dataclass
from typing import Callable

MAX_ABS = 1_000_000


def bounded(value):
    if type(value) is not int or abs(value) > MAX_ABS:
        raise ValueError('non_integer_or_overflow')
    return value

@dataclass(frozen=True)
class Primitive:
    name: str
    fn: Callable[[int], int]
    cost: int
    cert: str = 'symbolic'
    desc: str = ''
    components: tuple[str, ...] = ()
    @property
    def arity(self): return 1


def _base():
    definitions={
        'identity': (lambda x:x,1),
        'plus_one': (lambda x:x+1,1),
        'minus_one': (lambda x:x-1,1),
        'double': (lambda x:x*2,1),
        'square': (lambda x:x*x,2),
        'negate': (lambda x:-x,1),
        'absolute': (lambda x:abs(x),1),
        'mod_two': (lambda x:x%2,1),
        'triple': (lambda x:x*3,2),
    }
    return {k:Primitive(k,fn,cost,desc=f'Integer transformation {k}') for k,(fn,cost) in definitions.items()}

class PrimitiveRegistry:
    def __init__(self): self._items=_base()
    def __len__(self):return len(self._items)
    def __contains__(self,key):return key in self._items
    def __getitem__(self,key):return self._items[key]
    def names(self):return sorted(self._items)
    def resolve(self, name):
        if name not in self._items: raise KeyError(f'unknown_primitive:{name}')
        return self._items[name]
    def apply(self,name,value):return bounded(self.resolve(name).fn(bounded(value)))
    def composition(self, name, component_names):
        # Only registered, named operations; no exec, eval, imports, or arbitrary code.
        if name in self._items:raise ValueError('duplicate_primitive')
        if not component_names or len(component_names)>6:raise ValueError('invalid_composition')
        if any(p not in self._items for p in component_names):raise ValueError('unknown_component')
        parts=tuple(component_names)
        for p in parts:
            if p == name:raise ValueError('recursive_primitive')
        def fn(value):
            for part in parts:value=self.apply(part,value)
            return value
        total=sum(self._items[p].cost for p in parts)
        self._items[name]=Primitive(name,fn,total,cert='symbolic',desc=' >> '.join(parts),components=parts)
        return self._items[name]
    def restore(self, entries):
        for item in entries:
            name=item['name']; parts=item['components']
            prim=self.composition(name,parts)
            if prim.cost!=item['cost']:raise ValueError('stored_cost_mismatch')
    def serialize_growth(self):
        return [{'name':p.name,'components':list(p.components),'cost':p.cost}
                for p in self._items.values() if p.components]

# Read-only base view retained for explanatory compatibility. Do NOT mutate globally.
PRIMITIVES=_base()
