"""An executable bounded symbolic program, no arbitrary code execution."""
from dataclasses import dataclass
from .primitives import PrimitiveRegistry

@dataclass(frozen=True)
class Pipeline:
    steps: tuple[str,...]
    def __init__(self,steps):object.__setattr__(self,'steps',tuple(steps))
    @property
    def pipeline_id(self):
        import hashlib
        return hashlib.sha256('>>'.join(self.steps).encode()).hexdigest()[:16]
    def execute(self, value, registry: PrimitiveRegistry):
        try:
            if len(self.steps)>6:raise ValueError('max_steps_exceeded')
            for step in self.steps:value=registry.apply(step,value)
            return {'ok':True,'result':value,'steps':list(self.steps)}
        except (ValueError,KeyError,OverflowError,TypeError) as exc:
            return {'ok':False,'reason':'PIPELINE_EXECUTION_INVALID','result':None,'steps':list(self.steps)}
    def cost(self,registry):return sum(registry.resolve(p).cost for p in self.steps)
