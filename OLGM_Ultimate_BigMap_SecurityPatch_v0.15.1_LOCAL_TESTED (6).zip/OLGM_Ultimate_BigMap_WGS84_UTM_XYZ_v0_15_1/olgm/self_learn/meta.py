"""Transfer candidates by intent; no transfer without recipient-task validation."""
from .pipeline import Pipeline
class MetaRouter:
    def __init__(self):self.by_intent={}
    def update(self,intent,steps,holdout_accuracy):
        self.by_intent[intent]={'steps':list(steps),'holdout_accuracy':holdout_accuracy}
    def transfer(self,target):
        return [Pipeline(v['steps']) for intent,v in sorted(self.by_intent.items()) if intent!=target]
    def report(self):return self.by_intent.copy()
