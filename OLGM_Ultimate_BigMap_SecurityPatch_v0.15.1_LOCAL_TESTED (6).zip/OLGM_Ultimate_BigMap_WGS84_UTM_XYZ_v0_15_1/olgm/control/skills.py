"""Finite, inspectable and deterministic built-in Skill Catalog.

Skill manifests are not Python code/plugins downloaded from the web. Third-party
executors must be injected and vetted separately. No self-grant or external I/O.
"""
from collections import Counter
from .registry import digest

SKILLS={
  'inventory':{'title':'Inventory / ทะเบียนเครื่องมือ','purpose':'Enumerate declared resources, not access the remote systems','kind':'read'},
  'connection_gaps':{'title':'Connectivity gap / ช่องว่างการเชื่อมต่อ','purpose':'Find offline/unconnected declared resources','kind':'read'},
  'queue_health':{'title':'Queue health / สถานะคิวงาน','purpose':'Summarize work items by lifecycle state','kind':'read'},
  'audit_integrity':{'title':'Audit integrity / ตรวจความครบถ้วนของหลักฐาน','purpose':'Verify OLGM audit hash-chain locally','kind':'read'},
  'intent_proof':{'title':'Latest intent proof / ตรวจเจตนาล่าสุด','purpose':'Compare declared intent hash with latest revision','kind':'read'},
  'permissions':{'title':'Permission inventory / ทะเบียนสิทธิ์','purpose':'Count locally active development grants, no secrets','kind':'read'},
  'space_inventory':{'title':'Space inventory / ทะเบียนสเปซ','purpose':'Report declared Space metadata only','kind':'read'},
  'plugin_inventory':{'title':'Plugin inventory / ทะเบียนปลั๊กอิน','purpose':'Report declared Plugin metadata only','kind':'read'},
}


def installed_skill_id(key):
    if key not in SKILLS:raise ValueError('unknown_builtin_skill')
    return f'skill.{key}-v1'


class BuiltinSkillExecutor:
    def __init__(self,registry,plane,audit,intents,canti):
        self.registry=registry;self.plane=plane;self.audit=audit
        self.intents=intents;self.canti=canti

    @staticmethod
    def catalog():
        return {'status':'BUILTIN_SKILLS_CATALOG','count':len(SKILLS),
                'skills':[dict(skill_id=installed_skill_id(key),**info) for key,info in SKILLS.items()],
                'note':'Catalog discovery is not execution authorization'}

    def install(self,key,origin_ref,source_ref='olgm.control.skills.v1'):
        if key not in SKILLS:raise ValueError('unknown_builtin_skill')
        return self.registry.register(installed_skill_id(key),'skill',SKILLS[key]['title'],
            'olgm.builtin.v1',['skill.describe','skill.run'],'INTERNAL',origin_ref,source_ref,'CONNECTED')

    def handler(self,key,action,args,idempotency_key):
        # Authorized resource selects the skill, never an untrusted argument.
        if key not in SKILLS:return {'status':'DENIED','reason':'unknown_skill'}
        if 'skill_id' in args and args['skill_id']!=key:
            return {'status':'DENIED','reason':'skill_resource_mismatch'}
        if action=='skill.describe':
            return {'status':'EXECUTED','skill_id':installed_skill_id(key),**SKILLS[key]}
        if action!='skill.run':return {'status':'DENIED','reason':'unknown_skill_action'}
        if key in ('inventory','space_inventory','plugin_inventory'):
            kind={'space_inventory':'space','plugin_inventory':'plugin'}.get(key)
            reg=self.registry.list(kind)
            # Avoid unnecessarily exposing private descriptions through skill output.
            rows=[{'resource_id':r['resource_id'],'kind':r['kind'],
                   'connection_state':r['connection_state'],'classification':r['classification']}
                  for r in reg['resources']]
            return {'status':'EXECUTED','skill_id':installed_skill_id(key),'resources':rows}
        if key=='connection_gaps':
            items=self.registry.list()['resources']
            gaps=[{'resource_id':r['resource_id'],'state':r['connection_state']}
                  for r in items if r['connection_state'] not in ('CONNECTED',)]
            return {'status':'EXECUTED','gaps':gaps,'count':len(gaps)}
        if key=='queue_health':
            jobs=self.plane.status(200)['jobs']
            return {'status':'EXECUTED','states':dict(Counter(x['state'] for x in jobs)),
                    'sample_size':len(jobs)}
        if key=='audit_integrity':
            verified,details=self.audit.verify()
            return {'status':'EXECUTED','audit_verified':verified,'detail':details}
        if key=='intent_proof':
            if set(args)-{'skill_id'}!={'intent_id','intent_hash'}:
                return {'status':'DENIED','reason':'intent_id_and_hash_required'}
            proof=self.intents.proof(args['intent_id'],args['intent_hash'])
            return {'status':'EXECUTED','proof_status':proof['status']}
        if key=='permissions':
            from datetime import datetime,timezone
            with self.canti._conn() as db:
                n=db.execute('SELECT COUNT(*) FROM permissions WHERE revoked_at IS NULL AND (expires_at IS NULL OR expires_at>?)',
                             (datetime.now(timezone.utc).isoformat(),)).fetchone()[0]
            return {'status':'EXECUTED','active_dev_grants':n,
                    'warning':'Local CANTI dev grants are not production authentication'}
        return {'status':'DENIED','reason':'no_handler'}
