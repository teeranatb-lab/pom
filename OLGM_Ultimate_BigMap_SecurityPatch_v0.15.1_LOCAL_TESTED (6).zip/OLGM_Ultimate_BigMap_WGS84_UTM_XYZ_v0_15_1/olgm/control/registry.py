"""Sovereign resource & skill catalog. Registry entries do not confer access."""
from __future__ import annotations
import hashlib, json, re, sqlite3
from datetime import datetime, timezone

KINDS = {'computer', 'plugin', 'space', 'skill'}
ALLOWED_ACTIONS = {
    'computer': {'computer.status', 'computer.screenshot', 'computer.click', 'computer.type'},
    'plugin': {'plugin.describe', 'plugin.invoke'},
    'space': {'space.list', 'space.read', 'space.write'},
    'skill': {'skill.describe', 'skill.run'},
}
CLASSIFICATIONS = {'PUBLIC', 'INTERNAL', 'PRIVATE', 'RESTRICTED', 'ORIGIN_ONLY'}
RESOURCE_RE = re.compile(r'^[a-z][a-z0-9_.:-]{2,119}$')


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


class ResourceRegistry:
    def __init__(self, db_path):
        self.db_path = str(db_path)
        with self._db() as con:
            con.execute('''CREATE TABLE IF NOT EXISTS access_resources (
                resource_id TEXT PRIMARY KEY, kind TEXT NOT NULL,
                display_name TEXT NOT NULL, provider TEXT NOT NULL,
                actions_json TEXT NOT NULL, classification TEXT NOT NULL,
                ownership_ref TEXT NOT NULL, source_ref TEXT NOT NULL,
                connection_state TEXT NOT NULL, entry_digest TEXT NOT NULL,
                recorded_at TEXT NOT NULL, targets_json TEXT NOT NULL DEFAULT '[]')''')
            columns={x[1] for x in con.execute('PRAGMA table_info(access_resources)').fetchall()}
            if 'targets_json' not in columns:
                con.execute("ALTER TABLE access_resources ADD COLUMN targets_json TEXT NOT NULL DEFAULT '[]'")

    def _db(self):
        con = sqlite3.connect(self.db_path, timeout=15)
        con.row_factory = sqlite3.Row
        return con

    def register(self, resource_id, kind, display_name, provider, actions, classification,
                 ownership_ref, source_ref, connection_state='NOT_CONNECTED', targets=None):
        if not isinstance(resource_id, str) or not RESOURCE_RE.fullmatch(resource_id):
            raise ValueError('invalid_resource_id')
        if kind not in KINDS or not isinstance(actions, list) or not actions or len(set(actions)) != len(actions):
            raise ValueError('invalid_kind_or_actions')
        if not set(actions).issubset(ALLOWED_ACTIONS[kind]):
            raise ValueError('action_not_allowed_for_kind')
        if classification not in CLASSIFICATIONS or not all((display_name,provider,ownership_ref,source_ref)):
            raise ValueError('classification_origin_and_source_required')
        if connection_state not in ('NOT_CONNECTED','DECLARED','CONNECTED','OFFLINE'):
            raise ValueError('invalid_connection_state')
        if resource_id.startswith(('core0', 'canonical', 'archive')):
            raise ValueError('protected_resource_not_registerable')
        targets=list(targets or [])
        if (any(not isinstance(t,str) or not t or len(t)>200 for t in targets) or len(set(targets))!=len(targets)):
            raise ValueError('invalid_targets')
        if (kind=='plugin' and 'plugin.invoke' in actions or
            kind=='space' and any(a in actions for a in ('space.read','space.write'))) and not targets:
            raise ValueError('explicit_tool_or_page_allowlist_required')
        item = dict(resource_id=resource_id, kind=kind, display_name=display_name,
                    provider=provider, actions=sorted(actions), classification=classification,
                    ownership_ref=ownership_ref, source_ref=source_ref, connection_state=connection_state, targets=sorted(targets))
        seal = digest(item)
        with self._db() as con:
            # Registry is append-only per ID: changing capabilities requires a new versioned resource ID.
            row = con.execute('SELECT entry_digest FROM access_resources WHERE resource_id=?',
                              (resource_id,)).fetchone()
            if row:
                return {'status':'UNCHANGED' if row['entry_digest']==seal else 'DENIED',
                        'reason':None if row['entry_digest']==seal else 'append_only_version_new_id_required',
                        'resource_id':resource_id}
            con.execute('INSERT INTO access_resources VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
                        (resource_id,kind,display_name,provider,canonical(item['actions']),classification,
                         ownership_ref,source_ref,connection_state,seal,now(),canonical(item['targets'])))
        return {'status':'REGISTERED_DECLARATION_ONLY','resource_id':resource_id,'digest':seal}

    def get(self, resource_id):
        with self._db() as con:
            row = con.execute('SELECT * FROM access_resources WHERE resource_id=?', (resource_id,)).fetchone()
        if not row: return None
        item=dict(row)
        item['actions']=json.loads(item.pop('actions_json'))
        item['targets']=json.loads(item.pop('targets_json'))
        sealed={key:item[key] for key in ('resource_id','kind','display_name','provider',
            'actions','classification','ownership_ref','source_ref','connection_state','targets')}
        if digest(sealed)!=item['entry_digest']:
            return None  # fail closed: tampered metadata is not a usable resource
        return item

    def list(self, kind=None):
        with self._db() as con:
            if kind is None:
                rows=con.execute('SELECT resource_id FROM access_resources ORDER BY resource_id').fetchall()
            else:
                if kind not in KINDS: raise ValueError('invalid_kind')
                rows=con.execute('SELECT resource_id FROM access_resources WHERE kind=? ORDER BY resource_id',(kind,)).fetchall()
        items=[self.get(row['resource_id']) for row in rows]
        return {'status':'INVENTORY_ONLY_NOT_AUTHORIZATION',
                'integrity_failures':sum(x is None for x in items),
                'resources':[x for x in items if x is not None]}
