"""Optional, strictly local computer adapter & injectable external connector dispatch.

Plugin/Space tools available in ChatGPT cannot be called by this local Python process
without an independently authenticated bridge. No invented transport or implicit token.
"""
from __future__ import annotations
import hashlib
import os
from pathlib import Path


class LocalComputer:
    """Foreground operator must enable this adapter explicitly; no unattended capture."""
    def __init__(self, capture_root, enabled=False):
        self.capture_root=Path(capture_root).resolve()
        self.enabled=bool(enabled)

    def dispatch(self, action, args):
        if action=='computer.status':
            return {'status':'AVAILABLE' if self.enabled else 'NOT_CONNECTED',
                    'adapter':'local_computer','interactive_operator_required':True}
        if not self.enabled:
            return {'status':'NOT_CONNECTED','reason':'local_computer_adapter_not_enabled'}
        # Optional desktop backend, not compatible with all headless systems.
        try:
            import pyautogui as p
            p.FAILSAFE = True
            p.PAUSE = 0.2
        except (ImportError, OSError, RuntimeError) as exc:
            return {'status':'NOT_CONNECTED','reason':'desktop_backend_unavailable',
                    'detail':type(exc).__name__}
        if action=='computer.screenshot':
            if args != {}:
                return {'status':'DENIED','reason':'screenshot_takes_no_arguments'}
            self.capture_root.mkdir(mode=0o700,parents=True,exist_ok=True)
            import uuid
            dest=(self.capture_root/f'capture_{uuid.uuid4().hex}.png').resolve()
            if not dest.is_relative_to(self.capture_root):
                return {'status':'DENIED','reason':'capture_path_escape'}
            try:
                p.screenshot().save(dest)
                os.chmod(dest,0o600)
                return {'status':'EXECUTED','artifact_local':str(dest),
                        'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),
                        'disclosure':'SCREEN_CONTENT_IS_SENSITIVE_LOCAL_FILE_NOT_EXPORTED'}
            except Exception as exc:
                return {'status':'FAILED','reason':'capture_failed','exception':type(exc).__name__}
        if action=='computer.click':
            if set(args)!={'x','y'} or any(type(args[k]) is not int or not 0<=args[k]<=10000 for k in ('x','y')):
                return {'status':'DENIED','reason':'invalid_coordinates'}
            try:
                w,h=p.size()
                if args['x']>=w or args['y']>=h:return {'status':'DENIED','reason':'outside_display'}
                p.click(args['x'],args['y'])
                return {'status':'EXECUTED','observed':'not_independently_verified'}
            except Exception as exc:
                return {'status':'FAILED','reason':'click_failed','exception':type(exc).__name__}
        if action=='computer.type':
            # No passwords, shell commands, arbitrary scripts or clipboard access.
            txt=args.get('text') if isinstance(args,dict) and set(args)=={'text'} else None
            if not isinstance(txt,str) or not 1<=len(txt)<=500 or any(ord(c)<32 and c not in '\n\t' for c in txt):
                return {'status':'DENIED','reason':'invalid_text'}
            # Do not put typed content in audit/results. Reject high-risk strings.
            if any(b in txt.lower() for b in ('password', 'api_key', 'secret=', 'sudo ', 'powershell ', 'rm -rf', 'curl ')):
                return {'status':'DENIED','reason':'potential_secret_or_executable_input'}
            try:
                p.write(txt,interval=0.01)
                return {'status':'EXECUTED','characters':len(txt),
                        'observed':'not_independently_verified'}
            except Exception as exc:
                return {'status':'FAILED','reason':'typing_failed','exception':type(exc).__name__}
        return {'status':'DENIED','reason':'unknown_computer_action'}


class ConnectorDispatcher:
    """Only explicitly injected, pre-reviewed handlers can execute tool calls."""
    def __init__(self, computer=None, handlers=None):
        self.computer=computer
        self.handlers=dict(handlers or {})

    def dispatch(self, resource, action, args, idempotency_key):
        kind=resource['kind']
        if kind=='computer':
            if not self.computer:return {'status':'NOT_CONNECTED','reason':'no_computer_adapter'}
            return self.computer.dispatch(action,args)
        handler=self.handlers.get(resource['resource_id'])
        if handler is None:
            return {'status':'NOT_CONNECTED','reason':'authorized_connector_bridge_missing',
                    'provider':resource['provider']}
        return handler(action,dict(args),idempotency_key=idempotency_key)
