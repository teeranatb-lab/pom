"""OLGM sovereign control plane: intent-bound, signed, queueable tool requests.

Fail-closed. An external tool connection, a resource declaration, a CANTI dev grant
and a signature are four distinct concepts. None implies any other.
"""
from __future__ import annotations
import json, sqlite3, uuid
from datetime import datetime, timezone
from .registry import ALLOWED_ACTIONS, canonical, digest, now

SCOPE = {
    'computer.status':'computer_view', 'computer.screenshot':'computer_view',
    'computer.click':'computer_control', 'computer.type':'computer_control',
    'plugin.describe':'plugin_read', 'plugin.invoke':'plugin_invoke',
    'space.list':'space_read', 'space.read':'space_read', 'space.write':'space_write',
    'skill.describe':'skill_read', 'skill.run':'skill_run',
}
HIGH_RISK = {'computer.screenshot','computer.click','computer.type','plugin.invoke',
             'space.write','skill.run'}


def _valid_expiry(value):
    try:
        dt=datetime.fromisoformat(value)
        return dt.tzinfo is not None and dt>datetime.now(timezone.utc)
    except (TypeError,ValueError):return False


class ControlPlane:
    def __init__(self, db_path, registry, intents, canti, signatures, audit):
        self.db_path=str(db_path);self.registry=registry;self.intents=intents
        self.canti=canti;self.signatures=signatures;self.audit=audit
        with self._db() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS control_plans (
                    plan_id TEXT PRIMARY KEY, intent_id TEXT NOT NULL, intent_hash TEXT NOT NULL,
                    resource_id TEXT NOT NULL, resource_digest TEXT NOT NULL,
                    action TEXT NOT NULL, scope TEXT NOT NULL, args_json TEXT NOT NULL,
                    args_digest TEXT NOT NULL, request_digest TEXT NOT NULL UNIQUE,
                    requested_by TEXT NOT NULL, state TEXT NOT NULL,
                    principal TEXT, approval_ref TEXT, receipt_digest TEXT,
                    not_before TEXT, priority INTEGER NOT NULL DEFAULT 0,
                    result_json TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS control_approval_nonces (
                    nonce TEXT PRIMARY KEY, plan_id TEXT NOT NULL, principal TEXT NOT NULL,
                    receipt_digest TEXT NOT NULL, consumed_at TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS ix_control_queue ON control_plans
                    (state,not_before,priority,created_at);
            ''')

    def _db(self):
        db=sqlite3.connect(self.db_path,timeout=15)
        db.row_factory=sqlite3.Row
        return db

    def _row(self, plan_id):
        with self._db() as db:
            row=db.execute('SELECT * FROM control_plans WHERE plan_id=?',(plan_id,)).fetchone()
        return dict(row) if row else None

    @staticmethod
    def _validate_args(action, args):
        if not isinstance(args,dict):raise ValueError('structured_args_required')
        if action=='computer.screenshot' and args:raise ValueError('screenshot_no_args')
        if action=='computer.status' and args:raise ValueError('status_no_args')
        if action=='computer.click':
            if set(args)!={'x','y'} or any(type(args[k]) is not int or not 0<=args[k]<=10000 for k in ('x','y')):
                raise ValueError('invalid_click')
        if action=='computer.type':
            if set(args)!={'text'} or not isinstance(args['text'],str) or not 1<=len(args['text'])<=500:
                raise ValueError('invalid_text')
            val=args['text'].lower()
            if any(s in val for s in ('password','api_key','secret=','sudo ','powershell ','rm -rf','curl ')):
                raise ValueError('possible_secret_or_command')
        if action in ('space.list','plugin.describe','skill.describe') and args:
            raise ValueError('describe_list_no_arguments')
        if action=='space.read' and set(args)!={'page_id'}:
            raise ValueError('space_read_exact_page_only')
        if action in ('space.read','space.write'):
            if not args.get('page_id') or not isinstance(args['page_id'],str):
                raise ValueError('space_page_id_required')
            if action=='space.write':
                if set(args)!={'page_id','content','expected_revision'} or not isinstance(args['content'],str) or len(args['content'])>10000 or not isinstance(args['expected_revision'],str):
                    raise ValueError('space_write_requires_content_and_revision')
        if action=='plugin.invoke':
            if not isinstance(args.get('tool'),str) or not args['tool'] or len(args['tool'])>100:
                raise ValueError('plugin_tool_name_required')
        if len(canonical(args).encode('utf-8'))>16000:
            raise ValueError('arguments_too_large')

    def propose(self, intent_id, intent_hash, resource_id, action, args, requested_by,
                idempotency_key):
        resource=self.registry.get(resource_id)
        if not resource:return {'status':'DENIED','reason':'resource_not_registered'}
        if action not in ALLOWED_ACTIONS[resource['kind']] or action not in resource['actions']:
            return {'status':'DENIED','reason':'action_not_in_resource_allowlist'}
        if not all([intent_id,intent_hash,requested_by,idempotency_key]):
            return {'status':'DENIED','reason':'intent_actor_and_idempotency_required'}
        if self.intents.proof(intent_id,intent_hash)['status']!='PASS':
            return {'status':'ROOT_REENTRY','reason':'latest_intent_mismatch'}
        self._validate_args(action,args)
        if action=='plugin.invoke' and args['tool'] not in resource.get('targets',[]):
            return {'status':'DENIED','reason':'plugin_tool_not_allowlisted'}
        if action in ('space.read','space.write') and args['page_id'] not in resource.get('targets',[]):
            return {'status':'DENIED','reason':'space_page_not_allowlisted'}
        request_digest=digest({'intent_id':intent_id,'intent_hash':intent_hash,
                              'resource_id':resource_id,'action':action,'args':args,
                              'idempotency_key':idempotency_key})
        with self._db() as db:
            old=db.execute('SELECT plan_id,state FROM control_plans WHERE request_digest=?',
                           (request_digest,)).fetchone()
            if old:return {'status':old['state'],'plan_id':old['plan_id'],'idempotent':True}
            plan_id=str(uuid.uuid4());ts=now()
            db.execute('''INSERT INTO control_plans (
                plan_id,intent_id,intent_hash,resource_id,resource_digest,action,scope,
                args_json,args_digest,request_digest,requested_by,state,created_at,updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (plan_id,intent_id,intent_hash,resource_id,resource['entry_digest'],action,
                 SCOPE[action],canonical(args),digest(args),request_digest,requested_by,
                 'PENDING_APPROVAL',ts,ts))
        self.audit.append(plan_id,'CONTROL_PROPOSE',{
            'intent_hash':intent_hash,'resource_id':resource_id,'resource_digest':resource['entry_digest'],
            'action':action,'scope':SCOPE[action],'args_sha256':digest(args),
            'request_digest':request_digest,'state':'PENDING_APPROVAL'})
        return {'status':'PENDING_APPROVAL','plan_id':plan_id,'action':action,
                'scope':SCOPE[action],'args_sha256':digest(args)}

    def receipt(self, plan_id, principal, expires_at, approval_ref):
        plan=self._row(plan_id)
        if not plan:return {'status':'NOT_FOUND'}
        if plan['state']!='PENDING_APPROVAL':return {'status':'DENIED','reason':'not_pending'}
        if not principal or not approval_ref or not _valid_expiry(expires_at):
            return {'status':'DENIED','reason':'principal_approval_ref_expiry_required'}
        payload={'schema':'OLGM_CONTROL_V1','plan_id':plan_id,'principal':principal,
                 'intent_id':plan['intent_id'],'intent_hash':plan['intent_hash'],
                 'resource_id':plan['resource_id'],'resource_digest':plan['resource_digest'],
                 'action':plan['action'],'scope':plan['scope'],
                 'args_digest':plan['args_digest'],'request_digest':plan['request_digest'],
                 'approval_ref':approval_ref,'nonce':str(uuid.uuid4()),'expires_at':expires_at}
        return {'status':'SIGN_THIS_EXACT_PAYLOAD','receipt':payload,
                'signing_text_sha256':digest(payload),
                'signing_instructions':'Ed25519 signature over SHA256(canonical_json(receipt)) as UTF-8 hex bytes'}

    def approve(self, plan_id, receipt, signature_hex):
        plan=self._row(plan_id)
        if not plan:return {'status':'NOT_FOUND'}
        if plan['state']!='PENDING_APPROVAL':return {'status':'DENIED','reason':'not_pending'}
        expected={'plan_id':plan_id,'intent_id':plan['intent_id'],'intent_hash':plan['intent_hash'],
                  'resource_id':plan['resource_id'],'resource_digest':plan['resource_digest'],
                  'action':plan['action'],'scope':plan['scope'],'args_digest':plan['args_digest'],
                  'request_digest':plan['request_digest']}
        if not isinstance(receipt,dict) or receipt.get('schema')!='OLGM_CONTROL_V1' or any(receipt.get(k)!=v for k,v in expected.items()):
            return {'status':'DENIED','reason':'receipt_not_bound_to_exact_plan'}
        if not all(receipt.get(k) for k in ('principal','approval_ref','nonce')) or not _valid_expiry(receipt.get('expires_at')):
            return {'status':'DENIED','reason':'invalid_receipt'}
        if self.intents.proof(plan['intent_id'],plan['intent_hash'])['status']!='PASS':
            return {'status':'ROOT_REENTRY','reason':'stale_intent'}
        resource=self.registry.get(plan['resource_id'])
        if not resource or resource['entry_digest']!=plan['resource_digest']:
            return {'status':'DENIED','reason':'resource_changed'}
        if not self.canti.check(plan['scope'],plan['resource_id'])['allowed']:
            return {'status':'DENIED','reason':'CANTI_missing_exact_scope'}
        try:
            with self._db() as db:
                key=db.execute('SELECT public_key_hex,authority FROM trusted_public_keys WHERE principal=? AND revoked_at IS NULL',
                               (receipt['principal'],)).fetchone()
            if not key:return {'status':'DENIED','reason':'principal_key_not_trusted'}
            if key['authority']!='Origin' and (plan['action'] in HIGH_RISK or resource['classification'] in ('RESTRICTED','ORIGIN_ONLY')):
                return {'status':'DENIED','reason':'origin_signature_required_for_sensitive_action'}
            if key['authority'] not in ('Origin','approver'):
                return {'status':'DENIED','reason':'insufficient_authority'}
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
            public=Ed25519PublicKey.from_public_bytes(bytes.fromhex(key['public_key_hex']))
            # Same canonical hashing as OLGM intent receipts, no direct signature over untrusted raw JSON.
            public.verify(bytes.fromhex(signature_hex),digest(receipt).encode('utf-8'))
        except (ValueError,TypeError,ImportError):
            return {'status':'DENIED','reason':'invalid_signature_or_key'}
        except Exception as exc:
            if type(exc).__name__=='InvalidSignature':
                return {'status':'DENIED','reason':'invalid_signature_or_key'}
            raise
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            current=db.execute('SELECT state FROM control_plans WHERE plan_id=?',(plan_id,)).fetchone()
            if not current or current['state']!='PENDING_APPROVAL':
                return {'status':'DENIED','reason':'state_changed'}
            try:
                db.execute('INSERT INTO control_approval_nonces VALUES(?,?,?,?,?)',
                           (receipt['nonce'],plan_id,receipt['principal'],digest(receipt),now()))
            except sqlite3.IntegrityError:
                return {'status':'DENIED','reason':'nonce_replay'}
            db.execute('UPDATE control_plans SET state=?,principal=?,approval_ref=?,receipt_digest=?,updated_at=? WHERE plan_id=?',
                       ('APPROVED',receipt['principal'],receipt['approval_ref'],digest(receipt),now(),plan_id))
        self.audit.append(plan_id,'CONTROL_APPROVED',{'principal':receipt['principal'],
                          'receipt_sha256':digest(receipt),'origin_role':'KEY_ATTESTED_NOT_IDENTITY_CERTIFIED'})
        return {'status':'APPROVED','plan_id':plan_id,
                'note':'Trusted key proof, not independent Origin identity certification'}

    def enqueue(self, plan_id, not_before=None, priority=0):
        if not isinstance(priority,int) or not -10<=priority<=10:return {'status':'DENIED','reason':'invalid_priority'}
        timestamp=not_before or now()
        try:
            dt=datetime.fromisoformat(timestamp)
            if dt.tzinfo is None:raise ValueError('timezone required')
        except (TypeError,ValueError):return {'status':'DENIED','reason':'invalid_not_before_timezone'}
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            cur=db.execute('UPDATE control_plans SET state=?,not_before=?,priority=?,updated_at=? WHERE plan_id=? AND state=?',
                           ('QUEUED',timestamp,priority,now(),plan_id,'APPROVED'))
        if not cur.rowcount:return {'status':'DENIED','reason':'plan_not_approved_or_already_queued'}
        self.audit.append(plan_id,'CONTROL_ENQUEUED',{'not_before':timestamp,'priority':priority})
        return {'status':'QUEUED','plan_id':plan_id,'not_before':timestamp,'priority':priority}

    def cancel(self,plan_id):
        with self._db() as db:
            cur=db.execute("UPDATE control_plans SET state='CANCELLED',updated_at=? WHERE plan_id=? AND state IN ('PENDING_APPROVAL','APPROVED','QUEUED')",
                           (now(),plan_id))
        if not cur.rowcount:return {'status':'DENIED','reason':'cannot_cancel_executing_or_terminal_plan'}
        self.audit.append(plan_id,'CONTROL_CANCELLED',{'plan_id':plan_id})
        return {'status':'CANCELLED','plan_id':plan_id}

    def _principal_active(self,principal):
        with self._db() as db:
            row=db.execute('SELECT authority FROM trusted_public_keys WHERE principal=? AND revoked_at IS NULL',
                           (principal,)).fetchone()
        return bool(row and row['authority'] in ('Origin','approver'))

    def work_once(self, dispatcher):
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            row=db.execute("SELECT * FROM control_plans WHERE state='QUEUED' AND not_before<=? ORDER BY priority DESC,created_at,plan_id LIMIT 1",
                           (now(),)).fetchone()
            if not row:return {'status':'IDLE'}
            plan=dict(row)
            db.execute("UPDATE control_plans SET state='DISPATCHING',updated_at=? WHERE plan_id=?",(now(),plan['plan_id']))
        plan_id=plan['plan_id']
        # Work is dispatched at most once; crash after claim requires manual reconciliation.
        if self.intents.proof(plan['intent_id'],plan['intent_hash'])['status']!='PASS':
            result={'status':'ROOT_REENTRY','reason':'stale_intent'}
        elif not self.canti.check(plan['scope'],plan['resource_id'])['allowed']:
            result={'status':'DENIED','reason':'CANTI_grant_expired_or_revoked'}
        elif not self._principal_active(plan['principal']):
            result={'status':'DENIED','reason':'approval_key_revoked_or_missing'}
        else:
            resource=self.registry.get(plan['resource_id'])
            if not resource or resource['entry_digest']!=plan['resource_digest']:
                result={'status':'DENIED','reason':'resource_digest_changed'}
            elif not plan['receipt_digest']:
                result={'status':'DENIED','reason':'unsigned_plan'}
            elif plan['action']=='plugin.invoke' and json.loads(plan['args_json'])['tool'] not in resource['targets']:
                result={'status':'DENIED','reason':'plugin_tool_not_allowlisted'}
            elif plan['action'] in ('space.read','space.write') and json.loads(plan['args_json'])['page_id'] not in resource['targets']:
                result={'status':'DENIED','reason':'space_page_not_allowlisted'}
            else:
                try:
                    result=dispatcher.dispatch(resource,plan['action'],json.loads(plan['args_json']),
                                               plan['request_digest'])
                    if not isinstance(result,dict):result={'status':'FAILED','reason':'invalid_dispatch_response'}
                except Exception as exc:
                    result={'status':'UNKNOWN_OUTCOME','reason':'dispatch_exception_unverified_effect',
                            'exception':type(exc).__name__}
        status=result.get('status','FAILED')
        new_state=('COMPLETED' if status in ('EXECUTED','AVAILABLE','SUCCESS') else
                   'BLOCKED' if status in ('NOT_CONNECTED','DENIED','ROOT_REENTRY') else
                   'UNKNOWN_OUTCOME' if status=='UNKNOWN_OUTCOME' else 'FAILED')
        with self._db() as db:
            db.execute('UPDATE control_plans SET state=?,result_json=?,updated_at=? WHERE plan_id=?',
                       (new_state,canonical(result),now(),plan_id))
        self.audit.append(plan_id,'CONTROL_OUTCOME',{'status':new_state,'result_sha256':digest(result),
                          'note':'External effects must be verified independently'})
        return {'status':new_state,'plan_id':plan_id,'result':result}

    def work_batch(self, dispatcher,limit=1):
        if not 1<=int(limit)<=20:raise ValueError('limit_1_to_20')
        values=[]
        for _ in range(int(limit)):
            row=self.work_once(dispatcher)
            if row['status']=='IDLE':break
            values.append(row)
        return {'status':'BATCH_PROCESSED','count':len(values),'results':values}

    def status(self,limit=50):
        n=min(max(int(limit),1),200)
        with self._db() as db:
            rows=db.execute('''SELECT plan_id,resource_id,action,scope,state,principal,priority,
                            not_before,created_at,updated_at FROM control_plans
                            ORDER BY created_at DESC LIMIT ?''',(n,)).fetchall()
        return {'status':'CONTROL_INVENTORY','jobs':[dict(x) for x in rows],
                'warning':'No direct connector access implied by registration'}
