"""Local metadata-based GPT skill study: no GPT model extraction, execution, or inherited account access.

Catalog records and training proposals are append-only. Approval requires a separate
Origin-signed authorization receipt and does NOT turn a discovered ChatGPT skill into
an executable local plugin. Treat descriptions and examples as untrusted reference data.
"""
from __future__ import annotations
import hashlib, json, re, sqlite3, uuid
from datetime import datetime, timezone
from pathlib import Path
from .control.registry import canonical, digest

SNAPSHOT=Path(__file__).resolve().parents[1]/'data'/'gpt_visible_skills_2026-11-10.json'
URI_RE=re.compile(r'^skills://plugins/[a-z][a-z0-9-]{1,65}/[a-z][a-z0-9-]{1,90}$')
LICENSES={'ORIGIN_OWNED','PERMISSION_GRANTED','PUBLIC_DOMAIN','UNKNOWN'}
MAX_TEXT=2500
THAI_ALIASES={
 'google-drive':['กูเกิล','ไดรฟ์','ไฟล์','เอกสาร','ชีต','สไลด์','ตาราง'],
 'figma':['ออกแบบ','หน้าจอ','ยูไอ','ภาพ','ไดอะแกรม','กราฟ','ฟิกมา','แอป'],
 'pages':['สเปซ','เพจ','หน้า','บันทึก','นัดหมาย','ติดตาม'],
 'browser':['เบราว์เซอร์','เว็บไซต์','เว็บ','แท็บ','คลิก'],
 'writing-style':['เขียน','สำนวน','ภาษา','เรียบเรียง','อีเมล'],
 'openai-templates':['รายงาน','งบประมาณ','นำเสนอ','เอกสาร','เทมเพลต','ติดตาม'],
 'template-creator':['แม่แบบ','เทมเพลต','ต้นแบบ'],
 'presentations-router':['สไลด์','นำเสนอ','พรีเซนต์'],
 'pdf-router':['พีดีเอฟ','ไฟล์ pdf'],
 'documents-router':['เอกสาร','จดหมาย'],
 'plugin-management':['ปลั๊กอิน','เชื่อมต่อ','จัดการสิทธิ์'],
 'spreadsheets-router':['ตาราง','คำนวณ','เอ็กเซล','สเปรดชีต'],
 'stripe':['ชำระเงิน','ร้านค้า','ใบแจ้งหนี้','บิล','ธุรกรรม'],
}
# A few exact topic aliases improve Thai retrieval, without claiming general Thai understanding.
TOPIC_ALIASES={
 'google-sheets':['ชีต','ตาราง','สูตร'], 'google-docs':['เอกสาร','ข้อความ'],
 'google-slides':['สไลด์','นำเสนอ'], 'google-drive':['ไดรฟ์','ไฟล์'],
 'figma-generate-diagram':['ผังงาน','ผังโครงสร้าง','ไดอะแกรม'],
 'figma-design-to-code':['ออกแบบเป็นโค้ด','แปลงหน้าจอเป็นโค้ด'],
 'figma-generate-design':['ออกแบบ ui','หน้าแอป'],
 'write-page':['เขียนสเปซ','เพิ่มหน้า'], 'maintain-space':['อัปเดตสเปซ'],
 'organize-space':['จัดระเบียบสเปซ'], 'manage-schedules':['ตั้งเวลา','ตารางอัตโนมัติ'],
 'plugin-management':['ปลั๊กอิน','เชื่อมต่อแอป'],
 'control-browser':['ควบคุมเบราว์เซอร์','คลิกเว็บ'],
 'pdf':['พีดีเอฟ','pdf'], 'presentation':['พรีเซนเทชัน','นำเสนอ'],
 'document':['เวิร์ด','เอกสาร'], 'spreadsheet':['เอ็กเซล','ตาราง'],
 'stripe-pay':['จ่ายเงิน'], 'stripe-docs':['Stripe API'],
}


def _now(): return datetime.now(timezone.utc).isoformat()


def _validate_text(v, name, limit=MAX_TEXT):
    if not isinstance(v,str) or not v.strip() or len(v)>limit or '\x00' in v:
        raise ValueError('invalid_'+name)
    return v.strip()


class GPTSkillStudy:
    """Read skill manifests, track proposed Thai examples, plan routing, record signed approvals.

    This is symbolic, metadata-only *skill study*, not an API into ChatGPT tools.
    """
    def __init__(self, db_path, audit=None, signatures=None, manifest_path=SNAPSHOT):
        self.db_path=str(db_path);self.audit=audit;self.signatures=signatures
        self.manifest_path=Path(manifest_path)
        with self._db() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS gpt_skill_descriptors(
                    digest TEXT PRIMARY KEY, uri TEXT NOT NULL, source_ref TEXT NOT NULL,
                    body_json TEXT NOT NULL, imported_at TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS idx_gpt_skills_uri ON gpt_skill_descriptors(uri);
                CREATE TABLE IF NOT EXISTS gpt_skill_lessons(
                    lesson_id TEXT PRIMARY KEY, uri TEXT NOT NULL,
                    example_text TEXT NOT NULL, expected_skill TEXT NOT NULL,
                    source_ref TEXT NOT NULL, origin_ref TEXT NOT NULL,
                    rights_basis TEXT NOT NULL, content_hash TEXT NOT NULL,
                    proposed_by TEXT NOT NULL, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS gpt_skill_approvals(
                    lesson_id TEXT PRIMARY KEY, principal TEXT NOT NULL,
                    receipt_hash TEXT NOT NULL, approved_at TEXT NOT NULL,
                    FOREIGN KEY(lesson_id) REFERENCES gpt_skill_lessons(lesson_id));
                ''')

    def _db(self):
        db=sqlite3.connect(self.db_path,timeout=15)
        db.row_factory=sqlite3.Row
        return db

    def _manifest(self):
        obj=json.loads(self.manifest_path.read_text(encoding='utf-8'))
        entries=obj.get('skills')
        if not isinstance(entries,list) or not entries or len(entries)>2000:raise ValueError('invalid_skill_manifest')
        uris=set()
        for item in entries:
            if not isinstance(item,dict) or not URI_RE.fullmatch(item.get('uri','')):
                raise ValueError('invalid_skill_uri')
            if item['uri'] in uris:raise ValueError('duplicate_skill_uri')
            uris.add(item['uri'])
            if item.get('api_connected') is not False or item.get('availability')!='DISCOVERED_METADATA_ONLY':
                raise ValueError('manifest_cannot_assert_access')
            _validate_text(item.get('source_ref'),'source_ref',400)
        return entries

    def import_snapshot(self):
        entries=self._manifest()
        added=0
        with self._db() as db:
            for entry in entries:
                content=canonical(entry)
                h=hashlib.sha256(content.encode('utf-8')).hexdigest()
                cur=db.execute('INSERT OR IGNORE INTO gpt_skill_descriptors VALUES(?,?,?,?,?)',
                               (h,entry['uri'],entry['source_ref'],content,_now()))
                added+=cur.rowcount
        if added and self.audit:
            self.audit.append('skill-import','GPT_SKILLS_METADATA_IMPORTED',
                {'count':added,'source':'skills__list_visible_session_snapshot','metadata_only':True,
                 'source_digest':digest([e['uri'] for e in entries])})
        return {'status':'IMPORTED_METADATA_ONLY','available_descriptions':len(entries),
                'new_records':added,'execution_authorized':False,
                'origin_authority_claimed':False}

    def _catalog(self):
        with self._db() as db:
            rows=db.execute('SELECT body_json FROM gpt_skill_descriptors ORDER BY imported_at,digest').fetchall()
        # No silent overwrite of historic revisions; latest snapshot for every URI
        keyed={}
        for row in rows:
            item=json.loads(row['body_json'])
            if digest(item)!=hashlib.sha256(row['body_json'].encode('utf-8')).hexdigest():
                raise ValueError('skill_descriptor_tampered')
            keyed[item['uri']]=item
        return sorted(keyed.values(),key=lambda x:(x['provider'],x['slug']))

    def catalog(self, provider=None, query='', limit=150):
        if query and (not isinstance(query,str) or len(query)>250):raise ValueError('query_too_long')
        items=self._catalog()
        if provider:items=[x for x in items if x['provider']==provider]
        if query:
            q=query.casefold().strip()
            items=[x for x in items if q in ' '.join([x['uri'],x['title'],x['category_th'],x['tags'],x['description']]).casefold()]
        n=len(items)
        return {'status':'CATALOG_METADATA_ONLY','total':n,'snapshot_total':len(self._catalog()),
                'skills':items[:min(max(int(limit),1),250)],
                'note':'Descriptions only. No transfer of GPT model weights, private skills, sessions or tool privileges.',
                'execution_authorized':False,'provenance':'skills__list:2026-11-10'}

    def recommend(self, question, limit=5):
        q=_validate_text(question,'question',350).casefold()
        items=self._catalog()
        ranked=[]
        with self._db() as db:
            lessons=db.execute('''SELECT l.uri,l.example_text,l.content_hash,l.source_ref,l.origin_ref,l.rights_basis
                FROM gpt_skill_lessons AS l JOIN gpt_skill_approvals AS a
                ON l.lesson_id=a.lesson_id''').fetchall()
        approved_examples={}
        for row in lessons:
            d=dict(row)
            if digest({k:d[k] for k in ('uri','example_text','source_ref','origin_ref','rights_basis')})==d['content_hash']:
                approved_examples.setdefault(d['uri'],[]).append(d['example_text'].casefold())
        for item in items:
            slug=item['slug'];grp=item['provider']
            tokens=[s for s in re.split(r'[\s\-_]+',slug) if len(s)>2]
            hits=[]
            if slug in q or item['title'].casefold() in q:hits.append('exact_title')
            for t in tokens:
                if t in q:hits.append(t)
            for t in TOPIC_ALIASES.get(slug,[]):
                if t.casefold() in q:hits.append(t)
            for t in THAI_ALIASES.get(grp,[]):
                if t.casefold() in q:hits.append(t)
            # Locally approved examples can enrich retrieval, never enable external execution.
            for example in approved_examples.get(item['uri'],[]):
                if q==example or (len(q)>6 and q in example):hits.append('approved_example')
            if hits:
                specificity=sum(1 for v in hits if v in TOPIC_ALIASES.get(slug,[]) or v in ('exact_title','approved_example'))
                ranked.append((len(set(hits))+specificity*2, item['uri'], hits, item))
        ranked.sort(key=lambda r:(-r[0],r[1]))
        out=[]
        for score,_,hits,item in ranked[:min(20,max(1,int(limit)))]:
            out.append({'uri':item['uri'],'title':item['title'],'provider':item['provider'],
                        'matched_terms':sorted(set(hits)),'score':score,'status':'SUGGESTED_NOT_EXECUTED',
                        'connection':'NOT_VERIFIED','rights':'REQUIRES_USER_PERMISSION_AND_CONNECTOR'})
        return {'status':'CANDIDATE_SKILLS' if out else 'NO_MATCH','question':question,'candidates':out,
                'is_verified_skill_execution':False,'note':'Rule-based suggestion from approved metadata only, not model reasoning.'}

    def propose_lesson(self,uri,example_text,source_ref,origin_ref,rights_basis,proposed_by):
        if not isinstance(uri,str) or uri not in {s['uri'] for s in self._catalog()}:
            raise ValueError('skill_not_in_catalog')
        example=_validate_text(example_text,'example',800)
        source=_validate_text(source_ref,'source_ref',400)
        origin=_validate_text(origin_ref,'origin_ref',200)
        actor=_validate_text(proposed_by,'actor',160)
        if rights_basis not in LICENSES:raise ValueError('invalid_rights_basis')
        body={'uri':uri,'example_text':example,'source_ref':source,'origin_ref':origin,'rights_basis':rights_basis}
        h=digest(body)
        lesson_id=uuid.uuid4().hex
        with self._db() as db:
            db.execute('INSERT INTO gpt_skill_lessons VALUES(?,?,?,?,?,?,?,?,?,?)',
                       (lesson_id,uri,example,uri,source,origin,rights_basis,h,actor,_now()))
        if self.audit:self.audit.append('skill-'+lesson_id,'GPT_SKILL_LESSON_PROPOSED',
                  {'lesson_id':lesson_id,'content_hash':h,'rights_basis':rights_basis,'source_ref':source})
        return {'status':'PENDING_ORIGIN_APPROVAL','lesson_id':lesson_id,'content_hash':h,
                'executable':False,'model_trained':False}

    def lesson(self,lesson_id):
        with self._db() as db:
            r=db.execute('SELECT * FROM gpt_skill_lessons WHERE lesson_id=?',(lesson_id,)).fetchone()
            a=db.execute('SELECT principal,receipt_hash FROM gpt_skill_approvals WHERE lesson_id=?',(lesson_id,)).fetchone()
        if not r:return {'status':'NOT_FOUND'}
        x=dict(r)
        body={k:x[k] for k in ('uri','example_text','source_ref','origin_ref','rights_basis')}
        if digest(body)!=x['content_hash']:return {'status':'INTEGRITY_FAIL'}
        x['status']='LOCALLY_APPROVED_NOT_PRODUCTION_CERTIFIED' if a else 'PENDING_ORIGIN_APPROVAL'
        x['approval_principal']=a['principal'] if a else None
        return x

    def approve_lesson(self,lesson_id,receipt,signature_hex):
        # Not exposed on HTTP UI. Origin enrollment is out-of-band and must be assessed separately.
        lesson=self.lesson(lesson_id)
        if lesson['status']=='NOT_FOUND':raise ValueError('lesson_not_found')
        if lesson['status']=='INTEGRITY_FAIL':raise ValueError('lesson_tampered')
        if lesson['status']!='PENDING_ORIGIN_APPROVAL':raise ValueError('lesson_not_pending')
        if lesson['rights_basis']=='UNKNOWN':raise ValueError('rights_not_verified')
        if not self.signatures:raise PermissionError('signature_gateway_not_configured')
        if not isinstance(receipt,dict) or receipt.get('intent_hash')!=lesson['content_hash']:
            raise PermissionError('lesson_hash_not_bound')
        resource='skill.knowledge.'+lesson_id
        check=self.signatures.verify(receipt,signature_hex,expected_plan_id='skill.lesson:'+lesson_id,
                                     expected_resource=resource,consume=False)
        if check['status']!='VERIFIED_SIGNATURE':raise PermissionError(check.get('reason','signature_invalid'))
        if check.get('authority')!='Origin':raise PermissionError('origin_only_approval')
        # Check before consuming one-time authorization; local trusted enrollment ≠ independently verified identity.
        consumed=self.signatures.verify(receipt,signature_hex,expected_plan_id='skill.lesson:'+lesson_id,
                                        expected_resource=resource,consume=True)
        if consumed['status']!='CONSUMED_SIGNATURE':raise PermissionError('signature_replay')
        with self._db() as db:
            db.execute('INSERT INTO gpt_skill_approvals VALUES(?,?,?,?)',
                       (lesson_id,consumed['principal'],consumed['receipt_hash'],_now()))
        if self.audit:self.audit.append('skill-'+lesson_id,'GPT_SKILL_LESSON_LOCAL_APPROVAL',
                  {'lesson_id':lesson_id,'receipt_hash':consumed['receipt_hash'],'authority':'Origin',
                   'identity_independent_verification':'NOT_TESTED'})
        return {'status':'LOCALLY_APPROVED_NOT_PRODUCTION_CERTIFIED','lesson_id':lesson_id,
                'execution_authorized':False,'origin_identity_proven_independently':False}

    def learning_summary(self):
        with self._db() as db:
            count=db.execute('SELECT COUNT(*) FROM gpt_skill_lessons').fetchone()[0]
            approved=db.execute('SELECT COUNT(*) FROM gpt_skill_approvals').fetchone()[0]
        return {'available_skill_metadata':len(self._catalog()),'candidate_lessons':count,
                'locally_approved_lessons':approved,'pending_lessons':count-approved,
                'weight_training':'NOT_IMPLEMENTED_IN_THIS_MODULE','plugin_connection':'NOT_INHERITED',
                'origin_authority':'REQUIRES_SEPARATE_EVIDENCE'}
