"""Origin-governed value notification policy for externally used OLGM answers.

Only evidence-based *estimates* are recorded. This package does not create a
copyright claim, commercial license, certified appraisal or legal restriction.
"""
from .policy import ValueGuard, OWNER_EMAIL, THRESHOLD_THB
from .mail import SmtpSender
__all__=['ValueGuard','SmtpSender','OWNER_EMAIL','THRESHOLD_THB']
