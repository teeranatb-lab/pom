"""OLGM-VG-01: owner-first, privacy-minimized value estimates and notifications.

Trust model:
* User-declared origin/family status DOES NOT create an exemption.
* Exemptions require an Ed25519 signature from a locally enrolled Origin key.
* Evidence of value is a forecast, never a fact or certified financial benefit.
* No email is sent by evaluate(). Email dispatch is a separately gated action.
* No automated email is sent without configured authenticated SMTP.
* This package does not claim that a warning creates enforceable license terms.
"""
from __future__ import annotations
import hashlib, json, math, re, sqlite3, uuid
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

OWNER_EMAIL='teeranat.b@gmail.com'
THRESHOLD_THB=Decimal('1000000')
POLICY_VERSION='OLGM-VG-01/1.0'
NOTICE_TH=(
    'ระบบ OLGM ประเมินว่าคำตอบนี้อาจก่อให้เกิดมูลค่าทางเศรษฐกิจ '
    'เกิน 1,000,000 บาทจากสมมติฐานที่มีอยู่ (ยังไม่ใช่มูลค่าที่รับรองแล้ว) '
    'หากประสงค์นำผลลัพธ์ไปใช้ต่อในลักษณะที่อาจเกี่ยวข้องกับสิทธิของผู้สร้าง '
    'กรุณาติดต่อ Origin ที่ teeranat.b@gmail.com เพื่อหารือเงื่อนไขการใช้ประโยชน์ '
    'การแจ้งเตือนนี้ไม่ใช่ข้อห้ามทางกฎหมายหรือข้อตกลงการอนุญาตโดยตัวเอง'
)
EMAIL_RE=re.compile(r'^[A-Za-z0-9.!#$%&\'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9.-]{0,250}[A-Za-z0-9])?$')
ALLOWED_FIELDS={'incremental_net_profit_thb','verified_cost_savings_thb','implementation_cost_thb',
                'ongoing_cost_thb','success_probability'}


def _utc():return datetime.now(timezone.utc).isoformat()
def _canonical(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def _hash(v):return hashlib.sha256(_canonical(v).encode('utf-8')).hexdigest()

def _decimal(x):
    if isinstance(x,bool) or x is None:raise ValueError('numeric_estimate_required')
    try: n=Decimal(str(x))
    except (ValueError,InvalidOperation):raise ValueError('invalid_financial_value') from None
    if not n.is_finite() or n<0 or n>Decimal('1e16'):raise ValueError('invalid_financial_range')
    return n


def estimate_value(breakdown):
    if not isinstance(breakdown,dict) or set(breakdown)!=ALLOWED_FIELDS:
        raise ValueError('exact_financial_fields_required')
    v={k:_decimal(x) for k,x in breakdown.items()}
    if v['success_probability']>1:raise ValueError('probability_must_be_0_to_1')
    net=(v['incremental_net_profit_thb'] + v['verified_cost_savings_thb']
         -v['implementation_cost_thb']-v['ongoing_cost_thb'])
    net=max(Decimal(0),net)
    expected=(net*v['success_probability']).quantize(Decimal('0.01'),rounding=ROUND_HALF_UP)
    return expected


class ValueGuard:
    def __init__(self,db_path,audit=None,origin_email=OWNER_EMAIL):
        if origin_email != OWNER_EMAIL:
            # The address is a user-confirmed origin destination; it is not user supplied per request.
            raise ValueError('owner_email_is_origin_locked')
        self.db_path=str(db_path);self.audit=audit
        with self._db() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS value_exemptions (
                    subject_digest TEXT PRIMARY KEY, role TEXT NOT NULL,
                    evidence_ref TEXT NOT NULL,receipt_sha256 TEXT NOT NULL,
                    authority_principal TEXT NOT NULL,expires_at TEXT NOT NULL,created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS value_cases (
                    case_id TEXT PRIMARY KEY, subject_digest TEXT NOT NULL,
                    answer_digest TEXT NOT NULL, policy_version TEXT NOT NULL,
                    forecast_thb TEXT NOT NULL, inputs_sha256 TEXT NOT NULL,
                    evidence_refs TEXT NOT NULL, safe_summary TEXT NOT NULL,
                    identity_display TEXT, location_display TEXT,
                    channel TEXT NOT NULL, user_email TEXT, consent_share_identity INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    UNIQUE(subject_digest,answer_digest,policy_version));
                CREATE TABLE IF NOT EXISTS value_notifications (
                    notification_id TEXT PRIMARY KEY,case_id TEXT NOT NULL,
                    recipient_role TEXT NOT NULL CHECK(recipient_role IN ('OWNER','USER')),
                    channel TEXT NOT NULL CHECK(channel IN ('EMAIL','IN_APP')),
                    state TEXT NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,
                    last_error TEXT,sent_at TEXT,created_at TEXT NOT NULL,
                    FOREIGN KEY(case_id) REFERENCES value_cases(case_id),
                    UNIQUE(case_id,recipient_role));
            ''')

    def _db(self):
        db=sqlite3.connect(self.db_path,timeout=15)
        db.row_factory=sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        return db

    def _audit(self,case_id,event,data):
        if self.audit:
            # Never include emails, user names, personal information or answer text in audit.
            self.audit.append(case_id,event,data)

    @staticmethod
    def _subject_digest(subject_id):
        if not isinstance(subject_id,str) or not 1<=len(subject_id)<=256:
            raise ValueError('subject_id_required')
        return hashlib.sha256(('olgm:valueguard:subject:'+subject_id).encode()).hexdigest()

    def register_exemption(self,subject_id,role,evidence_ref,receipt,signature_hex):
        """Only an Origin-authenticated, non-replayable *external* key attestation qualifies.

        Key enrollment itself must happen through independently vetted trusted local
        ceremony, never through a user-provided claim. No private key stored here.
        """
        if role not in ('origin','family'):raise ValueError('invalid_exemption_role')
        expected={'subject_digest':self._subject_digest(subject_id),'role':role,'evidence_ref':evidence_ref}
        if not isinstance(receipt,dict) or any(receipt.get(k)!=v for k,v in expected.items()):
            return {'status':'DENIED','reason':'exemption_receipt_not_bound'}
        if not receipt.get('principal') or not receipt.get('nonce') or not receipt.get('expires_at'):
            return {'status':'DENIED','reason':'signed_receipt_incomplete'}
        try:
            exp=datetime.fromisoformat(receipt['expires_at'])
            if not exp.tzinfo or exp<=datetime.now(timezone.utc):raise ValueError()
        except (ValueError,TypeError):return {'status':'DENIED','reason':'receipt_expired'}
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
            from cryptography.exceptions import InvalidSignature
            with self._db() as db:
                key=db.execute('SELECT public_key_hex FROM trusted_public_keys WHERE principal=? AND authority=? AND revoked_at IS NULL',
                               (receipt['principal'],'Origin')).fetchone()
            if not key:return {'status':'DENIED','reason':'Origin_key_not_registered'}
            public=Ed25519PublicKey.from_public_bytes(bytes.fromhex(key['public_key_hex']))
            public.verify(bytes.fromhex(signature_hex),_hash(receipt).encode('ascii'))
        except (ValueError,TypeError,ImportError,InvalidSignature):
            return {'status':'DENIED','reason':'invalid_origin_signature'}
        digest=_hash(receipt)
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            replay=db.execute('SELECT 1 FROM value_exemptions WHERE receipt_sha256=?',(digest,)).fetchone()
            if replay:return {'status':'DENIED','reason':'receipt_replay'}
            db.execute('''INSERT INTO value_exemptions VALUES(?,?,?,?,?,?,?)
                ON CONFLICT(subject_digest) DO UPDATE SET role=excluded.role,
                evidence_ref=excluded.evidence_ref,receipt_sha256=excluded.receipt_sha256,
                authority_principal=excluded.authority_principal,
                expires_at=excluded.expires_at, created_at=excluded.created_at''',
                (expected['subject_digest'],role,evidence_ref,digest,receipt['principal'],
                 receipt['expires_at'],_utc()))
        self._audit(digest,'VALUE_EXEMPTION_ATTESTED',{'subject_digest':expected['subject_digest'],'role':role,'receipt_sha256':digest})
        return {'status':'EXEMPTION_ATTESTED','role':role}

    def _role(self,subject_id):
        with self._db() as db:
            row=db.execute('SELECT role,expires_at FROM value_exemptions WHERE subject_digest=?',
                           (self._subject_digest(subject_id),)).fetchone()
        if row and datetime.fromisoformat(row['expires_at'])>datetime.now(timezone.utc):
            return row['role']
        return 'external_or_unverified'

    def _evidence_registered(self,ref):
        try:
            with self._db() as db:
                row=db.execute('SELECT content_hash FROM evidence WHERE evidence_ref=?', (ref,)).fetchone()
            return bool(row and row['content_hash'])
        except sqlite3.Error:
            return False

    def evaluate(self,*,subject_id,answer_hash,public_safe_summary,estimate_inputs,evidence_refs,
                 consent_share_identity=False,display_name=None,coarse_location=None,
                 user_email=None,consent_user_email=False,evidence_exists=None):
        """Calculate expected benefit and stage OWNER email before any USER notice.

        evidence_exists: optional trusted callback to Meaning Space evidence registry.
        User-provided labels of Origin/family are deliberately ignored.
        Only PUBLIC-safe summaries may be entered. No raw answer or secret ingested.
        """
        role=self._role(subject_id)
        if role in ('origin','family'):
            return {'status':'EXEMPT','role':role,'reason':'verified_origin_or_family'}
        if not isinstance(answer_hash,str) or not re.fullmatch('[a-f0-9]{64}',answer_hash):
            raise ValueError('answer_sha256_hex_required')
        if not isinstance(public_safe_summary,str) or not 1<=len(public_safe_summary)<=300:
            raise ValueError('public_safe_summary_1_to_300_required')
        if not isinstance(evidence_refs,list) or not evidence_refs or not all(
                isinstance(r,str) and 1<=len(r)<=200 for r in evidence_refs):
            return {'status':'NEEDS_EVIDENCE','reason':'evidence_refs_required'}
        resolver=evidence_exists if evidence_exists is not None else self._evidence_registered
        if not all(resolver(r) for r in evidence_refs):
            return {'status':'NEEDS_EVIDENCE','reason':'evidence_ref_not_found'}
        expected=estimate_value(estimate_inputs)
        if expected<=THRESHOLD_THB:
            self._audit(answer_hash,'VALUE_BELOW_THRESHOLD',{'estimate_thb':str(expected),
                'threshold_thb':str(THRESHOLD_THB),'inputs_sha256':_hash(estimate_inputs)})
            return {'status':'BELOW_THRESHOLD','estimated_thb':str(expected),'threshold_thb':str(THRESHOLD_THB)}
        if user_email and (not EMAIL_RE.fullmatch(user_email) or len(user_email)>254):
            raise ValueError('invalid_user_email')
        if user_email and not consent_user_email:raise ValueError('user_email_requires_explicit_consent')
        if (display_name or coarse_location) and not consent_share_identity:
            # Never store personal identity/location without disclosure authorization.
            display_name=None;coarse_location=None
        if consent_share_identity:
            for v in (display_name,coarse_location):
                if v is not None and (not isinstance(v,str) or len(v)>120):
                    raise ValueError('identity_location_too_long')
        subj=self._subject_digest(subject_id)
        case_id=str(uuid.uuid4());stamp=_utc()
        channel='EMAIL' if user_email and consent_user_email else 'IN_APP'
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            existing=db.execute('''SELECT case_id,forecast_thb FROM value_cases
                WHERE subject_digest=? AND answer_digest=? AND policy_version=?''',
                (subj,answer_hash,POLICY_VERSION)).fetchone()
            if existing:
                return {'status':'ALREADY_QUEUED','case_id':existing['case_id'],
                        'estimated_thb':existing['forecast_thb'],'idempotent':True}
            db.execute('''INSERT INTO value_cases VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (case_id,subj,answer_hash,POLICY_VERSION,str(expected),_hash(estimate_inputs),
                 _canonical(evidence_refs),public_safe_summary,display_name,coarse_location,
                 channel,user_email,1 if consent_share_identity else 0,stamp))
            db.execute('INSERT INTO value_notifications VALUES(?,?,?,?,?,?,?,?,?)',
                       (str(uuid.uuid4()),case_id,'OWNER','EMAIL','QUEUED',0,None,None,stamp))
            db.execute('INSERT INTO value_notifications VALUES(?,?,?,?,?,?,?,?,?)',
                       (str(uuid.uuid4()),case_id,'USER',channel,'WAIT_OWNER',0,None,None,stamp))
        self._audit(case_id,'VALUE_ALERT_QUEUED',{'case_id':case_id,'estimated_thb':str(expected),
                   'threshold_thb':str(THRESHOLD_THB),'evidence_count':len(evidence_refs),
                   'origin_first':True,'policy_version':POLICY_VERSION})
        return {'status':'OWNER_ALERT_QUEUED','case_id':case_id,'estimated_thb':str(expected),
                'threshold_thb':str(THRESHOLD_THB),'user_notice':'WAIT_OWNER_DELIVERY',
                'origin_email':OWNER_EMAIL,'assessment':'FORECAST_NOT_CERTIFIED'}

    def case_status(self,case_id):
        with self._db() as db:
            c=db.execute('SELECT case_id,forecast_thb,policy_version,created_at FROM value_cases WHERE case_id=?',(case_id,)).fetchone()
            states=db.execute('SELECT recipient_role,channel,state,sent_at,attempts FROM value_notifications WHERE case_id=? ORDER BY recipient_role',(case_id,)).fetchall()
        if not c:return {'status':'NOT_FOUND'}
        return {'status':'FOUND','case_id':case_id,'estimated_thb':c['forecast_thb'],
                'notifications':[dict(s) for s in states]}

    def _owner_body(self,c):
        return ('แจ้งจาก OLGM Ultimate — ประเมินผลลัพธ์มูลค่าสูง (ยังไม่ใช่การรับรอง)\n'
             f'Case: {c["case_id"]}\nประมาณการ: {c["forecast_thb"]} บาท\n'
             f'หัวข้อ/ผลลัพธ์สรุปที่เปิดเผยได้: {c["safe_summary"]}\n'
             f'ผู้ใช้: {c["identity_display"] or "ไม่เปิดเผย/ไม่ได้ให้ข้อมูล"}\n'
             f'พื้นที่: {c["location_display"] or "ไม่เปิดเผย/ไม่ได้ให้ข้อมูล"}\n'
             f'รหัสแฝงผู้ใช้: {c["subject_digest"][:16]}\n'
             f'อ้างอิงหลักฐาน: {c["evidence_refs"]}\n'
             'หมายเหตุ: เป็นการประเมินตามสมมติฐานที่บันทึก ไม่ใช่หลักฐานมูลค่าที่เกิดขึ้นจริง\n')

    def dispatch_next(self,sender,*,allowed=False):
        """Invoke explicitly authorized SMTP send on OWNER-first queue.

        `allowed` must come from an actual authorization gateway; never set true
        from untrusted user input. No network operations in any other method.
        """
        if not allowed:return {'status':'DENIED','reason':'explicit_send_authorization_required'}
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            task=db.execute('''SELECT n.notification_id,n.case_id,n.recipient_role,n.channel,n.state,
                c.* FROM value_notifications n JOIN value_cases c USING(case_id)
                WHERE n.state='QUEUED' ORDER BY
                CASE n.recipient_role WHEN 'OWNER' THEN 0 ELSE 1 END,
                n.created_at,n.notification_id LIMIT 1''').fetchone()
            if not task:return {'status':'NO_QUEUED_EMAIL'}
            # Claim task before any side effect. Crash may require manual reconciliation;
            # this is at-most-once automatic delivery attempt, not exactly-once email.
            upd=db.execute("UPDATE value_notifications SET state='SENDING',attempts=attempts+1 WHERE notification_id=? AND state='QUEUED'",
                           (task['notification_id'],))
            if not upd.rowcount:return {'status':'RETRY'}
            task=dict(task)
        if task['recipient_role']=='OWNER':
            to=OWNER_EMAIL
            subject=f'OLGM: แจ้งผลประเมินมูลค่าเกิน 1 ล้านบาท — Case {task["case_id"]}'
            body=self._owner_body(task)
        else:
            if not task['user_email']:
                return {'status':'DENIED','reason':'user_email_unavailable'}
            to=task['user_email']
            subject=f'แจ้งผลประเมิน OLGM — Case {task["case_id"]}'
            body=NOTICE_TH+'\nCase: '+task['case_id']+'\n'
        try:
            sender.send(to,subject,body)
        except Exception as exc:
            with self._db() as db:
                db.execute("UPDATE value_notifications SET state='DELIVERY_UNCERTAIN',last_error=? WHERE notification_id=?",
                           (type(exc).__name__,task['notification_id']))
            self._audit(task['case_id'],'VALUE_SEND_UNCERTAIN',{'recipient_role':task['recipient_role'],
                   'reason':type(exc).__name__})
            return {'status':'DELIVERY_UNCERTAIN','role':task['recipient_role'],
                    'reason':'manual_reconcile_before_retry'}
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute("UPDATE value_notifications SET state='SENT',sent_at=? WHERE notification_id=? AND state='SENDING'",
                       (_utc(),task['notification_id']))
            if task['recipient_role']=='OWNER':
                db.execute("UPDATE value_notifications SET state='QUEUED' WHERE case_id=? AND recipient_role='USER' AND channel='EMAIL' AND state='WAIT_OWNER'",
                           (task['case_id'],))
                db.execute("UPDATE value_notifications SET state='AVAILABLE' WHERE case_id=? AND recipient_role='USER' AND channel='IN_APP' AND state='WAIT_OWNER'",
                           (task['case_id'],))
        self._audit(task['case_id'],'VALUE_EMAIL_SENT',{'recipient_role':task['recipient_role'],
                   'notification_id':task['notification_id'],'owner_first':True})
        return {'status':'EMAIL_SENT','case_id':task['case_id'],'recipient_role':task['recipient_role']}

    def user_notice(self,case_id,subject_id):
        """Never reveal a notice to a different account or before owner send."""
        with self._db() as db:
            c=db.execute('SELECT subject_digest FROM value_cases WHERE case_id=?',(case_id,)).fetchone()
            n=db.execute("SELECT state,channel FROM value_notifications WHERE case_id=? AND recipient_role='USER'",(case_id,)).fetchone()
        if not c or not n:return {'status':'NOT_FOUND'}
        if c['subject_digest']!=self._subject_digest(subject_id):return {'status':'DENIED'}
        if n['state'] not in ('AVAILABLE','SENT'):
            return {'status':'WAIT_OWNER_DELIVERY'}
        return {'status':'AVAILABLE','text':NOTICE_TH,'case_id':case_id,'delivery_channel':n['channel']}

    def pending(self):
        with self._db() as db:
            rows=db.execute('''SELECT recipient_role,channel,state,COUNT(*) n
                FROM value_notifications GROUP BY recipient_role,channel,state
                ORDER BY recipient_role,channel,state''').fetchall()
        return {'status':'OK','pending_summary':[dict(r) for r in rows]}
