"""Real SMTP transport; never enabled or configured automatically.

No email send occurs on import; credentials are sourced from operator-secured env.
"""
import os, smtplib
from email.message import EmailMessage
from email.utils import parseaddr

class SmtpSender:
    def __init__(self,host,port,username,password,sender,mode='starttls'):
        if not host or not username or not password or not sender:
            raise ValueError('authenticated_SMTP_configuration_required')
        if mode not in ('starttls','ssl') or not ((mode=='starttls' and int(port)==587) or
                                                 (mode=='ssl' and int(port)==465)):
            raise ValueError('TLS_SMTP_port_required')
        self.host=host;self.port=int(port);self.username=username
        self.password=password;self.sender=sender;self.mode=mode

    @classmethod
    def from_environment(cls):
        return cls(os.getenv('OLGM_SMTP_HOST'),os.getenv('OLGM_SMTP_PORT',587),
                   os.getenv('OLGM_SMTP_USERNAME'),os.getenv('OLGM_SMTP_PASSWORD'),
                   os.getenv('OLGM_SMTP_FROM'),os.getenv('OLGM_SMTP_MODE','starttls'))

    def send(self,to,subject,body):
        if not isinstance(to,str) or '\n' in to or '\r' in to:
            raise ValueError('invalid_recipient')
        msg=EmailMessage()
        msg['From']=self.sender;msg['To']=to;msg['Subject']=subject
        msg.set_content(body)
        if self.mode=='ssl':
            with smtplib.SMTP_SSL(self.host,self.port,timeout=15) as smtp:
                smtp.login(self.username,self.password)
                smtp.send_message(msg)
        else:
            with smtplib.SMTP(self.host,self.port,timeout=15) as smtp:
                smtp.ehlo();smtp.starttls();smtp.ehlo()
                smtp.login(self.username,self.password)
                smtp.send_message(msg)
