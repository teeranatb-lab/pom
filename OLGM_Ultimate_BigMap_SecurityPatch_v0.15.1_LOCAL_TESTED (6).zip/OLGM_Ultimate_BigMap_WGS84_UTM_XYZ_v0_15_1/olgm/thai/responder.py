"""Offline Thai answer service. Responds in Thai, with explicit epistemic status.

No claim of human-level Thai reasoning; no public data retrieved; no model called.
"""
import ast
import re
from decimal import Decimal,InvalidOperation
from .nlu import ThaiIntentRouter
from .text import normalize

_RESPONSES = {
  'greet':'สวัสดีครับ ผมช่วยจำแนกเจตนา ค้นคืนตัวอย่างที่ได้รับอนุมัติ และเสนอโปรแกรม Python จากรูปแบบที่ตรวจสอบไว้ได้',
  'thanks':'ยินดีครับ',
  'help':'รองรับการจำแนกเจตนาภาษาไทย การตอบจากตัวอย่างที่อนุมัติ การคำนวณจำกัดขอบเขต และการเขียน Python จากรูปแบบที่กำหนดไว้',
  'olgm_core0':'Core 0 เป็นฐานเชิงแนวคิด ไม่ใช่ฐานข้อมูลหรือ API ที่เอเจนต์เข้าไปอ่านหรือเขียนได้ การเปลี่ยนแปลงต้องผ่านอำนาจที่พิสูจน์ได้ของ Origin',
  'olgm_origin':'Origin และ Origin Intent เป็นรากสิทธิ์ของสถาปัตยกรรม ระบบไม่อ้างตัวเป็น Origin และไม่รับคำสั่งในข้อความแทนหลักฐานอนุญาตที่ตรวจสอบได้',
  'olgm_sovereign':'อธิปไตยทางปัญญากำหนดให้รักษาที่มาของแนวคิด สิทธิการเข้าถึง ขอบเขตการใช้ข้อมูล และสิทธิการอนุมัติของ Origin; ไม่มีการส่งข้อมูลออกจากเครื่องโดยปริยาย',
  'olgm_canonical':'Canonical และ Archive เป็นแหล่งอ้างอิงที่ห้ามเขียนทับโดยปริยาย รุ่นใหม่ต้อง Append + Inherit + Delta และบันทึกหลักฐานการเปลี่ยนแปลง',
  'olgm_meaning':'Meaning Space เก็บแก่นและเส้นความสัมพันธ์ด้วยรหัสคงที่ การเปลี่ยนหมวดไม่ควรทำให้ความสัมพันธ์เปลี่ยนโดยไม่มีเหตุผลและหลักฐาน',
  'olgm_intent_lock':'Intent Lock ต้องรักษาเจตนาล่าสุดและข้อจำกัดเดิม การเปลี่ยนแปลงต้องเก็บเป็นเหตุการณ์ใหม่ ไม่ใช่ลบประวัติ',
  'olgm_otfa':'OTFA ตรวจข้ออ้างแยกระนาบเชิงประจักษ์ ทฤษฎี และความสอดคล้อง การมีเอกสารไม่เท่ากับข้ออ้างได้รับการพิสูจน์',
  'olgm_canti':'CANTI ต้องตรวจสิทธิ์และขอบเขตก่อนดำเนินการ ไม่มีสิทธิ์เพิ่มเป้าหมายหรืออนุมัติแทน Origin โดยอัตโนมัติ',
  'olgm_provenance':'Provenance เก็บที่มา การแปลง ผลการพิสูจน์ ผู้อนุมัติ และผลลัพธ์ให้ตรวจย้อนกลับได้',
  'olgm_selflearn':'G-06 เรียนรู้จากโจทย์และผลทดสอบได้ภายในขอบเขตของ Primitive/รูปแบบที่มี แต่ต้องวัดผลกับชุดทดสอบแยกและขออนุมัติก่อนใช้แพตช์จริง',
  'code_write':'สามารถเสนอไฟล์ Python จากรูปแบบมาตรฐาน เช่น รวมตัวเลข เรียงข้อมูล แยกกลุ่ม และกรองคอลัมน์ หากโจทย์เกินขอบเขตต้องใช้ตัวสร้างโค้ดที่มีความสามารถเพิ่มเติมและตรวจรับก่อนใช้งาน',
  'code_security':'การเขียนหรือแก้โค้ดต้องตรวจสิทธิ์ ความถูกต้องของซอร์ส การทดสอบ Regression และการย้อนกลับก่อนเปลี่ยนระบบจริง',
  'procurement_egp':'การเกี่ยวข้องกับ e-GP ต้องแยกงานก่อน e-GP ระหว่าง e-GP และตรวจรับหลัง e-GP ให้ครบตามระเบียบปัจจุบัน โดยไม่อ้างว่าระบบนี้ตรวจรับตามกฎหมายแล้ว',
  'gis_crs':'งาน CRS ต้องกำหนดระบบพิกัดต้นทาง ปลายทาง และตรวจสอบความถูกต้องของ Datum Transform ด้วยหมุดควบคุมก่อนใช้สำรวจจริง',
  'privacy':'ข้อมูลส่วนบุคคลและข้อมูลจำกัดสิทธิ์ต้องใช้ในขอบเขตที่ได้รับอนุญาต ไม่ส่งไปโมเดลหรือ API ภายนอกโดยปริยาย',
  'release':'ระบบจะยังไม่ผ่าน S-10 หากไม่มีหลักฐานการทดสอบโมเดลจริง การยืนยันสิทธิ์ และการตรวจรับอิสระตามเกณฑ์',
}

_NUMBER_WORDS = {'ศูนย์':'0','หนึ่ง':'1','สอง':'2','สาม':'3','สี่':'4','ห้า':'5',
                 'หก':'6','เจ็ด':'7','แปด':'8','เก้า':'9','สิบ':'10'}
_OPERATORS={'บวก':'+','ลบ':'-','คูณ':'*','หาร':'/','×':'*','÷':'/'}

class ThaiMath:
    @staticmethod
    def expression(text):
        s=normalize(text).translate(str.maketrans('๐๑๒๓๔๕๖๗๘๙','0123456789'))
        # Pure arithmetic command stripping, not code execution.
        for k,v in _OPERATORS.items():s=s.replace(normalize(k),' '+v+' ')
        for word in sorted(_NUMBER_WORDS,key=len,reverse=True):
            s=s.replace(normalize(word),' '+_NUMBER_WORDS[word]+' ')
        clauses=['คำนวณ','เท่ากับเท่าไหร่','เท่าไร','เท่าไหร่','ได้เท่าไร','คิดเลข','ผลลัพธ์','ได้เท่าไหร่']
        s=re.sub('|'.join(re.escape(normalize(x)) for x in clauses),'',s)
        s=s.replace('=','').strip()
        s=''.join(s.split())
        if not s or len(s)>100 or not re.fullmatch(r'[0-9.()+*/%\-]+',s):
            return None
        return s

    @classmethod
    def compute(cls,text):
        exp=cls.expression(text)
        if exp is None:return None
        try:
            tree=ast.parse(exp,mode='eval')
            def walk(n,depth=0):
                if depth>12:raise ValueError('too_deep')
                if isinstance(n,ast.Constant) and type(n.value) in (int,float):
                    return Decimal(str(n.value))
                if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.UAdd,ast.USub)):
                    v=walk(n.operand,depth+1)
                    return v if isinstance(n.op,ast.UAdd) else -v
                if isinstance(n,ast.BinOp) and isinstance(n.op,(ast.Add,ast.Sub,ast.Mult,ast.Div,ast.Mod)):
                    a=walk(n.left,depth+1);b=walk(n.right,depth+1)
                    if isinstance(n.op,ast.Add):out=a+b
                    elif isinstance(n.op,ast.Sub):out=a-b
                    elif isinstance(n.op,ast.Mult):out=a*b
                    elif isinstance(n.op,ast.Div):out=a/b
                    else:out=a%b
                    if abs(out)>Decimal('1e18'):raise ValueError('out_of_range')
                    return out
                raise ValueError('invalid_operator')
            value=walk(tree.body)
            return {'status':'DETERMINISTIC_MATH','expression':exp,'result':format(value.normalize(),'f'),
                    'calculation_verified_locally':True}
        except (SyntaxError,ValueError,InvalidOperation,ArithmeticError,ZeroDivisionError):
            return {'status':'MATH_REJECTED','expression':exp,'reason':'invalid_or_unsafe_expression'}

class ThaiResponder:
    def __init__(self,memory=None,router=None,lexicon=None):
        self.memory=memory
        self.lexicon=lexicon
        self.router=router or ThaiIntentRouter()
    def answer(self,text):
        routing=self.router.detect(text)
        if self.lexicon:
            normalized=normalize(text)
            # This is a narrow, inspectable Thai definition query; unknown words abstain.
            term=normalized
            for prefix in ('คำว่า','ความหมายของ'):
                if term.startswith(normalize(prefix)):term=term[len(normalize(prefix)):].strip()
            for suffix in ('แปลว่าอะไร','หมายถึงอะไร','คืออะไร','หมายความว่าอะไร'):
                if term.endswith(normalize(suffix)):term=term[:-len(normalize(suffix))].strip()
            resolved=self.lexicon.resolve(term)
            if resolved.get('status')=='LINKED_TO_EXISTING_CID':
                return {'status':'ANSWER_FROM_APPROVED_LEXICAL_LINK','answer_th':
                        f"{term} เชื่อมกับแก่น {resolved['core_surface']}: {resolved['definition'] or 'ยังไม่มีนิยาม'}",
                        'intent':'definition','cid':resolved['cid'],
                        'origin_ref':resolved['origin_ref'],'source_ref':resolved['source_ref'],
                        'verified_fact':False,'network_called':False,'model_called':False}
        if self.memory:
            matched=self.memory.approved_match(text)
            if matched:
                return {'status':'ANSWER_FROM_APPROVED_EXAMPLE','answer_th':matched['text'],
                        'intent':routing['intent'],'provenance':{k:matched[k] for k in
                         ('example_id','source_ref','origin_ref','license','match_score','classification')},
                        'verified_fact':False,'network_called':False,'model_called':False}
        math=ThaiMath.compute(text)
        if math and math['status']=='DETERMINISTIC_MATH':
            return {'status':'DETERMINISTIC_ANSWER','answer_th':f"ผลการคำนวณคือ {math['result']}",
                    'intent':'calculate','math':math,'verified_fact':True,'network_called':False,
                    'model_called':False}
        key=routing['intent']
        if key in _RESPONSES:
            return {'status':'PATTERN_GUIDANCE_NOT_FACT_VERIFIED','answer_th':_RESPONSES[key],
                    'intent':key,'pattern_evidence':routing['candidates'][:1],
                    'verified_fact':False,'network_called':False,'model_called':False}
        if key:
            p=routing['candidates'][0]
            return {'status':'NEEDS_CONTEXT_OR_TOOL','answer_th':f"ผมจำแนกโจทย์เป็น '{p['purpose']}' ได้ แต่ยังไม่มีหลักฐานหรือเครื่องมือเพียงพอที่จะตอบเฉพาะเรื่องนี้อย่างถูกต้อง กรุณาระบุข้อมูลหรือแหล่งอ้างอิงสำหรับงานดังกล่าว",
                    'intent':key,'pattern_evidence':routing['candidates'][:1],
                    'verified_fact':False,'network_called':False,'model_called':False}
        return {'status':'INSUFFICIENT','answer_th':'ยังไม่พบรูปแบบที่รองรับหรือคำตอบที่ได้รับอนุมัติ จึงไม่สร้างข้อเท็จจริงขึ้นเอง',
                'intent':None,'verified_fact':False,'network_called':False,'model_called':False}
