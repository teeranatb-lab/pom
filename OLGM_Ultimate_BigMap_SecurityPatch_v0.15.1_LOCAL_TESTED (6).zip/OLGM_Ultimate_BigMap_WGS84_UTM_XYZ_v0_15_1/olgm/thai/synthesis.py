"""Bounded symbolic program synthesis from approved local integer I/O examples.

This searches a fixed safe expression grammar. It is a real program search,
not a hardcoded answer and not novel Python code generation without constraints.
Generalization is NEVER inferred without an independent validation set.
"""
from collections import deque
import ast
import hashlib
import re
from ..self_learn.primitives import PrimitiveRegistry

_EXPRESSIONS={
    'identity':lambda x:x,
    'plus_one':lambda x:f'({x}+1)',
    'minus_one':lambda x:f'({x}-1)',
    'double':lambda x:f'({x}*2)',
    'square':lambda x:f'({x}*{x})',
    'negate':lambda x:f'(-{x})',
    'absolute':lambda x:f'abs({x})',
    'mod_two':lambda x:f'({x}%2)',
    'triple':lambda x:f'({x}*3)',
}

class ThaiProgramSynthesizer:
    def __init__(self,registry=None):self.registry=registry or PrimitiveRegistry()

    @staticmethod
    def _check_pairs(pairs,name):
        if not isinstance(pairs,list) or not 1<=len(pairs)<=64:
            raise ValueError(name+'_requires_1_to_64_examples')
        samples=[]
        for item in pairs:
            if not isinstance(item,(tuple,list)) or len(item)!=2 or any(type(v) is not int or abs(v)>100000 for v in item):
                raise ValueError(name+'_requires_bounded_integer_pairs')
            samples.append(tuple(item))
        if len(set(x for x,_ in samples))<len(samples):
            raise ValueError(name+'_duplicate_inputs_not_allowed')
        return samples

    def synthesize(self,train,validation=None,origin_ref=None,max_depth=4):
        if not isinstance(origin_ref,str) or not re.fullmatch(r'[\w./:@#-]{1,160}',origin_ref):
            raise ValueError('origin_ref_required')
        training=self._check_pairs(train,'train')
        validation=self._check_pairs(validation,'validation') if validation is not None else None
        if validation and set(x for x,_ in training)&set(x for x,_ in validation):
            raise ValueError('train_and_validation_must_be_disjoint')
        if type(max_depth) is not int or not 1<=max_depth<=5:raise ValueError('invalid_max_depth')
        names=[x for x in self.registry.names() if x in _EXPRESSIONS]
        # Enumerate shortest working programs, then cost. No arbitrary Python source execution.
        queue=deque([()]); seen_outputs=set(); scored=0; best=None; best_matches=-1
        while queue and scored<25000:
            steps=queue.popleft()
            if steps:
                outputs=[]
                try:
                    for x,_ in training:
                        v=x
                        for step in steps:v=self.registry.apply(step,v)
                        outputs.append(v)
                except (ValueError,OverflowError):
                    continue
                signature=tuple(outputs)
                if signature in seen_outputs:continue
                seen_outputs.add(signature)
                scored+=1
                correct=sum(v==expected for v,(_,expected) in zip(outputs,training))
                if correct>best_matches:
                    best_matches=correct;best=steps
                if correct==len(training):
                    best=steps;break
            if len(steps)<max_depth:
                for name in names:queue.append((*steps,name))
        if best is None:return {'status':'UNSUPPORTED','reason':'no_program_candidate'}
        exact=best_matches==len(training)
        if not exact:
            return {'status':'NO_EXACT_PROGRAM','best_training_accuracy':best_matches/len(training),
                    'searched_unique_candidates':scored,'max_depth':max_depth,
                    'note':'No invented code returned when constraints unmet'}
        expr='x'
        for step in best:expr=_EXPRESSIONS[step](expr)
        source=(f'"""OLGM bounded synthetic candidate; Origin ref {origin_ref}.\n'
                f'Generated from local I/O examples; not production certified.\n"""\n\n'
                f'def process(x):\n    return {expr}\n')
        ast.parse(source)
        val_ok=None
        if validation is not None:
            results=[]
            for x,y in validation:
                try:
                    v=x
                    for step in best:v=self.registry.apply(step,v)
                    results.append(v==y)
                except (ValueError,OverflowError):results.append(False)
            val_ok=sum(results)/len(results)
        return {'status':'CODE_CANDIDATE','mechanism':'BOUNDED_SYMBOLIC_PROGRAM_SEARCH',
                'program_steps':list(best),'source_sha256':hashlib.sha256(source.encode()).hexdigest(),
                'code':source,'origin_ref':origin_ref,'train_examples':len(training),
                'training_accuracy':1.0,'validation_accuracy':val_ok,
                'validation_note':'user_supplied_validation_not_blind' if validation else 'NOT_VALIDATED',
                'searched_unique_candidates':scored,'max_depth':max_depth,
                'verified_novel_generation':False,'source_classification':'LOCAL_GENERATED_CANDIDATE'}
