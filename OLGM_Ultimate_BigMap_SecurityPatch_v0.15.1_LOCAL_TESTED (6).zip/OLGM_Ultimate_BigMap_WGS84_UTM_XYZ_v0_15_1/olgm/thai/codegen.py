"""Constrained offline Python code synthesis from reviewed algorithmic blueprints.

Source is a user-visible *proposal*; never execute it or overwrite repo files.
No eval/exec, no access to Origin/Core 0/Canonical, no arbitrary Python payload.
Unknown requirements return UNSUPPORTED instead of inventing capabilities.
"""
from __future__ import annotations
import ast
import hashlib
import json
import os
import re
import tempfile
import textwrap
from dataclasses import dataclass
from pathlib import Path
from .text import normalize

@dataclass(frozen=True)
class CodePattern:
    key:str
    description_th:str
    aliases:tuple[str,...]
    body:str
    # deterministic sample for independent test, expected output
    sample_input:object
    sample_output:object

# All functions accept process(data); selected patterns accept a reviewed static field value.
_RAW = [
 ('identity','ส่งคืนข้อมูล','คืนข้อมูล|แสดงข้อมูล', 'return data', [2,1],[2,1]),
 ('sort','เรียงตัวเลขจากน้อยไปมาก','เรียงข้อมูล|เรียงลำดับ|sort', 'return sorted(data)',[3,1,2],[1,2,3]),
 ('sort_desc','เรียงตัวเลขจากมากไปน้อย','เรียงจากมากไปน้อย|เรียงย้อนกลับ', 'return sorted(data, reverse=True)',[3,1,2],[3,2,1]),
 ('reverse','กลับลำดับ','กลับลำดับ|reverse', 'return list(reversed(data))',[1,2,3],[3,2,1]),
 ('unique','ตัดข้อมูลซ้ำ','ลบค่าซ้ำ|ข้อมูลไม่ซ้ำ|unique', 'return list(dict.fromkeys(data))',[2,1,2],[2,1]),
 ('count','นับจำนวน','นับจำนวน|count', 'return len(data)',[1,2,3],3),
 ('sum','รวมตัวเลข','รวมตัวเลข|หาผลรวม|sum', 'return sum(data)',[1,2,3],6),
 ('average','หาค่าเฉลี่ย','ค่าเฉลี่ย|average', 'return (sum(data)/len(data)) if data else None',[2,4,6],4.0),
 ('minimum','หาค่าน้อยสุด','ค่าน้อยสุด|min', 'return min(data) if data else None',[4,1,5],1),
 ('maximum','หาค่ามากสุด','ค่ามากสุด|max', 'return max(data) if data else None',[4,1,5],5),
 ('positive','กรองค่าบวก','จำนวนบวก|กรองค่าบวก', 'return [x for x in data if x>0]',[-2,0,3,1],[3,1]),
 ('negative','กรองค่าลบ','จำนวนลบ|กรองค่าลบ', 'return [x for x in data if x<0]',[-2,0,3,1],[-2]),
 ('even','กรองเลขคู่','เลขคู่|กรองเลขคู่', 'return [x for x in data if x%2==0]',[1,2,3,4],[2,4]),
 ('odd','กรองเลขคี่','เลขคี่|กรองเลขคี่', 'return [x for x in data if x%2!=0]',[1,2,3,4],[1,3]),
 ('strip','ลบช่องว่างต้นท้ายข้อความ','ตัดช่องว่าง|ลบช่องว่าง|strip', 'return data.strip()','  ไทย  ','ไทย'),
 ('lower','แปลงภาษาอังกฤษเป็นตัวเล็ก','ตัวพิมพ์เล็ก|lowercase|lower', 'return data.casefold()','Hello','hello'),
 ('normalize_thai','ปรับอักขระและเว้นวรรค Unicode','ปรับข้อความไทย|normalize thai|normalize unicode',
  'import unicodedata\nreturn " ".join(unicodedata.normalize("NFKC", data).split())','  สวัสดี    โลก  ','สวัสดี โลก'),
 ('char_count','นับจำนวนอักขระ','นับตัวอักษร|ความยาวข้อความ', 'return len(data)','ภาษาไทย',7),
 ('word_count','นับคำที่แยกด้วยช่องว่าง (ไม่ใช่ตัวตัดคำไทย)','นับคำ|word count',
  'return len(data.split())','สวัสดี โลก',2),
 ('filter_nonempty','กรองค่าไม่ว่าง','กรองค่าว่าง|ลบค่าว่าง', 'return [x for x in data if x is not None and x != ""]',[None,'',0,'ไทย'],[0,'ไทย']),
 ('flatten','แผ่ลิสต์สองมิติ','แปลงลิสต์ซ้อน|flatten', 'return [item for group in data for item in group]',[[1,2],[3]],[1,2,3]),
 ('chunk','แบ่งรายการเป็นชุด','แบ่งข้อมูลเป็นชุด|chunk', 'size=PARAM_SIZE\nreturn [data[i:i+size] for i in range(0,len(data),size)]',[1,2,3,4,5],[[1,2],[3,4],[5]]),
 ('paginate','แบ่งหน้ารายการ','แบ่งหน้า|paginate', 'size=PARAM_SIZE\npage=PARAM_PAGE\nreturn data[(page-1)*size:page*size]',[1,2,3,4,5],[1,2]),
 ('sum_by_key','รวมค่าตามคอลัมน์','รวมคอลัมน์|รวมตามฟิลด์|sum by key',
  'key=PARAM_KEY\nreturn sum(row[key] for row in data)',[{'price':2},{'price':3}],5),
 ('sort_by_key','เรียงดิกชันนารีตามคอลัมน์','เรียงตามคอลัมน์|sort by key',
  'key=PARAM_KEY\nreturn sorted(data,key=lambda row:row[key])',[{'price':5},{'price':1}],[{'price':1},{'price':5}]),
 ('group_by_key','จัดกลุ่มตามคอลัมน์','จัดกลุ่มตามฟิลด์|group by key',
  'key=PARAM_KEY\nresult={}\nfor row in data:\n    result.setdefault(row[key],[]).append(row)\nreturn result',
  [{'group':'a','v':1},{'group':'b','v':2},{'group':'a','v':3}],
  {'a':[{'group':'a','v':1},{'group':'a','v':3}],'b':[{'group':'b','v':2}]}),
 ('distinct_by_key','ลดซ้ำตามคอลัมน์','ไม่ซ้ำตามฟิลด์|distinct by key',
  'key=PARAM_KEY\nseen=set()\nresult=[]\nfor row in data:\n    if row[key] not in seen:\n        seen.add(row[key])\n        result.append(row)\nreturn result',
  [{'id':1},{'id':1},{'id':2}],[{'id':1},{'id':2}]),
 ('filter_equals','กรองแถวที่ค่าเท่ากัน','กรองตามค่า|filter equals',
  'key=PARAM_KEY\nexpected=PARAM_VALUE\nreturn [row for row in data if row.get(key)==expected]',
  [{'status':'ok'},{'status':'no'}],[{'status':'ok'}]),
 ('extract_key','ดึงค่าคอลัมน์','ดึงคอลัมน์|extract key',
  'key=PARAM_KEY\nreturn [row[key] for row in data]',[{'id':1},{'id':2}],[1,2]),
 ('merge_dict','รวมดิกชันนารีจากลิสต์','รวมพจนานุกรม|merge dict',
  'result={}\nfor item in data:\n    result.update(item)\nreturn result',[{'a':1},{'b':2}],{'a':1,'b':2}),
 ('frequency','ตารางความถี่','นับความถี่|frequency',
  'result={}\nfor x in data:\n    result[x]=result.get(x,0)+1\nreturn result',['ก','ข','ก'],{'ก':2,'ข':1}),
 ('cumulative_sum','ผลรวมสะสม','ผลรวมสะสม|cumulative sum',
  'total=0\nresult=[]\nfor x in data:\n    total+=x\n    result.append(total)\nreturn result',[1,2,3],[1,3,6]),
 ('running_max','ค่าสูงสุดสะสม','ค่าสูงสุดสะสม|running max',
  'result=[]\nbest=None\nfor x in data:\n    best=x if best is None or x>best else best\n    result.append(best)\nreturn result',[2,1,4,3],[2,2,4,4]),
 ('all_truthy','ตรวจทุกค่าจริง','ทุกค่าจริง|all true', 'return all(data)',[True,True],True),
 ('any_truthy','ตรวจว่ามีค่าจริง','มีค่าจริง|any true', 'return any(data)',[False,True],True),
 ('head','หัวรายการ','ข้อมูลตัวแรก|first item', 'return data[0] if data else None',[3,2,1],3),
 ('tail','ท้ายรายการ','ข้อมูลตัวสุดท้าย|last item', 'return data[-1] if data else None',[3,2,1],1),
]

PATTERNS={k:CodePattern(k,d,tuple(aliases.split('|')),body,input_,output)
          for k,d,aliases,body,input_,output in _RAW}

class SafeCodeGenerator:
    def __init__(self,output_root=None,canti=None):
        self.output_root=Path(output_root).absolute() if output_root else None
        self.canti=canti

    def select(self,request):
        txt=normalize(request)
        scores=[]
        for k,p in PATTERNS.items():
            aliases=[normalize(a) for a in p.aliases]
            match=[alias for alias in aliases if alias in txt]
            if match:scores.append((max(map(len,match)),k))
        if not scores:return {'status':'UNSUPPORTED','reason':'no_reviewed_code_pattern_for_request'}
        scores.sort(key=lambda v:(-v[0],v[1]))
        if len(scores)>1 and scores[0][0]==scores[1][0]:
            return {'status':'AMBIGUOUS','candidates':[x[1] for x in scores[:5]]}
        return {'status':'MATCHED','pattern':scores[0][1]}

    def render(self,pattern,key=None,size=2,page=1,value=None,origin_ref=None):
        if pattern not in PATTERNS:
            return {'status':'UNSUPPORTED','reason':'unknown_template','available_count':len(PATTERNS)}
        if origin_ref is not None and (not isinstance(origin_ref,str) or not re.fullmatch(r'[\w./:@#-]{1,160}',origin_ref)):
            raise ValueError('unsafe_or_invalid_origin_ref')
        p=PATTERNS[pattern]
        if pattern in {'sum_by_key','sort_by_key','group_by_key','distinct_by_key','filter_equals','extract_key'}:
            key=key or ('group' if pattern=='group_by_key' else 'status' if pattern=='filter_equals' else
                        'id' if pattern in ('distinct_by_key','extract_key') else 'price')
            if not isinstance(key,str) or len(key)>100 or not re.fullmatch(r'[\w\u0e00-\u0e7f -]+',key):
                raise ValueError('invalid_key')
        if type(size) is not int or not 1<=size<=100000 or type(page) is not int or not 1<=page<=100000:
            raise ValueError('invalid_page_or_size')
        if type(value) not in (str,int,float,bool,type(None)):
            raise ValueError('value_type_not_allowed')
        if pattern=='filter_equals' and value is None:value='ok'
        body=(p.body.replace('PARAM_KEY',repr(key))
                    .replace('PARAM_SIZE',str(size)).replace('PARAM_PAGE',str(page))
                    .replace('PARAM_VALUE',repr(value)))
        header=f'"""OLGM generated candidate. Pattern: {pattern}. Origin ref: {origin_ref or "UNSPECIFIED"}.\nNot verified for production. Do not edit canonical assets.\n"""'
        source=header+'\n\ndef process(data):\n'+textwrap.indent(body,'    ')+'\n'
        tree=ast.parse(source)
        # Reviewed template invariants: no system, network, filesystem, dynamic eval or imports except Unicode library.
        for node in ast.walk(tree):
            if isinstance(node,(ast.ImportFrom,ast.Global,ast.Nonlocal,ast.ClassDef,ast.AsyncFunctionDef)):
                raise ValueError('forbidden_generated_node')
            if isinstance(node,ast.Import) and any(n.name!='unicodedata' for n in node.names):
                raise ValueError('forbidden_generated_import')
            if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id in ('eval','exec','open','compile','__import__'):
                raise ValueError('forbidden_generated_call')
        h=hashlib.sha256(source.encode()).hexdigest()
        return {'status':'CODE_CANDIDATE','pattern':pattern,'description_th':p.description_th,
                'code':source,'source_sha256':h,'origin_ref':origin_ref,
                'source_classification':'LOCAL_GENERATED_CANDIDATE','verified_novel_generation':False}

    # A conservative type system for safe pipeline composition. Other reviewed
    # patterns remain available as single steps but need a typed contract first.
    _SIGNATURES = {
        'identity':('list_num','list_num'), 'sort':('list_num','list_num'),
        'sort_desc':('list_num','list_num'),'reverse':('list_num','list_num'),
        'unique':('list_num','list_num'),'count':('list_num','number'),
        'sum':('list_num','number'),'average':('list_num','number'),
        'minimum':('list_num','number'),'maximum':('list_num','number'),
        'positive':('list_num','list_num'),'negative':('list_num','list_num'),
        'even':('list_num','list_num'),'odd':('list_num','list_num'),
        'cumulative_sum':('list_num','list_num'),'running_max':('list_num','list_num'),
        'flatten':('list_of_list_num','list_num'),
        'strip':('text','text'),'lower':('text','text'),
        'normalize_thai':('text','text'),'char_count':('text','number'),
        'word_count':('text','number'),
    }

    def render_pipeline(self,steps,origin_ref):
        if not isinstance(origin_ref,str) or not re.fullmatch(r'[\w./:@#-]{1,160}',origin_ref):
            raise ValueError('unsafe_or_invalid_origin_ref')
        if not isinstance(steps,(tuple,list)) or not 2<=len(steps)<=6:
            return {'status':'UNSUPPORTED','reason':'pipeline_length_2_to_6_required'}
        if any(not isinstance(k,str) or k not in self._SIGNATURES for k in steps):
            return {'status':'UNSUPPORTED','reason':'typed_pattern_contract_missing'}
        expected_type=self._SIGNATURES[steps[0]][0]
        output_type=expected_type
        for step in steps:
            input_type,next_type=self._SIGNATURES[step]
            if output_type!=input_type:
                return {'status':'UNSUPPORTED','reason':'type_mismatch',
                        'at':step,'expected_input':input_type,'previous_output':output_type}
            output_type=next_type
        functions=[]
        for i,key in enumerate(steps):
            rendered=self.render(key,origin_ref=origin_ref)
            if rendered['status']!='CODE_CANDIDATE':return rendered
            source=rendered['code']
            functions.append(source[source.index('def process(data):'):].replace(
                        'def process(data):',f'def _step_{i}(data):',1))
        main='def process(data):\n'
        for i in range(len(steps)):main+=f'    data = _step_{i}(data)\n'
        main+='    return data\n'
        header=f'"""OLGM local candidate typed pipeline; origin ref {origin_ref}.\nNot production certified. Core 0 and Canonical not modified.\n"""\n\n'
        source=header+'\n'.join(functions)+'\n'+main
        ast.parse(source)
        return {'status':'CODE_CANDIDATE','pattern':'pipeline:'+'>>'.join(steps),
                'description_th':'ประกอบกระบวนการ Python ตามชนิดข้อมูลที่ยืนยันในแม่แบบ',
                'code':source,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),
                'origin_ref':origin_ref,'input_contract':expected_type,'output_contract':output_type,
                'source_classification':'LOCAL_GENERATED_CANDIDATE','verified_novel_generation':False,
                'structural_reuse':True}

    def save(self,rendered,filename):
        if rendered.get('status')!='CODE_CANDIDATE':raise ValueError('not_code_candidate')
        if not self.output_root:raise ValueError('output_root_not_configured')
        if not self.canti or not self.canti.check('sandbox_write','thai.generated')['allowed']:
            raise PermissionError('CANTI_sandbox_write_thai.generated_required')
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,60}\.py',filename):
            raise ValueError('invalid_generated_filename')
        # Existing root and ancestors are checked, to prevent symlink escape.
        self.output_root.mkdir(parents=True,exist_ok=True)
        if self.output_root.is_symlink():raise PermissionError('generated_root_symlink_forbidden')
        dest=self.output_root/filename
        if dest.exists() or dest.is_symlink():raise FileExistsError('no_overwrite_of_generated_source')
        data=rendered['code'].encode()
        if hashlib.sha256(data).hexdigest()!=rendered['source_sha256']:
            raise ValueError('generated_source_hash_mismatch')
        fd,temp=tempfile.mkstemp(dir=self.output_root,prefix='.staged_',suffix='.py')
        try:
            with os.fdopen(fd,'wb') as stream:
                stream.write(data);stream.flush();os.fsync(stream.fileno())
            # Open without overwrite even in a name-race.
            os.link(temp,dest)
        finally:
            if os.path.exists(temp):os.unlink(temp)
        return {'status':'SAVED_CANDIDATE_NOT_EXECUTED','file':str(dest),
                'source_sha256':rendered['source_sha256']}


def capabilities():
    return {'reviewed_code_patterns':len(PATTERNS),
            'keys':sorted(PATTERNS),'language':'Python 3',
            'novel_untemplated_code':'NOT_IMPLEMENTED','source_autonomous_mutation':'DENIED_BY_DEFAULT'}
