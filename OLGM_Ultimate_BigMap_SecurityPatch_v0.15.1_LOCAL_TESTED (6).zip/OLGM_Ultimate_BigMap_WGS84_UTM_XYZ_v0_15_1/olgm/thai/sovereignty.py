"""OLGM Origin/Intellectual-Sovereignty security boundary for Thai extension.

This class is a restrictive application policy, not a certificate of real-world identity.
Core 0 is a conceptual boundary, NOT an addressable resource or editable object.
"""
from dataclasses import dataclass

CLASSES={'PUBLIC','INTERNAL','PRIVATE','CONFIDENTIAL','ORIGIN_ONLY'}
PROTECTED_RESOURCES=('core0','origin_intent','canonical_master','canonical_archive')

@dataclass(frozen=True)
class OriginPolicy:
    declaration_ref: str
    canonical_ref: str
    policy_version: str = 'G08-LOCAL-1'

    def __post_init__(self):
        if not self.declaration_ref or not self.canonical_ref:
            raise ValueError('origin_and_canonical_refs_required')

    def check(self, operation, classification='INTERNAL', destination='local', resource='thai.examples'):
        if classification not in CLASSES:return {'allowed':False,'reason':'invalid_classification'}
        if any(resource==r or resource.startswith(r+'/') for r in PROTECTED_RESOURCES) and operation in ('write','learn','change','delete','execute'):
            return {'allowed':False,'reason':'protected_origin_or_canonical_boundary'}
        if destination!='local':
            return {'allowed':False,'reason':'no_outbound_without_specific_origin_authorization'}
        if operation in ('modify_origin','become_origin','rewrite_canonical'):
            return {'allowed':False,'reason':'origin_not_delegable_by_prompt'}
        return {'allowed':True,'mode':'local_only','source_authority':'not_independently_verified',
                'origin_declaration_ref':self.declaration_ref,'canonical_ref':self.canonical_ref}
