"""Offline Thai Unicode handling and transparent fuzzy matching; no network access."""
import re
import unicodedata
from collections import Counter

def normalize(text):
    if not isinstance(text,str):raise TypeError('text_must_be_string')
    if len(text)>20000:raise ValueError('text_too_long')
    return re.sub(r'\s+',' ',unicodedata.normalize('NFKC',text).casefold()).strip()

def grams(text,n=2):
    value=re.sub(r'[^\u0e00-\u0e7fa-z0-9]+','',normalize(text))
    if not value:return Counter()
    return Counter(value[i:i+n] for i in range(max(1,len(value)-n+1)))

def similarity(a,b):
    if normalize(a)==normalize(b):return 1.0
    x,y=grams(a),grams(b)
    if not x or not y:return 0.0
    return 2*sum((x & y).values())/(sum(x.values())+sum(y.values()))
