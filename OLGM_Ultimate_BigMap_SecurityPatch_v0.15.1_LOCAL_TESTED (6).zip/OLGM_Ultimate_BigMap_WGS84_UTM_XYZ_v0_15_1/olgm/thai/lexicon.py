"""Thai language learning anchored to immutable Meaning Space CIDs.

Learning an alias never changes a core ID, core definition, edge, or category.
Only signed, provenance-bearing links can be used by Thai semantic lookup.
"""
import hashlib
import json
import sqlite3
import uuid
from .text import normalize
from ..intent import now
from ..identity import SignedAuthorizations


def alias_digest(alias,language,cid,origin_ref,source_ref,license_name):
    obj={'alias':normalize(alias),'language':language,'cid':cid,'origin_ref':origin_ref,
         'source_ref':source_ref,'license':license_name}
    return hashlib.sha256(json.dumps(obj,ensure_ascii=False,sort_keys=True).encode()).hexdigest()

class ThaiLexicon:
    def __init__(self,meaning_space,canti=None,audit=None):
        self.ms=meaning_space;self.db_path=str(meaning_space.db_path)
        self.canti=canti;self.audit=audit
        with self._db() as db:
            db.executescript('''CREATE TABLE IF NOT EXISTS thai_alias_candidates (
             alias_id TEXT PRIMARY KEY,alias TEXT NOT NULL,alias_normalized TEXT NOT NULL,
             language TEXT NOT NULL,cid TEXT NOT NULL,origin_ref TEXT NOT NULL,
             source_ref TEXT NOT NULL,license TEXT NOT NULL,content_hash TEXT NOT NULL,
             created_at TEXT NOT NULL);
             CREATE TABLE IF NOT EXISTS thai_alias_approvals (
             alias_id TEXT PRIMARY KEY REFERENCES thai_alias_candidates(alias_id),
             alias_normalized TEXT NOT NULL,language TEXT NOT NULL,
             signer TEXT NOT NULL,receipt_hash TEXT NOT NULL,approved_content_hash TEXT NOT NULL,
             created_at TEXT NOT NULL,
             UNIQUE(alias_normalized,language));
             CREATE TRIGGER IF NOT EXISTS thai_alias_candidates_no_update BEFORE UPDATE ON thai_alias_candidates
             BEGIN SELECT RAISE(ABORT,'append_only_alias'); END;
             CREATE TRIGGER IF NOT EXISTS thai_alias_candidates_no_delete BEFORE DELETE ON thai_alias_candidates
             BEGIN SELECT RAISE(ABORT,'append_only_alias'); END;
             CREATE TRIGGER IF NOT EXISTS thai_alias_approvals_no_update BEFORE UPDATE ON thai_alias_approvals
             BEGIN SELECT RAISE(ABORT,'append_only_alias_approval'); END;
             CREATE TRIGGER IF NOT EXISTS thai_alias_approvals_no_delete BEFORE DELETE ON thai_alias_approvals
             BEGIN SELECT RAISE(ABORT,'append_only_alias_approval'); END;''')
    def _db(self):
        db=sqlite3.connect(self.db_path,timeout=15);db.row_factory=sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        return db
    def propose(self,alias,cid,origin_ref,source_ref,license_name,language='th'):
        if not all(isinstance(x,str) and x.strip() for x in
                   (alias,cid,origin_ref,source_ref,license_name)):
            raise ValueError('alias_cid_origin_source_license_required')
        if len(alias)>200 or language not in ('th','en'):
            raise ValueError('invalid_alias_or_language')
        if not self.ms.get_core(cid):return {'status':'REJECTED','reason':'cid_not_found'}
        if not self.canti or not self.canti.check('sandbox_write','thai.lexicon')['allowed']:
            return {'status':'DENIED','reason':'CANTI_sandbox_write_required'}
        aid=str(uuid.uuid4())
        h=alias_digest(alias,language,cid,origin_ref,source_ref,license_name)
        with self._db() as db:
            db.execute('INSERT INTO thai_alias_candidates VALUES(?,?,?,?,?,?,?,?,?,?)',
                       (aid,alias,normalize(alias),language,cid,origin_ref,source_ref,license_name,h,now()))
        if self.audit:self.audit.append(aid,'THAI_ALIAS_CANDIDATE',{'cid':cid,'content_hash':h,
                   'source_ref':source_ref,'origin_ref':origin_ref})
        return {'status':'CANDIDATE','alias_id':aid,'cid':cid,'content_hash':h,
                'edges_modified':False,'core_modified':False}
    def record(self,aid):
        with self._db() as db:
            row=db.execute('''SELECT c.*,a.created_at approved_at FROM thai_alias_candidates c
               LEFT JOIN thai_alias_approvals a ON c.alias_id=a.alias_id WHERE c.alias_id=?''',(aid,)).fetchone()
        return dict(row) if row else None
    def approval_receipt(self,aid,principal,expires_at):
        row=self.record(aid)
        if not row:raise ValueError('alias_not_found')
        if row['approved_at']:raise ValueError('already_approved')
        return {'principal':principal,'plan_id':aid,'intent_id':'thai-alias:'+aid,
                'intent_hash':row['content_hash'],'resource':'thai.lexicon','scope':'sandbox_write',
                'nonce':str(uuid.uuid4()),'expires_at':expires_at,
                'approval_ref':'origin_reviewed_alias','decision_ref':'thai_alias_promotion_v1'}
    def approve(self,aid,receipt,signature):
        row=self.record(aid)
        if not row:return {'status':'DENIED','reason':'alias_not_found'}
        if row['approved_at']:return {'status':'DENIED','reason':'already_approved'}
        if not self.canti or not self.canti.check('sandbox_train','thai.lexicon')['allowed']:
            return {'status':'DENIED','reason':'CANTI_sandbox_train_required'}
        if (not isinstance(receipt,dict) or receipt.get('plan_id')!=aid or
             receipt.get('intent_id')!='thai-alias:'+aid or
             receipt.get('intent_hash')!=row['content_hash'] or
             receipt.get('decision_ref')!='thai_alias_promotion_v1'):
            return {'status':'DENIED','reason':'receipt_not_bound_to_alias'}
        if row['content_hash']!=alias_digest(row['alias'],row['language'],row['cid'],
                                            row['origin_ref'],row['source_ref'],row['license']):
            return {'status':'DENIED','reason':'tampered_alias'}
        if not self.ms.get_core(row['cid']):return {'status':'DENIED','reason':'cid_no_longer_exists'}
        # Prevent all conflicting approved aliases, not just duplicate CIDs.
        with self._db() as db:
            dup=db.execute('SELECT 1 FROM thai_alias_approvals WHERE alias_normalized=? AND language=?',
                           (row['alias_normalized'],row['language'])).fetchone()
            if dup:return {'status':'DENIED','reason':'alias_conflict'}
        auth=SignedAuthorizations(self.db_path).verify(receipt,signature,
                        expected_plan_id=aid,expected_resource='thai.lexicon',consume=False)
        if auth.get('status')!='VERIFIED_SIGNATURE' or auth.get('authority')!='Origin':
            return {'status':'DENIED','reason':'origin_signature_required'}
        auth=SignedAuthorizations(self.db_path).verify(receipt,signature,
                        expected_plan_id=aid,expected_resource='thai.lexicon',consume=True)
        if auth.get('status')!='CONSUMED_SIGNATURE':return {'status':'DENIED','reason':'signature_rejected'}
        try:
            with self._db() as db:
                db.execute('INSERT INTO thai_alias_approvals VALUES(?,?,?,?,?,?,?)',
                    (aid,row['alias_normalized'],row['language'],receipt['principal'],auth['receipt_hash'],row['content_hash'],now()))
        except sqlite3.IntegrityError:
            return {'status':'DENIED','reason':'alias_conflict'}
        if self.audit:self.audit.append(aid,'THAI_ALIAS_APPROVED',{'cid':row['cid'],
                'receipt_hash':auth['receipt_hash'],'origin_ref':row['origin_ref']})
        return {'status':'APPROVED_LINK','alias_id':aid,'cid':row['cid'],
                'edges_modified':False,'core_modified':False}

    def resolve(self,word,language='th'):
        normalized=normalize(word)
        with self._db() as db:
            row=db.execute('''SELECT c.*,a.approved_content_hash FROM thai_alias_candidates c
                JOIN thai_alias_approvals a ON c.alias_id=a.alias_id
                WHERE c.alias_normalized=? AND c.language=?''',(normalized,language)).fetchone()
        if not row:return {'status':'NOT_FOUND'}
        if row['approved_content_hash']!=row['content_hash']:
            return {'status':'TAMPERED'}
        if row['content_hash']!=alias_digest(row['alias'],row['language'],row['cid'],
                                             row['origin_ref'],row['source_ref'],row['license']):
            return {'status':'TAMPERED'}
        core=self.ms.get_core(row['cid'])
        if not core:return {'status':'INCOMPLETE','reason':'cid_missing'}
        return {'status':'LINKED_TO_EXISTING_CID','word':word,'cid':core['cid'],
                'core_surface':core['surface_form'],'definition':core['definition'],
                'source_ref':row['source_ref'],'origin_ref':row['origin_ref'],
                'evidence_status':'approved_lexical_link_not_independent_factual_proof'}
