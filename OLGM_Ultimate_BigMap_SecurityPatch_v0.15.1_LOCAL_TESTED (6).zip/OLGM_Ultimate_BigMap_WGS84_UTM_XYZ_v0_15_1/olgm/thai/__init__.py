"""Sovereign Thai language layer — bounded offline language support, opt-in retrieval learning."""
from .nlu import ThaiIntentRouter
from .patterns import PATTERNS,stats
from .sovereignty import OriginPolicy
