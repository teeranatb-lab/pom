"""Human-reviewed Thai intent catalog. Pattern match != understanding or verified fact.

Stable keys are independent of Thai labels and taxonomy; category migrations must not
rewrite Meaning Space CIDs, canonical lineage, or historical records.
"""
from dataclasses import dataclass
from .text import normalize

@dataclass(frozen=True)
class ThaiPattern:
    key: str
    group: str
    phrases: tuple[str, ...]
    methods: tuple[int, ...]
    purpose: str

# 72 domain-specific intent patterns: 1+18 methods are *method plans*, not all implemented operators.
_RAW = [
('greet','conversation','สวัสดี|ทักทาย|หวัดดี|hello','1,2,19','ทักทาย'),
('thanks','conversation','ขอบคุณ|ขอบใจ|thank you','1,2,19','ขอบคุณ'),
('help','conversation','ช่วยเหลือ|ทำอะไรได้บ้าง|วิธีใช้งาน|ช่วยหน่อย','1,6,19','ขอความช่วยเหลือ'),
('clarify','conversation','ขยายความ|อธิบายเพิ่ม|หมายความว่าอย่างไร|ชี้แจง','1,6,14,19','ขอคำอธิบายเพิ่ม'),
('summarize','language','สรุป|ย่อความ|สรุปใจความ|สาระสำคัญ','1,6,14,19','สรุปเนื้อหา'),
('translate','language','แปลภาษา|แปลไทย|แปลอังกฤษ|แปลให้','1,12,14,19','แปลภาษา'),
('spellcheck','language','ตรวจคำผิด|แก้คำสะกด|ตรวจสะกด','1,3,10,19','ตรวจภาษา'),
('rewrite','language','ปรับสำนวน|เรียบเรียงใหม่|เขียนใหม่|เปลี่ยนสำนวน','1,12,14,19','เรียบเรียง'),
('thai_learn','language','เรียนรู้ภาษาไทย|ฝึกภาษาไทย|สอนภาษาไทย|เพิ่มคำศัพท์ไทย','1,2,4,19','เรียนรู้ภาษาไทย'),
('definition','language','นิยาม|ความหมายของ|แปลว่าอะไร|คืออะไร','1,2,4,19','หานิยาม'),
('synonyms','language','คำไวพจน์|คำพ้องความหมาย|คำใกล้เคียง','1,3,14,19','คำใกล้เคียง'),
('contradiction','language','ขัดแย้ง|ข้อมูลไม่ตรงกัน|ความขัดกัน','1,3,10,19','ตรวจความขัดแย้ง'),
('cause','reasoning','สาเหตุ|ทำไม|เพราะอะไร|เหตุใด','1,9,16,19','หาเหตุ'),
('effect','reasoning','ผลกระทบ|ส่งผลต่อ|ผลที่ตามมา','1,15,16,19','วิเคราะห์ผล'),
('compare','reasoning','เปรียบเทียบ|ความแตกต่าง|ต่างกันอย่างไร','1,3,10,19','เปรียบเทียบ'),
('classify','reasoning','จำแนก|จัดประเภท|แบ่งประเภท|จัดกลุ่ม','1,4,6,19','จำแนก'),
('verify','reasoning','พิสูจน์|ตรวจสอบความจริง|ตรวจสอบหลักฐาน|เป็นจริงหรือไม่','1,7,10,19','พิสูจน์'),
('infer','reasoning','อนุมาน|คาดการณ์จากข้อมูล|ข้อสรุปจาก','1,7,8,9,19','อนุมาน'),
('plan','reasoning','วางแผน|แผนงาน|จัดลำดับขั้นตอน','1,6,17,19','วางแผน'),
('optimize','reasoning','เพิ่มประสิทธิภาพ|ลดต้นทุน|ปรับให้ดีที่สุด|เพิ่มความเร็ว','1,6,15,19','เพิ่มประสิทธิภาพ'),
('calculate','math','คำนวณ|บวก|ลบ|คูณ|หาร','1,7,19','คำนวณ'),
('statistics','math','ค่าเฉลี่ย|มัธยฐาน|ส่วนเบี่ยงเบนมาตรฐาน','1,6,7,19','สถิติ'),
('forecast','math','พยากรณ์|คาดการณ์|ทำนายแนวโน้ม','1,8,17,19','คาดการณ์'),
('unit_convert','math','แปลงหน่วย|เมตรเป็น|กิโลเมตรเป็น|ตารางเมตรเป็น','1,5,7,19','แปลงหน่วย'),
('code_write','coding','เขียนโค้ด|สร้างโค้ด|เขียนโปรแกรม|สร้างฟังก์ชัน|write code','1,6,14,19','สร้างโปรแกรม'),
('code_fix','coding','แก้บั๊ก|แก้โค้ด|ซ่อมโค้ด|debug','1,6,10,19','แก้โค้ด'),
('code_review','coding','รีวิวโค้ด|ตรวจโค้ด|ตรวจสอบซอร์สโค้ด|code review','1,3,10,19','ตรวจโค้ด'),
('code_test','coding','ทดสอบโค้ด|เขียนเทสต์|เขียนยูนิตเทสต์|pytest','1,7,10,19','ทดสอบโค้ด'),
('code_refactor','coding','รีแฟกเตอร์|จัดระเบียบโค้ด|refactor','1,6,14,19','ปรับโครงสร้างโค้ด'),
('code_security','coding','ช่องโหว่โค้ด|ความปลอดภัยโค้ด|สแกนช่องโหว่','1,10,15,19','ความปลอดภัยโค้ด'),
('api_design','coding','ออกแบบ api|สร้าง api|rest api|endpoint','1,6,15,19','ออกแบบ API'),
('db_schema','coding','ออกแบบฐานข้อมูล|สร้างตาราง|sqlite|database schema','1,4,15,19','ออกแบบฐานข้อมูล'),
('sql_query','coding','เขียน sql|คำสั่ง sql|ค้นด้วย sql','1,6,7,19','สร้าง SQL'),
('automation','coding','ระบบอัตโนมัติ|ออโตเมชัน|automate|ทำซ้ำอัตโนมัติ','1,6,15,19','ระบบอัตโนมัติ'),
('git_change','coding','git commit|แก้ repository|pull request|branch','1,6,10,19','การเปลี่ยนแปลงซอร์ส'),
('olgm_origin','sovereignty','ออริจิน|origin intent|ผู้ริเริ่มแนวคิด|ต้นกำเนิดเจตนา','1,2,10,19','ตรวจ Origin'),
('olgm_core0','sovereignty','คอร์ศูนย์|core 0|มิติศูนย์','1,2,15,19','ขอบเขต Core 0'),
('olgm_sovereign','sovereignty','อธิปไตยทางปัญญา|intellectual sovereignty|สิทธิทางปัญญา','1,10,15,19','กำกับอธิปไตยทางปัญญา'),
('olgm_canonical','sovereignty','คาโนนิคอล|canonical|ฐานแม่บท|เอกสารแม่บท','1,3,10,19','ตรวจแม่บท'),
('olgm_meaning','sovereignty','มิติความหมาย|meaning space|แก่นความหมาย|เส้นความสัมพันธ์','1,2,5,15,19','ตรวจ Meaning Space'),
('olgm_resonance','sovereignty','resonance|ความถี่เจตนา|การสั่นพ้องความหมาย','1,2,15,19','Resonance'),
('olgm_otfa','sovereignty','otfa|สามระนาบ|ตรวจข้อเท็จจริง','1,7,10,19','OTFA'),
('olgm_canti','sovereignty','canti|action dispatcher|ตัวควบคุมการกระทำ','1,15,19','CANTI'),
('olgm_provenance','sovereignty','provenance|ประวัติหลักฐาน|ที่มาข้อมูล|สายสืบย้อน','1,3,10,19','ตรวจที่มา'),
('olgm_intent_lock','sovereignty','ล็อกเจตนา|intent lock|เจตนาล่าสุด','1,2,19','ล็อกเจตนา'),
('olgm_audit','sovereignty','hash chain|audit|ตรวจสอบย้อนหลัง|บัญชีตรวจสอบ','1,7,10,19','Audit'),
('olgm_selflearn','sovereignty','self-learning|เรียนรู้ด้วยตนเอง|พัฒนาตนเอง|structural growth','1,8,15,19','Self-Learning'),
('procurement_need','procurement','เหตุผลความจำเป็น|ความจำเป็นจัดซื้อ|เสนอจัดซื้อ','1,4,15,19','เสนอความจำเป็น'),
('procurement_egp','procurement','e-gp|ระบบ egp|จัดซื้อจัดจ้างออนไลน์','1,4,15,19','เอกสาร e-GP'),
('procurement_inspection','procurement','ตรวจรับพัสดุ|ตรวจรับของ|คณะกรรมการตรวจรับ','1,7,10,19','ตรวจรับ'),
('procurement_inventory','procurement','คลังพัสดุ|เบิกวัสดุ|รับเข้าคลัง|ยอดคงเหลือ','1,4,6,19','คลังพัสดุ'),
('procurement_fuel','procurement','น้ำมันเชื้อเพลิง|บัญชี s22|fleet card|น้ำมันหล่อลื่น','1,4,7,19','เชื้อเพลิง'),
('procurement_assets','procurement','ทะเบียนครุภัณฑ์|ค่าเสื่อมราคา|ทรัพย์สินราชการ','1,4,7,19','ครุภัณฑ์'),
('procurement_contracts','procurement','ทะเบียนสัญญา|สัญญาจ้าง|ควบคุมสัญญา','1,4,15,19','ทะเบียนสัญญา'),
('procurement_approval','procurement','อนุมัติพัสดุ|หัวหน้าพัสดุ|ผู้มีอำนาจอนุมัติ','1,10,19','ตรวจสิทธิ์อนุมัติ'),
('gis_coordinates','gis','พิกัด|ละติจูด|ลองจิจูด|longitude|latitude','1,5,7,19','พิกัด'),
('gis_crs','gis','utm|indian 1975|wgs84|ระบบพิกัด','1,5,7,19','แปลง CRS'),
('gis_polyline','gis','polyline|เส้นแนวเขต|วาดแนวคลอง|วาดเส้นแนว','1,5,6,19','เส้น GIS'),
('gis_distance','gis','ระยะทาง|คำนวณระยะ|หาความยาวเส้น','1,5,7,19','คำนวณระยะ'),
('gis_export','gis','dxf|dwg|ส่งออกแผนที่|export csv','1,5,6,19','ส่งออกแผนที่'),
('documents_draft','documents','ร่างหนังสือ|เอกสารราชการ|ทำหนังสือ|ร่างจดหมาย','1,6,14,19','ร่างเอกสาร'),
('documents_pdf','documents','สร้าง pdf|ทำ pdf|ไฟล์ pdf','1,6,14,19','สร้าง PDF'),
('documents_sheet','documents','excel|สเปรดชีต|ตารางข้อมูล|ไฟล์ csv','1,4,6,19','ตารางข้อมูล'),
('web_research','research','ค้นเว็บ|ค้นอินเทอร์เน็ต|ค้นแหล่งอ้างอิง|วิจัยข้อมูล','1,2,10,19','ค้นคว้า'),
('law_verify','research','กฎหมาย|ระเบียบกระทรวง|ประกาศราชกิจจา|ข้อบังคับ','1,7,10,19','ตรวจข้อกฎหมาย'),
('privacy','security','ข้อมูลส่วนบุคคล|pdpa|ข้อมูลลับ|ความเป็นส่วนตัว','1,10,15,19','ปกป้องข้อมูล'),
('risk','security','ประเมินความเสี่ยง|วิเคราะห์ความเสี่ยง|risk assessment','1,10,17,19','ประเมินความเสี่ยง'),
('access','security','สิทธิ์การเข้าถึง|กำหนดสิทธิ์|role based|rbac','1,4,10,19','ตรวจสิทธิ์'),
('release','security','production|โปรดักชั่น|ตรวจรับระบบ|s-10','1,7,10,19','ตรวจรับ'),
('monitoring','operations','ตรวจสถานะ|ติดตามสถานะ|เฝ้าระวัง|สถานะระบบ','1,2,15,19','ติดตามสถานะ'),
('backup','operations','สำรองข้อมูล|backup|กู้คืนข้อมูล|restore','1,6,10,19','สำรองข้อมูล'),
('performance','operations','ความเร็วระบบ|latency|ประสิทธิภาพระบบ|benchmark','1,6,15,19','วัดประสิทธิภาพ'),
]
PATTERNS={k:ThaiPattern(k,g,tuple(p.split('|')),tuple(int(x) for x in nums.split(',')),purpose)
          for k,g,p,nums,purpose in _RAW}

def catalog():
    return [{'key': p.key, 'group': p.group, 'phrases': list(p.phrases),
             'method_plan':list(p.methods),'purpose':p.purpose}
            for p in PATTERNS.values()]

def stats():
    groups={}
    for p in PATTERNS.values():groups[p.group]=groups.get(p.group,0)+1
    return {'intent_patterns':len(PATTERNS), 'thai_and_english_triggers':sum(len(p.phrases) for p in PATTERNS.values()),
            'groups':groups,'scope':'rule_pattern_recognition_not_language_model'}
