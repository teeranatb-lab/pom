"""Thai NLU routing with negative-intent guards, transparent evidence, no false fact status."""
from .text import normalize
from .patterns import PATTERNS
import re

class ThaiIntentRouter:
    def __init__(self,patterns=None):self.patterns=patterns or PATTERNS

    @staticmethod
    def _matches(text,needle):
        # Avoid matching English substrings embedded in larger words.
        if not re.search(r'[\u0e00-\u0e7f]',needle):
            hits=[m.start() for m in re.finditer(r'(?<![a-z0-9_])'+re.escape(needle)+r'(?![a-z0-9_])',text)]
        else:
            hits=[m.start() for m in re.finditer(re.escape(needle),text)]
        result=[]
        for at in hits:
            left=text[max(0,at-11):at]
            # Negations immediately before the action are constraints, not an intent to perform it.
            if re.search(r'(?:ไม่ต้อง|ห้าม|อย่า|ไม่ให้)\s*$',left):continue
            result.append(at)
        return result

    def detect(self,text):
        value=normalize(text)
        hits=[]
        for key,p in self.patterns.items():
            found=[]
            for raw in p.phrases:
                phrase=normalize(raw)
                if self._matches(value,phrase):found.append(phrase)
            if found:
                score=max(len(x) for x in found)+min(3,len(found)-1)
                hits.append({'key':key,'group':p.group,'purpose':p.purpose,
                             'matched_phrases':sorted(found,key=lambda s:(-len(s),s)),
                             'method_plan':list(p.methods),'score':score})
        hits.sort(key=lambda x:(-x['score'],x['key']))
        return {'status':'MATCHED_PATTERN' if hits else 'UNKNOWN','language':'th' if re.search('[\u0e00-\u0e7f]',value) else 'und',
                'intent':hits[0]['key'] if hits else None,
                'candidates':hits[:6], 'ambiguous':len(hits)>1 and hits[0]['score']==hits[1]['score'],
                'verified_understanding':False,'text_length':len(value)}
