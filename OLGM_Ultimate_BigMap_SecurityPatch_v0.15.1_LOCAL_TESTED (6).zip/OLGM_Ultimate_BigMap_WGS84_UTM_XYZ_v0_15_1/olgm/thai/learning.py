"""Opt-in, provenance-preserving Thai Q/A memory.

Candidate data never trains model weights and is never served as trusted answers.
Approval requires a locally enrolled Origin-authority Ed25519 signature, CANTI
sandbox_train/thai.examples permission and a one-use intent-bound receipt.
The signer enrollment is NOT itself proof of legal ownership of the Origin identity.
"""
import hashlib
import json
import sqlite3
import uuid
from .text import normalize,similarity
from .sovereignty import CLASSES,OriginPolicy
from ..identity import SignedAuthorizations
from ..intent import now


def hash_example(question,answer,origin_ref,source_ref,license_name,classification):
    payload={'q':normalize(question),'a':normalize(answer),'origin':origin_ref,'source':source_ref,
             'license':license_name,'classification':classification}
    return hashlib.sha256(json.dumps(payload,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

class ThaiExampleMemory:
    def __init__(self,db_path,audit=None,canti=None,policy=None):
        self.db_path=str(db_path);self.audit=audit;self.canti=canti
        self.policy=policy or OriginPolicy('external_origin_declaration_required','external_canonical_reference_required')
        with self._db() as db:
            db.executescript('''CREATE TABLE IF NOT EXISTS thai_examples (
              example_id TEXT PRIMARY KEY, question TEXT NOT NULL, answer TEXT NOT NULL,
              question_normalized TEXT NOT NULL, origin_ref TEXT NOT NULL, source_ref TEXT NOT NULL,
              license TEXT NOT NULL, classification TEXT NOT NULL, content_hash TEXT NOT NULL,
              submitted_by TEXT NOT NULL, created_at TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS thai_example_approvals (
              example_id TEXT PRIMARY KEY REFERENCES thai_examples(example_id),
              signer TEXT NOT NULL, receipt_hash TEXT NOT NULL, approved_content_hash TEXT NOT NULL,
              approved_at TEXT NOT NULL);
              CREATE INDEX IF NOT EXISTS thai_example_question_idx ON thai_examples(question_normalized);
              CREATE TRIGGER IF NOT EXISTS thai_examples_no_update BEFORE UPDATE ON thai_examples
              BEGIN SELECT RAISE(ABORT,'append_only_example'); END;
              CREATE TRIGGER IF NOT EXISTS thai_examples_no_delete BEFORE DELETE ON thai_examples
              BEGIN SELECT RAISE(ABORT,'append_only_example'); END;
              CREATE TRIGGER IF NOT EXISTS thai_example_approvals_no_update BEFORE UPDATE ON thai_example_approvals
              BEGIN SELECT RAISE(ABORT,'append_only_approval'); END;
              CREATE TRIGGER IF NOT EXISTS thai_example_approvals_no_delete BEFORE DELETE ON thai_example_approvals
              BEGIN SELECT RAISE(ABORT,'append_only_approval'); END;''')
    def _db(self):
        db=sqlite3.connect(self.db_path,timeout=15)
        db.row_factory=sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        return db

    def propose(self,question,answer,origin_ref,source_ref,license_name,submitted_by,classification='INTERNAL'):
        if any(not isinstance(v,str) or not v.strip() for v in
               (question,answer,origin_ref,source_ref,license_name,submitted_by)):
            raise ValueError('q_a_origin_source_license_author_required')
        if len(question)>2000 or len(answer)>10000:raise ValueError('example_too_long')
        if classification not in CLASSES:raise ValueError('invalid_classification')
        if not self.policy.check('learn',classification)['allowed']:
            raise PermissionError('origin_policy_denied')
        eid=str(uuid.uuid4())
        h=hash_example(question,answer,origin_ref,source_ref,license_name,classification)
        with self._db() as db:
            db.execute('''INSERT INTO thai_examples VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
                       (eid,question,answer,normalize(question),origin_ref,source_ref,license_name,
                        classification,h,submitted_by,now()))
        if self.audit:self.audit.append(eid,'THAI_LEARN_CANDIDATE',{'example_hash':h,'origin_ref':origin_ref,
                'source_ref':source_ref,'classification':classification})
        return {'status':'CANDIDATE','example_id':eid,'content_hash':h,
                'served_as_answer':False,'note':'not model weight training; owner approval required'}

    def record(self,eid):
        with self._db() as db:
            row=db.execute('''SELECT e.*, a.signer,a.receipt_hash,a.approved_content_hash,a.approved_at FROM thai_examples e
            LEFT JOIN thai_example_approvals a ON e.example_id=a.example_id WHERE e.example_id=?''',(eid,)).fetchone()
        return dict(row) if row else None

    def approval_receipt(self,eid,principal,expiry,nonce=None):
        row=self.record(eid)
        if not row:raise ValueError('example_not_found')
        if row['approved_at']:raise ValueError('already_approved')
        return {'principal':principal,'plan_id':eid,'intent_id':'thai-learning:'+eid,
                'intent_hash':row['content_hash'],'resource':'thai.examples','scope':'sandbox_write',
                'nonce':nonce or str(uuid.uuid4()),'expires_at':expiry,'approval_ref':'origin_reviewed_thai_example',
                'decision_ref':'thai_example_promotion_v1'}

    def approve(self,eid,receipt,signature_hex):
        row=self.record(eid)
        if not row:return {'status':'DENIED','reason':'example_not_found'}
        if row['approved_at']:return {'status':'DENIED','reason':'already_approved'}
        if not self.canti or not self.canti.check('sandbox_train','thai.examples')['allowed']:
            return {'status':'DENIED','reason':'CANTI_sandbox_train_required'}
        if (not isinstance(receipt,dict) or receipt.get('plan_id')!=eid or
             receipt.get('intent_id')!='thai-learning:'+eid or
             receipt.get('intent_hash')!=row['content_hash'] or
             receipt.get('decision_ref')!='thai_example_promotion_v1'):
            return {'status':'DENIED','reason':'approval_not_bound_to_example'}
        with self._db() as db:
            if db.execute('SELECT 1 FROM thai_example_approvals WHERE example_id=?',(eid,)).fetchone():
                return {'status':'DENIED','reason':'already_approved'}
        auth=SignedAuthorizations(self.db_path).verify(receipt,signature_hex,
                     expected_plan_id=eid,expected_resource='thai.examples',consume=False)
        if auth['status']!='VERIFIED_SIGNATURE' or auth.get('authority')!='Origin':
            return {'status':'DENIED','reason':'valid_origin_authority_signature_required',
                    'authorization':auth.get('reason','not_Origin')}
        # Verify hash from currently stored immutable columns before consuming nonce.
        if row['content_hash']!=hash_example(row['question'],row['answer'],row['origin_ref'],row['source_ref'],
                                              row['license'],row['classification']):
            return {'status':'DENIED','reason':'example_tampered'}
        consumed=SignedAuthorizations(self.db_path).verify(receipt,signature_hex,
                     expected_plan_id=eid,expected_resource='thai.examples',consume=True)
        if consumed['status']!='CONSUMED_SIGNATURE':
            return {'status':'DENIED','reason':consumed.get('reason','invalid_signature')}
        with self._db() as db:
            db.execute('INSERT INTO thai_example_approvals VALUES(?,?,?,?,?)',
                       (eid,receipt['principal'],consumed['receipt_hash'],row['content_hash'],now()))
        if self.audit:self.audit.append(eid,'THAI_LEARN_APPROVED',{'example_hash':row['content_hash'],
              'receipt_hash':consumed['receipt_hash'],'signer':receipt['principal']})
        return {'status':'APPROVED_LOCAL_ORIGIN_KEY','example_id':eid,
                'identity_note':'key enrollment is local trust, not independent identity certification'}

    def approved_match(self,question,min_similarity=.88):
        needle=normalize(question)
        with self._db() as db:
            rows=db.execute('''SELECT e.*,a.approved_at,a.signer,a.approved_content_hash FROM thai_examples e
              JOIN thai_example_approvals a ON e.example_id=a.example_id ORDER BY a.approved_at DESC''').fetchall()
        candidates=[]
        for row in rows:
            d=dict(row)
            # Required to detect direct DB tampering before returning learned text.
            if d['approved_content_hash']!=d['content_hash']:
                continue
            if d['content_hash']!=hash_example(d['question'],d['answer'],d['origin_ref'],d['source_ref'],
                                                d['license'],d['classification']):
                continue
            score=similarity(needle,d['question_normalized'])
            if score>=min_similarity:candidates.append((score,d))
        if not candidates:return None
        candidates.sort(key=lambda v:(-v[0],v[1]['example_id']))
        score,row=candidates[0]
        return {'status':'APPROVED_EXAMPLE_NOT_FACT','text':row['answer'],'match_score':round(score,4),
                'origin_ref':row['origin_ref'],'source_ref':row['source_ref'],
                'license':row['license'],'classification':row['classification'],
                'example_id':row['example_id'],'verified_fact':False}

    def status(self):
        with self._db() as db:
            total=db.execute('SELECT COUNT(*) FROM thai_examples').fetchone()[0]
            ok=db.execute('SELECT COUNT(*) FROM thai_example_approvals').fetchone()[0]
        return {'candidates':total-ok,'approved':ok,'total_examples':total,
                'mechanism':'retrieval_learning_not_weight_training','external_transfer':'DENIED_BY_DEFAULT'}
