# ผลแก้ 5 จุดตรวจพบจาก v0.12.1 (ระดับ Code)

| ID | ช่องว่างเดิม | การแก้ไข | หลักฐานที่มี | สถานะ |
|---|---|---|---|---|
| SEC-01 | `DENIED` / `NOT_IMPLEMENTED` / `INSUFFICIENT` ไม่เข้า Audit | Agent ทำ `AGENT_REQUEST` และ `AGENT_OUTCOME` ก่อนส่งคำตอบทุกเส้นทางหลัก และไม่ส่งคำตอบเมื่อ Audit ล้มเหลว | `test_denied_notimplemented_insufficient_all_audited` | CODE TESTED |
| SEC-02 | `str(exc)` อาจเปิดเผยข้อมูลภายใน | Observer ไม่คืน Exception Text; Agent ใช้ Reason Code; Console ใช้ Generic Error Codes | `test_exception_does_not_leak_internal_message` | CODE TESTED |
| SEC-03 | `obs['relation']` เกิด KeyError เมื่อไม่มี relation | ตรวจชนิดและโครงสร้างก่อนใช้ พร้อมสถานะ `INSUFFICIENT` | `test_observer_missing_relation_and_empty_candidate_fail_closed` | CODE TESTED |
| SEC-04 | `CANDIDATE` + คำตอบ `None` | ห้ามส่ง status `CANDIDATE` เมื่อคำตอบไม่ใช่ String ที่มีเนื้อหา | `test_observer_missing_relation_and_empty_candidate_fail_closed` | CODE TESTED |
| SEC-05 | `relation_id=None` ทำให้ย้อนสายสัมพันธ์ไม่ได้ | บันทึก candidate relation ใน `observation_candidate_relations`, มี `relation_ref`, `trace_id`, checksum และ OTFA ตรวจ integrity และสถานะ `NOT_TESTED` (ไม่สวมเป็น `verified` edge) | `test_candidate_relation_id_is_persisted_not_verified`, `test_candidate_relation_tamper_detected` | CODE TESTED |

## ขอบเขตการรับรอง

- ผลระดับ Code/Test เท่านั้น; ไม่มีการรับรองการปฏิบัติงานจริงบน X-admin หรือการป้องกันการแก้ฐานข้อมูลโดยผู้มีสิทธิ์ OS สูงสุด
- Audit/Geometry hash แบบ Local ไม่แทน Immutable External Anchor หรือการลงนามรับรองจาก Origin
- S-10 Production ยังคง `NOT PASSED`
