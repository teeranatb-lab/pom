# OLGM UI v0.12.1 — ความครอบคลุมและขอบเขตการเชื่อมต่อ

| ส่วน | ผ่าน API Local | UI | Live External Verified | ข้อจำกัด |
|---|---:|---:|---:|---|
| Overview & SQLite diagnostics | ✓ | ✓ | ไม่เกี่ยวข้อง | ตัวเลขดึงจาก DB ในเครื่องนี้ |
| Thai responder | ✓ | ✓ | ไม่จำเป็น | Pattern/rule-based ไม่ใช่ general Thai LLM |
| Code synthesis | ✓ | ✓ | ไม่จำเป็น | สร้าง Candidate จาก Pattern ไม่เขียน Production |
| Intent Lock | ✓ | ✓ | ไม่จำเป็น | บันทึก append-only ไม่สร้างสิทธิ์ Origin |
| Meaning Space graph | ✓ | ✓ | ไม่จำเป็น | SVG visualization, ยังไม่ใช่ interactive 3D engine |
| Audit / Provenance | ✓ | ✓ | ไม่จำเป็น | Local hash-chain ไม่ใช่ external immutable anchor |
| CANTI / Queue / Control | ✓ (read/propose) | ✓ | ✕ | ไม่มี Execute โดยไม่มี signed approval |
| Computer access / screenshot | Registry only | ✓ | ✕ | X-admin Offline |
| Plugin access | Registry only | ✓ | ✕ | ChatGPT connector ไม่ได้ส่ง credential ให้ Python Runtime |
| Space access | Registry only | ✓ | ✕ | ไม่มี Space ที่ connector รายงานขณะตรวจ |
| Skills | Catalog | ✓ | n/a | Execution ต้องผ่าน CANTI ของแต่ละ Skill |
| BigMap GIS | ✓, pyproj | ✓ | ไม่เกี่ยวข้อง | Indian1975 UTM, field survey NOT TESTED |
| Self Improvement G-06 | Underlying CLI | Status | ✕ | Runtime source patches require signed approval |
| Model Gateway / AI Observer | Configured only | Status | ✕ | Model disabled by default |
| OTFA / Evidence | Read | ✓ | ✕ | External verification not performed |
| S-10 release | Read / evaluate via CLI | Status | ✕ | NOT PASSED |
| ValueGuard 1,000,000 THB | Read/status | ✓ | ✕ | SMTP delivery and lawful notice NOT TESTED |
| Backup / Restore | Local CLI mechanism | Status | ✕ | No production disaster recovery certification |
| Admin settings | ✓ | ✓ | n/a | Admin Console token ≠ Origin identity |

## Production blocker

UI ใช้งานบน Local เท่านั้นในแพ็กเกจนี้. X-admin ยัง Offline จึงไม่สามารถติดตั้งและเปิดโปรเซสจริง, ระบุ PID ของระบบอื่น, ทดสอบคีย์บอร์ด/เมาส์ หรือทดสอบ LAN proxy/TLS ที่เครื่องเป้าหมายได้. ไม่ปิดระบบอื่นโดยเดาจากชื่อโปรเซสหรือ service manager.
