# BigMap WGS84 Lat/Long + UTM XYZ คู่ขนาน / OLGM Ultimate v0.15.0

## ข้อกำหนดพิกัดที่ใช้ในโปรแกรม

1. **แหล่งข้อมูลหลัก:** Lat/Long (WGS84, EPSG:4326, หน่วยองศาทศนิยม); GeoJSON ใช้ลำดับ `[longitude, latitude]` ตาม RFC 7946; CSV/UI ใช้ `lat,lon`.
2. **พิกัดฉากอนุพันธ์:** UTM (WGS84) โดย Zone อัตโนมัติจาก Lat/Long (มีข้อยกเว้น Norway/Svalbard) และกำหนด EPSG ตาม Zone/ซีกโลก: ซีกเหนือ `32600 + Zone`, ซีกใต้ `32700 + Zone`. พิกัด X=Easting, Y=Northing, หน่วยเมตร.
3. **อุบลราชธานี / แม่น้ำชี:** อยู่ใน UTM Zone 48N ⇒ `EPSG:32648` (102–108°E). สำหรับพื้นที่ 96–102°E ใช้ Zone 47N ⇒ `EPSG:32647`. ระบบ **ไม่แปลงกลับไปเป็น EPSG:24048** เว้นแต่เรียกคำสั่ง Legacy ที่ชัดเจน.
4. **Z:** เป็นค่าความสูงที่ผู้ใช้ให้มาเท่านั้น; หากไม่ส่งค่า ใช้ `null`/CSV เว้นว่าง ไม่สมมติ 0. หากส่ง Z ต้องระบุแหล่งอ้างอิงแนวดิ่งโดยเลือก WGS84 ellipsoidal height (`EPSG:4979` แสดง **CRS ภูมิศาสตร์ 3D**, ไม่ใช่ Vertical CRS ล้วน) หรือ `EPSG:5773` (EGM96 Height), `EPSG:3855` (EGM2008 Height). ไม่มีการแก้ความสูงระหว่าง ellipsoid กับ geoid แบบอัตโนมัติ.
5. **เส้น/พื้นที่ข้าม Zone:** แสดง X/Y ตาม Zone ของแต่ละ vertex, สถานะ `MULTI_ZONE_PER_VERTEX` และ `coordinates_are_metric=false`; ห้ามใช้เป็น geometry ฉากเดียวโดยไม่แยกหรือออกแบบการฉายใหม่.
6. **พื้นที่ความหมาย:** `meaning_cores.semantic_coordinates` เป็น XYZ เชิงนามธรรม *ไม่ใช่* UTM. เชื่อม Feature ↔ CID ผ่าน link ที่สถานะ CANDIDATE พร้อม evidence_ref, Origin reference และ Audit; **ไม่มีการย้าย CID หรือเขียนทับ semantic_edges**.
7. **Provenance:** geometry ดั้งเดิม, revision, geometry_hash, record_hash, vertical_crs มีลำดับตรวจสอบได้; projection สร้างเป็น derived view จาก revision นั้นพร้อม `derived_from_geometry_hash`.
8. **ความเที่ยงตรง:** การคำนวณใช้ pyproj/PROJ, แต่ **ไม่รับรองความถูกต้องของ GPS, Datum transformation, แนวดิ่ง, จุดควบคุม หรือการรังวัด**. UTM WGS84 ≠ Indian 1975 UTM.

## ติดตั้ง Local บน Windows

1. แตก ZIP ในโฟลเดอร์ใหม่ ห้ามแตกทับ Canonical/Archive หรือฐานข้อมูลเก่าที่กำลังรัน
2. ปิด OLGM Console รุ่นเก่าอย่างปลอดภัย แล้วเปิด `deploy\windows\setup_local.cmd` (สร้าง Virtualenv และทำ SQLite Backup ผ่าน `sqlite3.backup` **ก่อน** schema migration)
3. เปิด `deploy\windows\start_local.cmd` แล้วเข้าหน้า `http://127.0.0.1:8787/`; รับ Token จากหน้าต่าง Terminal
4. เมนู BigMap เลือก Feature, กรอก `lat,lon[,Z]`, เลือก Vertical CRS เมื่อมี Z, บันทึก และดูตาราง UTM/Revision พร้อม Export CSV คู่
5. ไม่เปิด LAN หรือควบคุมเครื่องอื่นจาก Installer นี้; ไม่มีสิทธิ์ Origin โดยอัตโนมัติ

## ติดตั้ง Python / Linux

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-local.txt
.venv/bin/python tools/backup_before_upgrade.py --db local_data/olgm.db --out local_data/backups
OLGM_DB="$PWD/local_data/olgm.db" .venv/bin/python runtime.py init
OLGM_DB="$PWD/local_data/olgm.db" .venv/bin/python console.py --port 8787
```

## ตัวอย่าง CLI (PowerShell/Terminal ในโฟลเดอร์ Project)

```bash
python runtime.py bigmap-utm-point 16.199682 103.197839
python runtime.py bigmap-utm-point 16.199682 103.197839 --z 88.5 --vertical-crs EPSG:4979
python runtime.py bigmap-add-point "ทุ่นลอย 1" 16.199682 103.197839 --origin-ref source:buoy --actor local_user
python runtime.py bigmap-features
python runtime.py bigmap-export bigmap_wgs84_utm.csv --format dual-csv
python runtime.py bigmap-import-utm bigmap_wgs84_utm.csv --origin-ref source:import --actor local_user
python runtime.py bigmap-verify
python runtime.py gis-csv data/buoys_wgs84_latlon.csv converted_dual.csv
```

ตัวอย่าง CSV (พิกัด WGS84 โดยไม่มีค่าความสูงจริง):

```csv
label,lat,lon
ทุ่นลอย 1,16.199682,103.197839
ทุ่นลอย 2,16.199754,103.197670
ทุ่นลอย 3,16.201307,103.199069
ทุ่นลอย 4,16.201349,103.199474
```

**หมายเหตุ:** คำสั่ง `gis-indian-legacy-point`, `gis-indian-legacy-csv` เก็บไว้สำหรับงานเดิมที่ต้องใช้ EPSG:24048 โดยระบุชัดว่าเป็นระบบ Indian 1975 ไม่ใช่ WGS84.

## รายการทดสอบ / สถานะ

- ทดสอบ UTM 47N/48N และซีกใต้, Round trip, Norway/Svalbard Zone exceptions
- ทดสอบ Lat/Lon + XYZ, Z ว่าง, Vertical CRS และไม่สร้างค่า Z ปลอม
- ทดสอบ Import/Export CSV และ GeoJSON, แก้ Revision, Hash Chain, ไม่เปลี่ยน CID
- ทดสอบ Agent status DENIED/NOT_IMPLEMENTED/INSUFFICIENT มี Audit; Candidate Relation Persisted แต่ไม่ใช่ Verified Edge
- ทดสอบ Console UI จาก Local API, Source Hash และ Production default deny
- ยังไม่ทดสอบ X-admin, จุดควบคุมจริง, ความแม่นยำรังวัด, Production S-10, โมเดลสด, การฝึกน้ำหนัก

## มาตรฐานอ้างอิง

- EPSG:32648 — WGS 84 / UTM zone 48N: https://epsg.io/32648
- EPSG:4979 — WGS 84 Geographic 3D: https://epsg.io/4979
- EPSG:5773 — EGM96 height: https://epsg.io/5773
- EPSG:3855 — EGM2008 height: https://epsg.io/3855
- PROJ / pyproj: https://pyproj4.github.io/pyproj/stable/api/transformer.html

**สถานะ:** CODE-LEVEL TESTED; SURVEY NOT CERTIFIED; S-10 PRODUCTION NOT PASSED.
