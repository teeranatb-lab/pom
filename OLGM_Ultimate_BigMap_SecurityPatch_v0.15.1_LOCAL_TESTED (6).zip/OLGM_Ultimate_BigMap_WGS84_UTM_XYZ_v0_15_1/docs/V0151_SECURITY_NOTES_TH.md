# OLGM Ultimate v0.15.1 — Security Regression Patch

## สถานะ
แก้ไขและทดสอบระดับโค้ดในเครื่องพัฒนา ไม่ใช่การตรวจรับ Production; S-10 ยัง NOT PASSED.

| ปัญหา | แนวทางแก้ | หลักฐาน |
|---|---|---|
| DENIED / NOT_IMPLEMENTED / INSUFFICIENT ไม่เข้า Audit | Agent `_end` และ Transport `HTTP_API_OUTCOME`, `HTTP_UI_OUTCOME` ใน Audit Chain | `tests/test_utm_xyz_v015.py` และ `tests/test_security_http_v0151.py` |
| ข้อความ `str(exc)` อาจรั่ว | ใช้รหัสความผิดพลาดคงที่ใน HTTP API, Console และผลที่อาจถูกแสดงใน Runtime | ทดสอบ malformed JSON / API token / ช่องทาง UI |
| Missing `relation` เกิด KeyError | ตรวจชนิด `obs` และ `relation` ก่อนใช้งาน, ปฏิเสธแบบ fail closed | Test Observer missing relation |
| `CANDIDATE` แต่ไม่มี `answer_candidate` | คืน `INSUFFICIENT / EMPTY_ANSWER_CANDIDATE` และ Audit | Test empty candidate |
| `relation_id=None` ไม่อ้างกลับ | บันทึก Candidate Relation พร้อม Hash/ID ใน SQLite; OTFA ยังคง `NOT_TESTED` | Test candidate relation persistence/tamper |

## ขอบเขตเพิ่มเติม
- การปฏิเสธตั้งแต่ชั้น HTTP ก่อน Agent เช่น 401 Invalid Token และ 403 CSRF จะเข้า Audit ด้วย metadata ที่ไม่รวม body, token หรือ query
- หากบันทึกเหตุการณ์ปฏิเสธลง Audit ไม่สำเร็จ HTTP ต้องตอบ `503 AUDIT_UNAVAILABLE`
- ทำการทดสอบ G-06 แยกชุดเพื่อป้องกัน recursive test-run
- เอกสาร Canonical / Archive ไม่ถูกแก้ไข

## วิธีตรวจซ้ำ
```
python -m pip install -r requirements-dev.txt
python -m pip install -r requirements-local.txt
OLGM_G06_SANDBOX_TEST=1 python -m pytest -q
python -m pytest -q tests/test_g06_source_improve.py
```
สำหรับ Windows ใช้ `$env:OLGM_G06_SANDBOX_TEST="1"` ใน PowerShell แทนคำสั่งกำหนดตัวแปรของ Unix
