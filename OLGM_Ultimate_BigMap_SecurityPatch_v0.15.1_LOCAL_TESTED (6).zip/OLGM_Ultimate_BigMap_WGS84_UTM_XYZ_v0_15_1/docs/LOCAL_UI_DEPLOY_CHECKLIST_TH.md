# ตรวจรับก่อนเรียกระบบ OLGM บน X-admin ว่าใช้งานได้จริง

1. ยืนยัน X-admin online ด้วยช่องทาง Remote Desktop Commander ที่ผู้ใช้อนุญาต
2. ตรวจโฟลเดอร์/DB/พอร์ต/โปรเซสที่ทำงาน และสำรองระบบเก่าก่อนเปลี่ยน
3. ตรวจสอบรายการเซิร์ฟเวอร์ OLGM/ATI เดิม **ราย PID**; หยุดเฉพาะที่ผู้ดูแลรับรอง ไม่กระทบ OS/network/backup
4. แตกแพ็กเกจใหม่ในโฟลเดอร์แยก ไม่แตะ Canonical/Archive
5. ติดตั้ง Python dependencies, รัน `runtime.py init`, เปิด `console.py`
6. ทดสอบ UI Login, Dashboard, Thai answer, Code Studio, Meaning Space, Intent, Settings, Audit, ValueGuard และ GIS จากเครื่อง X-admin
7. ตรวจ Local S-10 gate; เก็บ logs/sha256 ของโค้ด, pass/fail/skip ตามจริง
8. หากจะให้มือถือใน LAN เข้า ต้องติดตั้ง TLS/Identity Proxy ตรวจ firewall/PDPA/สิทธิ์ต่างหากก่อน ไม่เปิด `0.0.0.0` อัตโนมัติ
9. หากต้องการเชื่อม ChatGPT Spaces/Plugin ต้องออกแบบ Authorized Bridge แยก เพราะ Connector ใน ChatGPT ไม่ใช่ credential ที่ Local Runtime ถือครอง
10. ให้ Origin และผู้ตรวจสอบอิสระพิจารณาก่อนรายงาน S-10 production PASS
