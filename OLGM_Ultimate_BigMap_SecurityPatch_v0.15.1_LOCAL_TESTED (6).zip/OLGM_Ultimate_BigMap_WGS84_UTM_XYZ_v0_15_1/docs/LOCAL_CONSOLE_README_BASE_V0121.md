# OLGM Ultimate — Sovereign Local Console v0.12.1

**สถานะ:** LOCAL CONSOLE CODE TESTED / X-admin NOT CONNECTED / S-10 PRODUCTION NOT PASSED

เว็บ Console ภาษาไทยสำหรับ OLGM Ultimate เชื่อมกับ Runtime ในแพ็กเกจเดียวกันผ่าน SQLite บนเครื่องที่รัน โดยไม่มีการสร้างสิทธิ์ Origin จากการเข้าสู่หน้าเว็บ และไม่มีการรันโมเดลหรือเรียก Connector ภายนอกโดยอัตโนมัติ

## เปิดใช้งานบน Windows (X-Comp / X-admin)

1. แตก ZIP ไว้ในโฟลเดอร์ใหม่ (อย่าแตกทับ Canonical, Archive หรือฐานข้อมูลเดิม)
2. ติดตั้ง **Python 3.11+** และเปิด `deploy\windows\setup_local.cmd` ครั้งเดียว เพื่อสร้าง `.venv`, ติดตั้ง Python dependencies รวม `pyproj` และตั้งฐานข้อมูลใน `local_data\olgm.db`
3. เปิด `deploy\windows\start_local.cmd` แล้วเข้า `http://127.0.0.1:8787/` ในเบราว์เซอร์เครื่องเดียวกัน
4. คัดลอก `OPERATOR LOGIN TOKEN` หรือ `ADMIN CONSOLE TOKEN` จากหน้าต่าง Terminal ไปใส่ในหน้า Login. **ADMIN CONSOLE ไม่ใช่ Origin authority**
5. หยุดเฉพาะ OLGM Console ที่เปิดโดยกด `Ctrl+C` ในหน้าต่างดังกล่าว

> หากไม่สามารถติดตั้งผ่าน `pip` ได้ ตรวจอินเทอร์เน็ตและ Python ก่อน ไม่มีการเปลี่ยน Firewall, Windows Service หรือ DNS ให้โดยอัตโนมัติ

### ตรวจและหยุดเซิร์ฟเวอร์โครงการเก่าอย่างปลอดภัย

```powershell
powershell -NoProfile -File .\deploy\windows\audit_other_servers.ps1
# อ่านผล PID และ CommandLine ให้ชัดเจนก่อน แล้วจึงเลือกทีละ PID
powershell -NoProfile -File .\deploy\windows\stop_reviewed_process.ps1 -ProcessId 1234
```

คำสั่งแรก **อ่านอย่างเดียว**; คำสั่งที่สองจะแสดงรายละเอียดและต้องพิมพ์ `STOP` เพื่อปิดเฉพาะ PID ที่เป็นเซิร์ฟเวอร์โครงการ OLGM/ATI/Athena/Passadu ที่เข้ารายการอนุญาตเท่านั้น ไม่แตะ OS-critical services และไม่ปิดแอปที่ไม่มีหลักฐานว่าเป็นโครงการเก่า ไม่มีการหยุดโปรเซสใดบน X-admin ในการส่งมอบนี้ เพราะ X-admin ยัง Offline

## Linux / macOS (Local)

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-local.txt
mkdir -p local_data
OLGM_DB="$PWD/local_data/olgm.db" .venv/bin/python runtime.py init
./deploy/linux/start_local.sh
```

URL ใช้ `http://127.0.0.1:8787/` เท่านั้น แม้จะอยู่ในวง LAN เดียวกันก็ยังเข้าจากมือถือไม่ได้ จนกว่าจะจัด Identity/TLS Gateway แยกต่างหากอย่างถูกต้อง ห้ามเปลี่ยนเป็น `0.0.0.0` เพียงเพื่อเปิดให้ LAN/WAN เข้าถึง

## ความครอบคลุมที่เชื่อมกับ Runtime จริง

**ใช้งานได้บน Local ผ่าน UI:** หน้า Dashboard/สถิติ, อ่าน Intent/Meaning Cores และเส้นความสัมพันธ์, แสดงกราฟความหมาย 2D, ถามตอบภาษาไทยในชุดที่ระบบรองรับ, เสนอโค้ด Python จาก Pattern, สร้าง Intent Lock, บันทึก/แสดง Settings แบบ Default→Workspace→Role→User, อ่าน Audit, สถานะ CANTI/Plans, S-10, ValueGuard, Skills และ Resource Registry, แปลงพิกัด WGS84 เป็น Indian 1975 UTM Zone 48N ผ่าน pyproj (ยังไม่รับรองการรังวัด), ลงทะเบียน Resource แบบ NOT_CONNECTED ด้วย Admin Console Token, ส่งข้อเสนอ Control Plan ที่ยังไม่ Execute

**มีหน้าดูสถานะแต่ยังไม่ใช่ Live Connector:** X-admin Computer/Screenshot/Mouse, Plugins, ChatGPT Spaces, Ollama/API Gateway, Multimodal Understanding, Production Backup Restore, S-10 Production Acceptance. ความสามารถเหล่านี้ต้องมี Connector/ตัวตน/สิทธิ์/หลักฐานจริงก่อนใช้ สถานะจาก Registry ไม่แปลว่าเชื่อมต่อได้

**Read-only / Restricted:** Core 0 ไม่มี API เขียน; Canonical/Archive ไม่แก้ไข; การเปิดโมเดล, การแก้โค้ด Production, การจัดการสิทธิ์, การ Execute คิวและการส่ง ValueGuard email ต้องผ่าน CANTI, Intent Lock และ Origin approval ตามระดับที่กำหนด ไม่สามารถใช้ Admin Console Token ลัดสิทธิ์ได้

## การตั้งค่าหลายระดับ

- Default → Workspace → Role → User
- ค่า `safe`: มีผลกับ UI/Workflow หลังบันทึกเหตุการณ์
- ค่า `restricted`: ลงทะเบียนข้อเสนอเป็น `AWAITING_ORIGIN` **ยังไม่มีผล** จนผ่านกระบวนการที่มีหลักฐาน
- ค่า `locked`: ป้องกันการเปลี่ยนผ่าน UI ทุกระดับ
- ทุกการเปลี่ยน/คืนค่าถูกบันทึกเป็น Append-only event/hash chain; Rollback เป็นเหตุการณ์ใหม่ ไม่แก้ประวัติย้อนหลัง

## ตรวจการทำงาน

```bash
python -m pytest -q --ignore=tests/test_g06_source_improve.py
python -m pytest -q tests/test_g06_source_improve.py
python -m py_compile console.py
node --check web/app.js   # ตรวจ JavaScript หากติดตั้ง Node.js
```

**ผลทดสอบในสภาพแวดล้อมที่สร้างแพ็กเกจ:** ชุดหลัก `225 PASS, 2 SKIPPED` และชุด G-06 ที่เรียก pytest ภายใน `2 PASS` รวม `227 PASS, 2 SKIPPED` แบบ **แยกสองรอบ** เพื่อป้องกันการทดสอบ source mutation ซ้อนตัวเอง. งาน T06 live model และ T17 weight learning ไม่ได้ทดสอบในแพ็กเกจนี้ ส่วน browser visual screenshot/end-to-end บน X-admin ยังไม่ทดสอบ

API/UI Login ทดสอบจริงผ่าน HTTP request: Session cookie HttpOnly/SameSite, ตรวจ Origin/CSRF, Operator/Admin ไม่ใช่ Origin, การตั้งค่าไม่ปลดล็อก Security, สร้าง Intent, ตอบไทย, Code, Resource Registration และ GIS

S-10 / Production **NOT PASSED**: ยังต้องมี Origin identity proof, independent reviewer, TLS/Identity gateway, connectors จริง, safety/PDPA assessment และทดสอบบนเครื่องเป้าหมาย. อ้างอิง `docs/LOCAL_UI_CAPABILITY_MATRIX.md`

## ข้อมูลกำกับ

อีเมล Origin สำหรับกฎ ValueGuard: `teeranat.b@gmail.com`. UI ไม่ส่งอีเมลโดยตัวเอง และไม่เปิดเผยข้อมูลส่วนบุคคลของผู้อื่นโดยอัตโนมัติ

บทบาท `admin` ของ Local UI เป็นการจัดการค่าตั้งค่าระดับ Workspace/Role/การลงทะเบียนเท่านั้น **ไม่สามารถอ้างเป็น Origin หรืออนุมัติ Production ได้**

โปรแกรมเว็บนี้เปิดเฉพาะ `127.0.0.1` พร้อม Token Login ที่สร้างใหม่ต่อการเริ่มโปรเซส; Tokens อยู่ในหน่วยความจำและพิมพ์บน Terminal เท่านั้น ไม่บันทึกลงฐานข้อมูลหรือไฟล์เว็บ ให้ดูแลสิทธิ์การเข้าถึงเครื่อง Local ด้วย
