param([Parameter(Mandatory=$true)][int]$ProcessId)
# Stop only a reviewed OLGM/ATI project server; Windows OS-critical services are excluded.
$ErrorActionPreference='Stop'
$proc=Get-CimInstance Win32_Process -Filter "ProcessId=$ProcessId"
if (-not $proc) {throw 'Process not found'}
if ($proc.Name -notmatch '^(python|pythonw|node|php|uvicorn|httpd|nginx|caddy|dotnet)(\.exe)?$') {throw 'Not an allowlisted project server executable'}
if ($proc.CommandLine -notmatch '(?i)(olgm|athena|ati|passadu|procurement)') {throw 'No recognized project signature in command line'}
Write-Host "Review this process BEFORE stopping:" -ForegroundColor Cyan
$proc | Select-Object ProcessId,Name,ExecutablePath,CommandLine | Format-List
$answer=Read-Host 'Type STOP to terminate only this PID (all other answers cancel)'
if ($answer -cne 'STOP') {Write-Host 'Cancelled';exit 0}
# Get fresh process identity to reduce PID reuse risk.
$new=Get-CimInstance Win32_Process -Filter "ProcessId=$ProcessId"
if (-not $new -or $new.CreationDate -ne $proc.CreationDate -or $new.CommandLine -ne $proc.CommandLine) {throw 'Process changed since review. Cancelled.'}
Stop-Process -Id $ProcessId
Write-Host "Stop requested for PID $ProcessId only." -ForegroundColor Yellow
