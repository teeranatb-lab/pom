# Usage: powershell -NoProfile -File .\deploy\windows\audit_other_servers.ps1
# This is intentionally READ-ONLY. No service/process is stopped by this script.
$ErrorActionPreference='Stop'
$pat='(?i)(olgm|athena|ati|passadu|procurement)'
Write-Host "Potential OLGM/ATI project servers (review only):" -ForegroundColor Cyan
$found=@(Get-CimInstance Win32_Process | Where-Object { 
 $_.Name -match '^(python|pythonw|node|php|uvicorn|httpd|nginx|caddy|dotnet)(\.exe)?$' -and
 $_.CommandLine -match $pat
} | Select-Object ProcessId,ParentProcessId,Name,CommandLine)
if ($found.Count -eq 0) {Write-Host 'No matching project processes found.'}
else {$found | Format-Table -Wrap -AutoSize}
Write-Host "READ-ONLY: this script did not stop any process." -ForegroundColor Yellow
