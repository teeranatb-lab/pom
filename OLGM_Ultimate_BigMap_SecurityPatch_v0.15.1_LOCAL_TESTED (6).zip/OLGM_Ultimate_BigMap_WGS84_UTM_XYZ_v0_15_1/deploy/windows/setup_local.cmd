@echo off
setlocal
cd /d "%~dp0\..\.."
where py >nul 2>nul
if errorlevel 1 (
 echo Python 3 not found. Install Python 3.11+ and rerun.
 pause
 exit /b 1
)
if not exist ".venv\Scripts\python.exe" py -3 -m venv .venv
if errorlevel 1 exit /b 1
if not exist "local_data" mkdir local_data
if exist "local_data\olgm.db" (
 echo Backing up existing SQLite DB before migration...
 ".venv\Scripts\python.exe" tools\backup_before_upgrade.py --db "local_data\olgm.db" --out "local_data\backups"
 if errorlevel 1 ( echo Database backup failed. Aborting install. & exit /b 1 )
)
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 exit /b 1
".venv\Scripts\python.exe" -m pip install -r requirements-local.txt
if errorlevel 1 exit /b 1
if not exist "local_data" mkdir local_data
set "OLGM_DB=%CD%\local_data\olgm.db"
".venv\Scripts\python.exe" runtime.py init
if errorlevel 1 exit /b 1
echo.
echo Setup complete. Double click deploy\windows\start_local.cmd
pause
