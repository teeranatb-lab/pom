@echo off
setlocal
cd /d "%~dp0\..\.."
if not exist ".venv\Scripts\python.exe" (
 echo Run deploy\windows\setup_local.cmd first.
 pause
 exit /b 1
)
if not exist "local_data" mkdir local_data
set "OLGM_DB=%CD%\local_data\olgm.db"
set "OLGM_MODEL_PROVIDER=disabled"
echo.
echo OLGM Ultimate Local Console / http://127.0.0.1:8787
 echo A new console token will appear below. Copy it into the web login screen.
echo No other Windows services will be stopped automatically.
echo Stop this OLGM console with Ctrl+C.
echo.
start "OLGM Browser" /b powershell -NoProfile -Command "Start-Sleep -Seconds 3; Start-Process 'http://127.0.0.1:8787/'"
".venv\Scripts\python.exe" console.py --port 8787
pause
