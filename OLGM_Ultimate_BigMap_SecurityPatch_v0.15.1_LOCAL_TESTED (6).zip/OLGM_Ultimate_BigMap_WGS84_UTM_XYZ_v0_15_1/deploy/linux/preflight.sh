#!/usr/bin/env sh
set -eu
# Set OLGM_DB and secret OLGM_HTTP_TOKEN out of band before invocation.
: "${OLGM_DB:?Set OLGM_DB to the actual runtime DB file}"
: "${OLGM_HTTP_TOKEN:?Set secure OLGM_HTTP_TOKEN out of band}"
export OLGM_ENV=production
python runtime.py production-preflight --output s10_production_preflight.json
