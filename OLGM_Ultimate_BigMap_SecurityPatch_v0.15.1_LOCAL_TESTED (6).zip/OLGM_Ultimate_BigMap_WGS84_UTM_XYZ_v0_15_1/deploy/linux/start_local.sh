#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
[ -x .venv/bin/python ] || { echo 'Run python3 -m venv .venv && .venv/bin/pip install -r requirements-dev.txt first'; exit 1; }
mkdir -p local_data
export OLGM_DB="$PWD/local_data/olgm.db"
export OLGM_MODEL_PROVIDER=disabled
exec .venv/bin/python console.py --port 8787
