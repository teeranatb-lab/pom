# OLGM Ultimate — BigMap WGS84 Lat/Lon + UTM XYZ v0.15.0

**Status:** CODE-LEVEL TESTED. **S-10 PRODUCTION NOT PASSED.** Tested on isolated local environment, **not X-admin**. GPS/survey control and vertical transformations **NOT CERTIFIED**.

This release extends the prior OLGM Local Console with **simultaneous geographic WGS84 coordinates and UTM WGS84 projected X/Y, plus qualified Z**; it preserves the original OLGM Meaning Space XYZ as a separate abstract coordinate system linked by stable CID/Feature IDs.

## Overview

- **Geographic source of truth:** EPSG:4326 WGS84 Lat/Lon (GeoJSON `[lon,lat]`; form/CSV `lat,lon`).
- **Projected horizontal view:** WGS84 UTM **auto-zone** via pyproj/PROJ. Ubon Ratchathani is **Zone 48N, EPSG:32648**; coordinates are X Easting (m), Y Northing (m).
- **Z/height:** optional; **null when unknown**. Require a documented height CRS/reference when provided (EPSG:4979 for WGS84 ellipsoidal height, EPSG:5773 EGM96 height, EPSG:3855 EGM2008 height). **No vertical datum conversion is silently performed**. EPSG:32648 itself is a **2D CRS**, not a 3D height standard.
- **BigMap:** Point/LineString/Polygon (single ring); append-only geometry revisions and hash-chain; UTM projections derived per revision; UTM CSV import/export, Lat/Lon GeoJSON and CSV; route history linked to Origin and evidence refs.
- **Meaning Space:** geography attached to CID via CANDIDATE links. Neither semantic core XYZ nor semantic edges are overwritten when physical position changes.
- **Security fixes (v0.12.1 findings):** log DENIED/NOT_IMPLEMENTED/INSUFFICIENT agent outcomes; redact exception details; reject observer output without relation; forbid candidate with null/empty answer; persist unverified relation-ref tied to claim and audit.
- **UI:** BigMap now displays Lat/Lon + UTM X/Y/Z, derived EPSG, Z-reference selection, and dual-CSV download. No external basemap or model automatically enabled.
- **Legacy support:** Indian 1975 UTM 48N conversion is retained behind explicit `gis-indian-legacy-*` commands only. **It is not the default datum.**

## Install on Windows (safe Local upgrade)

1. Extract the ZIP **to a new folder**. Do not overwrite previous release, Canonical or Archive; close the prior OLGM Console normally.
2. Double-click `deploy\windows\setup_local.cmd`. It creates a `.venv`, uses `pyproj` and other dependencies, takes and integrity-checks a SQLite backup **before** initiating a schema migration for an existing `local_data\olgm.db`.
3. Double-click `deploy\windows\start_local.cmd`. Open **http://127.0.0.1:8787/** and enter the console token shown in Terminal. The Console is **loopback-only**; no LAN/WAN listening or stopping of other Windows services.
4. In **BigMap**, input `lat,lon` or `lat,lon,z`; choose a Vertical Reference for Z; see calculated UTM Zone/EPSG and coordinates; use **CSV Lat/Lon + UTM XYZ** to export.

Data in your *old release folder* is not automatically migrated from another directory. If continuing an old database, first make a verified backup and plan a controlled copy to the new `local_data` path, ensuring both Consoles are stopped. These steps do not open Production or bypass Origin approval.

## Python / CLI (Windows or Linux)

```bash
python -m venv .venv
# Windows: .venv\Scripts\python -m pip install -r requirements-local.txt
# Linux:   .venv/bin/python -m pip install -r requirements-local.txt
python tools/backup_before_upgrade.py --db local_data/olgm.db --out local_data/backups
python runtime.py init
python runtime.py bigmap-utm-point 16.199682 103.197839
python runtime.py bigmap-utm-point 16.199682 103.197839 --z 88.5 --vertical-crs EPSG:4979
python runtime.py gis-csv data/buoys_wgs84_latlon.csv converted_dual.csv
python runtime.py bigmap-add-point "ทุ่นลอย 1" 16.199682 103.197839 --origin-ref field:buoy --actor local_user
python runtime.py bigmap-export bigmap_dual_export.csv --format dual-csv
python -m pytest -q --ignore=tests/test_g06_source_improve.py
python -m pytest -q tests/test_g06_source_improve.py
```

Use a dedicated DB path such as `OLGM_DB=...` for isolated testing. No actual Origin authority, security key, third-party plugin or remote computer is unlocked by these commands.

## Source files

| File | Purpose |
|---|---|
| `olgm/utm_wgs84.py` | Coordinate conversion, auto UTM zone, qualified Z and dual CSV output. |
| `olgm/bigmap.py` | Geographic Features ↔ Meaning Space CID, versioned CRS metadata, import/export, integrity checks. |
| `olgm/geopoints.py` | Compatibility layer that derives WGS84 UTM for legacy Lat/Lon points. |
| `console.py`, `web/app.js` | Local authenticated BigMap API and bilingual coordinate UI. |
| `runtime.py` | New GIS/BigMap CLI with explicit legacy Indian commands. |
| `tools/backup_before_upgrade.py` | Read-only SQLite backup/restore preflight before version migration. |
| `tests/test_utm_xyz_v015.py` | Zone, roundtrip, vertical, CSV, audit, governance and regression test suite. |
| `docs/BIGMAP_UTM_WGS84_XYZ_TH.md` | Full Thai specification and install guide. |
| `data/buoys_wgs84_latlon.csv` | Four example buoy positions. |

**Technical guide:** [docs/BIGMAP_UTM_WGS84_XYZ_TH.md](docs/BIGMAP_UTM_WGS84_XYZ_TH.md). Original console instructions preserved as [docs/LOCAL_CONSOLE_README_BASE_V0121.md](docs/LOCAL_CONSOLE_README_BASE_V0121.md).

**Not included:** source-code edits on X-admin, surveyed control-point assessment, automatic Z vertical-datum correction, production network gateway, independent S-10 acceptance, live model/training evidence.

## Security Patch v0.15.1 — HTTP outcomes and exception redaction

- Central API and Local Console error-response paths record `HTTP_API_OUTCOME` / `HTTP_UI_OUTCOME` into the audit hash-chain with non-sensitive metadata.
- Invalid tokens, CSRF attempts, malformed JSON, 404, API-level `NOT_IMPLEMENTED`, `DENIED` and `INSUFFICIENT` are included. Raw request bodies, passwords, tokens and exception strings are excluded.
- When recording a protected outcome fails, response changes to `503 SERVICE_UNAVAILABLE / AUDIT_UNAVAILABLE` instead of falsely claiming governance success.
- Public API/Console malformed JSON errors no longer expose exception messages.
- Independent tests: `python -m pytest -q tests/test_security_http_v0151.py tests/test_utm_xyz_v015.py`
- This is a **local code patch**, not a penetration-test certificate; model and Production S-10 remain NOT PASSED. No Canonical/Archive edits.
