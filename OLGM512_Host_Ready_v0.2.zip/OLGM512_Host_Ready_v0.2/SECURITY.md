# Security baseline — OLGM 512 Host Ready v0.2

- Authentication is mandatory by default. The process refuses to start without `OLGM_ADMIN_PASSWORD` unless `OLGM_AUTH_DISABLED=true` is explicitly set for local development.
- Bind the application to `127.0.0.1`; expose it through HTTPS reverse proxy only.
- Nginx sample includes request rate limiting, HSTS, clickjacking and content-sniffing protections.
- Application adds CSP, no-store caching and no-referrer headers.
- SQLite database is separated from application files and should be owned by the dedicated service account.
- Evidence is hashed with SHA-256 and ledger events are append-only by application behavior. This is not yet a cryptographic transparency log.
- CANTI v0.2 still performs no external side effects. Do not enable real-world executors until policy, approval and secrets isolation are added.
- HTTP Basic Auth is a deployment baseline, not final enterprise identity. Use SSO/OIDC or an authenticated access proxy before multi-user enterprise use.
