import base64
import datetime
import hashlib
import hmac
import html
import json
import os
import secrets
import sqlite3
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

APP_VERSION = "0.2.0"
ORIGIN_ID = "ORG-TEERANAT-BUTDA"
ORIGIN_NAME = "Teeranat Butda"
ORIGIN_TH = "ธีรนาท บุตรดา"
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv("OLGM_DB_PATH", str(BASE_DIR / "data" / "olgm512.db")))
HOST = os.getenv("OLGM_HOST", "127.0.0.1")
PORT = int(os.getenv("OLGM_PORT", "8512"))
ADMIN_USER = os.getenv("OLGM_ADMIN_USER", "admin")
ADMIN_PASSWORD = os.getenv("OLGM_ADMIN_PASSWORD", "")
AUTH_DISABLED = os.getenv("OLGM_AUTH_DISABLED", "false").lower() == "true"
MAX_BODY = int(os.getenv("OLGM_MAX_BODY_BYTES", "1048576"))
SITE_TITLE = os.getenv("OLGM_SITE_TITLE", "OLGM 512")

DB_PATH.parent.mkdir(parents=True, exist_ok=True)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def uid(prefix):
    return f"{prefix}-{uuid.uuid4().hex[:12].upper()}"


def sha256_text(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    conn = db()
    cur = conn.cursor()
    cur.executescript("""
    PRAGMA journal_mode=WAL;
    PRAGMA synchronous=FULL;
    CREATE TABLE IF NOT EXISTS origins(
      origin_id TEXT PRIMARY KEY,name TEXT NOT NULL,name_th TEXT NOT NULL,created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS intents(
      intent_id TEXT PRIMARY KEY,origin_id TEXT NOT NULL,version INTEGER NOT NULL,
      goal TEXT NOT NULL,raw_text TEXT NOT NULL,status TEXT NOT NULL,
      created_at TEXT NOT NULL,locked_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS evidence(
      evidence_id TEXT PRIMARY KEY,intent_id TEXT NOT NULL,source TEXT NOT NULL,
      content TEXT NOT NULL,hash TEXT NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS claims(
      claim_id TEXT PRIMARY KEY,intent_id TEXT NOT NULL,text TEXT NOT NULL,state TEXT NOT NULL,created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS claim_evidence(
      claim_id TEXT NOT NULL,evidence_id TEXT NOT NULL,PRIMARY KEY(claim_id,evidence_id)
    );
    CREATE TABLE IF NOT EXISTS decisions(
      decision_id TEXT PRIMARY KEY,intent_id TEXT NOT NULL,summary TEXT NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS executions(
      execution_id TEXT PRIMARY KEY,intent_id TEXT NOT NULL,decision_id TEXT NOT NULL,target TEXT NOT NULL,
      state TEXT NOT NULL,result TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS events(
      event_id TEXT PRIMARY KEY,trace_id TEXT NOT NULL,intent_id TEXT NOT NULL,type TEXT NOT NULL,
      payload TEXT NOT NULL,payload_hash TEXT NOT NULL,created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS audit_log(
      audit_id TEXT PRIMARY KEY,actor TEXT NOT NULL,action TEXT NOT NULL,path TEXT NOT NULL,
      remote_addr TEXT NOT NULL,status INTEGER NOT NULL,created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_events_intent_time ON events(intent_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_evidence_intent ON evidence(intent_id);
    CREATE INDEX IF NOT EXISTS idx_claims_intent ON claims(intent_id);
    """)
    cur.execute("SELECT 1 FROM origins WHERE origin_id=?", (ORIGIN_ID,))
    if not cur.fetchone():
        cur.execute("INSERT INTO origins VALUES(?,?,?,?)", (ORIGIN_ID, ORIGIN_NAME, ORIGIN_TH, now()))
    conn.commit()
    conn.close()


def audit(actor, action, path, remote_addr, status):
    try:
        conn = db()
        conn.execute("INSERT INTO audit_log VALUES(?,?,?,?,?,?)", (uid("AUD"), actor, action, path, remote_addr, int(status), now()))
        conn.commit(); conn.close()
    except Exception:
        pass


def event(intent_id, typ, payload, trace_id=None):
    trace_id = trace_id or intent_id
    payload_json = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    eid = uid("EVT")
    conn = db()
    conn.execute("INSERT INTO events VALUES(?,?,?,?,?,?,?)",
                 (eid, trace_id, intent_id, typ, payload_json, sha256_text(payload_json), now()))
    conn.commit(); conn.close()
    return eid


def require_intent(intent_id):
    conn = db(); row = conn.execute("SELECT intent_id FROM intents WHERE intent_id=?", (intent_id,)).fetchone(); conn.close()
    if not row:
        raise ValueError("intent not found")


def create_intent(text):
    clean = " ".join(text.strip().split())
    if not clean:
        raise ValueError("intent required")
    intent_id = uid("INT")
    conn = db()
    conn.execute("INSERT INTO intents VALUES(?,?,?,?,?,?,?,?)",
                 (intent_id, ORIGIN_ID, 1, clean[:500], text[:20000], "LOCKED", now(), now()))
    conn.commit(); conn.close()
    event(intent_id, "INTENT_CREATED", {"goal": clean[:500], "origin": ORIGIN_ID})
    event(intent_id, "INTENT_LOCKED", {"version": 1})
    return intent_id


def add_evidence(intent_id, source, content):
    require_intent(intent_id)
    if not content.strip():
        raise ValueError("evidence required")
    eid = uid("EVD")
    digest = sha256_text(content)
    conn = db()
    conn.execute("INSERT INTO evidence VALUES(?,?,?,?,?,?,?)",
                 (eid, intent_id, source[:200] or "LOCAL", content[:100000], digest, "VERIFIED_INTEGRITY", now()))
    conn.commit(); conn.close()
    event(intent_id, "EVIDENCE_RECEIVED", {"evidence_id": eid, "source": source[:200], "hash": digest})
    return eid


def add_claim(intent_id, text, evidence_ids):
    require_intent(intent_id)
    if not text.strip():
        raise ValueError("claim required")
    conn = db()
    valid_ids = []
    for evidence_id in evidence_ids:
        row = conn.execute("SELECT evidence_id FROM evidence WHERE evidence_id=? AND intent_id=?", (evidence_id, intent_id)).fetchone()
        if row:
            valid_ids.append(evidence_id)
    cid = uid("CLM")
    state = "SUPPORTED" if valid_ids else "UNKNOWN"
    conn.execute("INSERT INTO claims VALUES(?,?,?,?,?)", (cid, intent_id, text[:20000], state, now()))
    for evidence_id in valid_ids:
        conn.execute("INSERT OR IGNORE INTO claim_evidence VALUES(?,?)", (cid, evidence_id))
    conn.commit(); conn.close()
    event(intent_id, "CLAIM_CREATED", {"claim_id": cid, "state": state, "evidence_ids": valid_ids})
    return cid


def decide(intent_id):
    require_intent(intent_id)
    conn = db(); claims = conn.execute("SELECT * FROM claims WHERE intent_id=?", (intent_id,)).fetchall()
    supported = [x for x in claims if x["state"] == "SUPPORTED"]
    unknown = [x for x in claims if x["state"] == "UNKNOWN"]
    if supported:
        summary = " | ".join(x["text"] for x in supported)
        status = "VERIFIED_DECISION" if not unknown else "PARTIAL_DECISION"
    else:
        summary = "ยังไม่มีหลักฐานเพียงพอสำหรับข้อสรุปที่ยืนยันได้"
        status = "INSUFFICIENT_EVIDENCE"
    did = uid("DEC")
    conn.execute("INSERT INTO decisions VALUES(?,?,?,?,?)", (did, intent_id, summary, status, now()))
    conn.commit(); conn.close()
    event(intent_id, "DECISION_CREATED", {"decision_id": did, "status": status})
    return did, summary, status


def canti_execute(intent_id, decision_id, target):
    require_intent(intent_id)
    conn = db(); d = conn.execute("SELECT decision_id,status FROM decisions WHERE decision_id=? AND intent_id=?", (decision_id, intent_id)).fetchone(); conn.close()
    if not d:
        raise ValueError("decision not found")
    xid = uid("EXE"); ts = now()
    conn = db()
    conn.execute("INSERT INTO executions VALUES(?,?,?,?,?,?,?,?)",
                 (xid, intent_id, decision_id, target[:1000], "TARGET_LOCK", "", ts, ts))
    conn.commit(); conn.close()
    event(intent_id, "CANTI_TARGET_LOCK", {"execution_id": xid, "target": target[:1000]})
    for stage in ["PATH_ANALYSIS", "EXECUTE_NO_EXPAND", "OBSERVE", "COMPARE", "CLOSE"]:
        conn = db(); conn.execute("UPDATE executions SET state=?,updated_at=? WHERE execution_id=?", (stage, now(), xid)); conn.commit(); conn.close()
        event(intent_id, f"CANTI_{stage}", {"execution_id": xid})
    result = "Reference execution closed locally; no external side effect was performed."
    conn = db(); conn.execute("UPDATE executions SET result=?,updated_at=? WHERE execution_id=?", (result, now(), xid)); conn.commit(); conn.close()
    return xid, result


def get_trace(intent_id):
    conn = db()
    origin = conn.execute("SELECT * FROM origins WHERE origin_id=?", (ORIGIN_ID,)).fetchone()
    intent = conn.execute("SELECT * FROM intents WHERE intent_id=?", (intent_id,)).fetchone()
    output = {
        "origin": dict(origin) if origin else {},
        "intent": dict(intent) if intent else {},
        "evidence": [dict(r) for r in conn.execute("SELECT * FROM evidence WHERE intent_id=? ORDER BY created_at", (intent_id,)).fetchall()],
        "claims": [dict(r) for r in conn.execute("SELECT * FROM claims WHERE intent_id=? ORDER BY created_at", (intent_id,)).fetchall()],
        "decisions": [dict(r) for r in conn.execute("SELECT * FROM decisions WHERE intent_id=? ORDER BY created_at", (intent_id,)).fetchall()],
        "executions": [dict(r) for r in conn.execute("SELECT * FROM executions WHERE intent_id=? ORDER BY created_at", (intent_id,)).fetchall()],
        "events": [dict(r) for r in conn.execute("SELECT * FROM events WHERE intent_id=? ORDER BY created_at", (intent_id,)).fetchall()],
    }
    conn.close(); return output


CSS = """
body{font-family:system-ui,-apple-system,Segoe UI,Tahoma,sans-serif;max-width:1100px;margin:32px auto;padding:0 18px;background:#08111f;color:#eaf0ff}
h1{margin-bottom:4px}.card{background:#111d31;border:1px solid #253a5d;border-radius:16px;padding:18px;margin:14px 0}
input,textarea{width:100%;box-sizing:border-box;background:#091426;color:#fff;border:1px solid #38527b;border-radius:9px;padding:11px;margin:6px 0}
button{background:#eaf2ff;color:#08111f;border:0;border-radius:9px;padding:10px 16px;font-weight:750;cursor:pointer}.muted{color:#9fb0d0}.ok{color:#a7f3d0}.warn{color:#fde68a}code{color:#c4f0ff}a{color:#93c5fd}pre{white-space:pre-wrap;word-break:break-word;background:#06101d;padding:15px;border-radius:12px;border:1px solid #23354f}
"""


def page(title, body):
    return f'<!doctype html><html lang="th"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)}</title><style>{CSS}</style><body>{body}</body></html>'


INDEX = page(SITE_TITLE, f"""
<h1>OLGM 512 — Host Ready</h1>
<div class="muted">Origin / ต้นกำเนิด: {ORIGIN_NAME} ({ORIGIN_TH}) · v{APP_VERSION}</div>
<div class="card"><h3>1) Create & Lock Intent</h3><form method="post" action="/intent"><textarea name="text" rows="3" maxlength="20000" placeholder="ระบุ Intent..."></textarea><button>สร้าง Intent</button></form></div>
<div class="card"><h3>2) Trace Explorer</h3><form method="get" action="/trace"><input name="intent_id" maxlength="64" placeholder="INT-..."><button>เปิด Trace</button></form></div>
<div class="card"><b>Canonical:</b> Origin → Intent → Evidence → Claim → Verification → Decision → CANTI → Outcome → Provenance</div>
""")


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class Handler(BaseHTTPRequestHandler):
    server_version = "OLGM512/0.2"

    def log_message(self, fmt, *args):
        print(f"{self.address_string()} - {fmt % args}")

    def _actor(self):
        return ADMIN_USER if self._authenticated() else "anonymous"

    def _authenticated(self):
        if AUTH_DISABLED:
            return True
        header = self.headers.get("Authorization", "")
        if not header.startswith("Basic ") or not ADMIN_PASSWORD:
            return False
        try:
            decoded = base64.b64decode(header[6:], validate=True).decode("utf-8")
            username, password = decoded.split(":", 1)
        except Exception:
            return False
        return hmac.compare_digest(username, ADMIN_USER) and hmac.compare_digest(password, ADMIN_PASSWORD)

    def _security_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'")

    def send_body(self, code, body, ctype="text/html; charset=utf-8"):
        data = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self._security_headers()
        self.end_headers(); self.wfile.write(data)
        audit(self._actor(), self.command, self.path.split("?", 1)[0], self.client_address[0], code)

    def unauthorized(self):
        body = page("Authentication required", "<h2>Authentication required</h2><p>OLGM 512 is protected.</p>")
        data = body.encode("utf-8")
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="OLGM 512", charset="UTF-8"')
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self._security_headers(); self.end_headers(); self.wfile.write(data)
        audit("anonymous", self.command, self.path.split("?", 1)[0], self.client_address[0], 401)

    def body(self):
        length = int(self.headers.get("Content-Length", "0") or 0)
        if length > MAX_BODY:
            raise ValueError("request too large")
        return self.rfile.read(length).decode("utf-8")

    def require_auth(self):
        if not self._authenticated():
            self.unauthorized(); return False
        return True

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/health":
            return self.send_body(200, json.dumps({"ok": True, "version": APP_VERSION}), "application/json; charset=utf-8")
        if parsed.path == "/ready":
            try:
                conn = db(); conn.execute("SELECT 1").fetchone(); conn.close()
                return self.send_body(200, json.dumps({"ready": True}), "application/json; charset=utf-8")
            except Exception:
                return self.send_body(503, json.dumps({"ready": False}), "application/json; charset=utf-8")
        if not self.require_auth(): return
        if parsed.path == "/": return self.send_body(200, INDEX)
        if parsed.path == "/trace":
            intent_id = parse_qs(parsed.query).get("intent_id", [""])[0]
            if not intent_id: return self.send_body(400, page("Error", "<h2>missing intent_id</h2>"))
            trace = get_trace(intent_id)
            if not trace["intent"]: return self.send_body(404, page("Not found", "<h2>intent not found</h2>"))
            safe = html.escape(json.dumps(trace, ensure_ascii=False, indent=2))
            return self.send_body(200, page("Trace", f'<h2>Trace Explorer</h2><pre>{safe}</pre><p><a href="/">Home</a></p>'))
        if parsed.path.startswith("/api/trace/"):
            intent_id = parsed.path.rsplit("/", 1)[-1]
            trace = get_trace(intent_id)
            if not trace["intent"]: return self.send_body(404, json.dumps({"error":"intent not found"}), "application/json; charset=utf-8")
            return self.send_body(200, json.dumps(trace, ensure_ascii=False, indent=2), "application/json; charset=utf-8")
        return self.send_body(404, page("Not found", "<h2>not found</h2>"))

    def do_POST(self):
        if not self.require_auth(): return
        try:
            parsed = urlparse(self.path); form = parse_qs(self.body())
            if parsed.path == "/intent":
                intent_id = create_intent(form.get("text", [""])[0])
                return self.send_body(200, page("Intent Locked", f'''<h2>Intent Locked</h2><p><code>{intent_id}</code></p>
                <form method="post" action="/evidence"><input type="hidden" name="intent_id" value="{intent_id}"><p>Source</p><input name="source" value="LOCAL" maxlength="200"><p>Evidence</p><textarea name="content" rows="5" maxlength="100000"></textarea><button>เพิ่ม Evidence</button></form><p><a href="/trace?intent_id={intent_id}">Trace Explorer</a></p>'''))
            if parsed.path == "/evidence":
                intent_id = form.get("intent_id", [""])[0]; source = form.get("source", ["LOCAL"])[0]; content = form.get("content", [""])[0]
                evidence_id = add_evidence(intent_id, source, content)
                return self.send_body(200, page("Evidence Stored", f'''<h2>Evidence Stored</h2><p><code>{evidence_id}</code></p><form method="post" action="/claim"><input type="hidden" name="intent_id" value="{html.escape(intent_id)}"><input type="hidden" name="evidence_id" value="{evidence_id}"><p>Claim</p><textarea name="text" rows="4" maxlength="20000"></textarea><button>สร้าง Claim + Verify</button></form>'''))
            if parsed.path == "/claim":
                intent_id = form.get("intent_id", [""])[0]; claim_text = form.get("text", [""])[0]; eids = [x for x in form.get("evidence_id", []) if x]
                add_claim(intent_id, claim_text, eids); decision_id, summary, status = decide(intent_id)
                return self.send_body(200, page("Decision", f'''<h2>{html.escape(status)}</h2><p>{html.escape(summary)}</p><form method="post" action="/execute"><input type="hidden" name="intent_id" value="{html.escape(intent_id)}"><input type="hidden" name="decision_id" value="{decision_id}"><p>CANTI Target</p><input name="target" maxlength="1000" value="Close verified reference cycle"><button>Run CANTI</button></form><p><a href="/trace?intent_id={html.escape(intent_id)}">ดู Trace</a></p>'''))
            if parsed.path == "/execute":
                intent_id = form.get("intent_id", [""])[0]; decision_id = form.get("decision_id", [""])[0]; target = form.get("target", [""])[0]
                execution_id, result = canti_execute(intent_id, decision_id, target)
                return self.send_body(200, page("CANTI Closed", f'''<h2>CANTI CLOSED</h2><p><code>{execution_id}</code></p><p>{html.escape(result)}</p><p><a href="/trace?intent_id={html.escape(intent_id)}">เปิด Full Trace</a></p><p><a href="/">Home</a></p>'''))
            return self.send_body(404, page("Not found", "<h2>not found</h2>"))
        except ValueError as exc:
            return self.send_body(400, page("Error", f"<h2>Bad request</h2><p>{html.escape(str(exc))}</p>"))
        except Exception:
            return self.send_body(500, page("Error", "<h2>Internal error</h2>"))


def main():
    if not AUTH_DISABLED and not ADMIN_PASSWORD:
        raise SystemExit("Refusing to start: set OLGM_ADMIN_PASSWORD or OLGM_AUTH_DISABLED=true for local development.")
    init_db()
    print(f"OLGM 512 Host Ready v{APP_VERSION}")
    print(f"Origin: {ORIGIN_NAME} / {ORIGIN_TH}")
    print(f"Listening: http://{HOST}:{PORT}")
    Server((HOST, PORT), Handler).serve_forever()


if __name__ == "__main__":
    main()
