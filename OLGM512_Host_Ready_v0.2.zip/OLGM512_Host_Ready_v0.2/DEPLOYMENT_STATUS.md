# Deployment status — 19 Sep 2026

## Completed
- OLGM 512 Host-Ready v0.2 application created.
- Origin locked to Teeranat Butda (ธีรนาท บุตรดา).
- Authentication baseline added; fail-closed startup without password.
- Database/config separation, audit log, security headers and body-size limit added.
- systemd, Nginx HTTP bootstrap, Nginx HTTPS, backup and smoke-test assets created.
- End-to-end local test passed: health → auth guard → intent → evidence → claim → decision → CANTI → trace.
- Test result: 11 events, 1 claim, 1 execution, final CANTI state CLOSE.

## External deployment state
- athena-30.com is publicly reachable.
- olgm.athena-30.com could not be verified as reachable from the available public access path at packaging time.
- No authorized remote computer/server was connected to the remote-control tool in this session, so server-side DNS, file upload, service installation and TLS issuance were not performed.

## Remaining server actions
1. Point `olgm.athena-30.com` DNS to the server.
2. Upload package and run `scripts/install_vps.sh` as root.
3. Set a strong password in `/etc/olgm512/olgm512.env`.
4. Start service and verify local `/health` and `/ready`.
5. Enable `deploy/nginx-http-bootstrap.conf`, issue TLS certificate, then replace it with `deploy/nginx-https.conf`.
6. Run remote smoke test against `https://olgm.athena-30.com`.
