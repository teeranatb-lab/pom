# OLGM 512 Host-Ready Reference Kernel v0.2

**Origin / ต้นกำเนิด:** Teeranat Butda (ธีรนาท บุตรดา)

Canonical chain:

`Origin → Intent → Evidence → Claim → Verification → Decision → CANTI → Outcome → Provenance`

## What changed from v0.1

- Environment-driven host, port, database path and site settings
- Authentication enabled by default; startup fails closed when password is missing
- Dedicated audit log
- Security headers and request size limit
- Public shallow `/health` and `/ready` endpoints
- Safer validation between Intent, Evidence and Decision objects
- Nginx reverse-proxy config for `olgm.athena-30.com`
- systemd unit with service hardening
- SQLite online backup script with retention
- VPS installer and smoke test
- Application data separated from code

## Local test

Linux/macOS:

```bash
export OLGM_AUTH_DISABLED=true
python3 app.py
```

Windows PowerShell:

```powershell
$env:OLGM_AUTH_DISABLED='true'
python app.py
```

Open `http://127.0.0.1:8512`.

## VPS deployment target

Recommended path:

`Internet → HTTPS/Nginx → 127.0.0.1:8512 → OLGM Kernel → /var/lib/olgm512/olgm512.db`

1. Create DNS `A/AAAA` record for `olgm.athena-30.com` pointing to the server.
2. Copy this package to the server.
3. Run `sudo bash scripts/install_vps.sh`.
4. Edit `/etc/olgm512/olgm512.env` and set a long random admin password.
5. Start with `sudo systemctl start olgm512` and verify `curl http://127.0.0.1:8512/health`.
6. Enable `deploy/nginx-http-bootstrap.conf` first, obtain the TLS certificate with your ACME/Certbot flow, then replace it with `deploy/nginx-https.conf`.
7. Run `OLGM_ADMIN_PASSWORD='...' python3 scripts/smoke_test.py https://olgm.athena-30.com`.

## Production boundary

v0.2 is suitable as a protected single-operator reference deployment. Before multi-user or real external actions add OIDC/SSO, RBAC/ABAC policy, secrets manager, signed evidence/attestation, database migration strategy, centralized monitoring and independent security review.
