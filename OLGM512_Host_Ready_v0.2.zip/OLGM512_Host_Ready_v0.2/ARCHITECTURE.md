# OLGM 512 — Runtime Architecture

## Kernel

- Origin Registry
- Intent Engine / Intent Lock
- Evidence Store
- Claim Engine
- Verification
- Decision Record
- Event Ledger
- Provenance Trace
- CANTI Execution State Machine

## Canonical objects

`OriginObject → IntentObject → EvidenceObject → ClaimObject → DecisionObject → ExecutionObject → Outcome/Event lineage`

## Kernel invariants

1. Origin cannot be silently overwritten.
2. Locked Intent cannot be silently changed.
3. Raw Evidence is never rewritten; new evidence creates a new object.
4. Claims distinguish supported from unknown.
5. Events are append-only.
6. Executions are tied to an Intent and Decision.
7. Every object is traceable by intent/trace lineage.
8. A reference cycle terminates explicitly with CLOSE.

## "ปัญญายาน" operational mapping

ใน implementation นี้ คำว่า “ปัญญายาน” ถูกวางเป็น **metacognitive / semantic-control layer** เหนือ reasoning ไม่ใช่คำอ้างถึงพลังภายนอกที่ตรวจสอบไม่ได้ โดยหน้าที่เชิงระบบคือ:

- ตรวจ Intent drift
- แยก Evidence / Inference / Unknown
- ตรวจความสอดคล้องของ Claim กับ Evidence
- เลือกว่าจะเดินต่อ หยุด หรือขอ Evidence เพิ่ม
- ปิดวงจร CANTI เมื่อ success condition ครบ

แนวคิดจึงถูกแปลงเป็นพฤติกรรมที่ทดสอบและเขียนโค้ดได้
