#!/usr/bin/env bash
set -euo pipefail
DB="${OLGM_DB_PATH:-/var/lib/olgm512/olgm512.db}"
OUT="${OLGM_BACKUP_DIR:-/var/backups/olgm512}"
mkdir -p "$OUT"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
python3 - "$DB" "$OUT/olgm512-$STAMP.db" <<'PY'
import sqlite3, sys
src, dst = sys.argv[1:3]
s = sqlite3.connect(src); d = sqlite3.connect(dst); s.backup(d); d.close(); s.close()
print(dst)
PY
find "$OUT" -type f -name 'olgm512-*.db' -mtime +14 -delete
