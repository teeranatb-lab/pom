import base64, json, os, sys, urllib.request, urllib.parse
base = (sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8512").rstrip("/")
user = os.getenv("OLGM_ADMIN_USER", "admin")
pw = os.getenv("OLGM_ADMIN_PASSWORD", "")
headers = {}
if pw:
    headers["Authorization"] = "Basic " + base64.b64encode(f"{user}:{pw}".encode()).decode()
def req(path, data=None, auth=True):
    h = headers.copy() if auth else {}
    body = urllib.parse.urlencode(data).encode() if data else None
    r = urllib.request.Request(base+path, data=body, headers=h)
    with urllib.request.urlopen(r, timeout=5) as x:
        return x.status, x.read().decode()
print("health", req("/health", auth=False)[0])
status, body = req("/intent", {"text":"Smoke-test intent"})
assert status == 200 and "INT-" in body
print("intent", status)
print("PASS")
