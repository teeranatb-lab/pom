#!/usr/bin/env bash
set -euo pipefail
if [ "${EUID}" -ne 0 ]; then echo "Run as root: sudo bash scripts/install_vps.sh"; exit 1; fi
APP_SRC="$(cd "$(dirname "$0")/.." && pwd)"
id -u olgm512 >/dev/null 2>&1 || useradd --system --home /opt/olgm512 --shell /usr/sbin/nologin olgm512
install -d -m 750 -o olgm512 -g olgm512 /opt/olgm512 /var/lib/olgm512 /var/backups/olgm512
install -d -m 750 /etc/olgm512
install -m 640 -o root -g olgm512 "$APP_SRC/app.py" /opt/olgm512/app.py
install -m 640 -o root -g root "$APP_SRC/deploy/olgm512.service" /etc/systemd/system/olgm512.service
if [ ! -f /etc/olgm512/olgm512.env ]; then
  install -m 640 -o root -g olgm512 "$APP_SRC/deploy/olgm512.env.example" /etc/olgm512/olgm512.env
  echo "Created /etc/olgm512/olgm512.env — set a strong password before starting."
fi
systemctl daemon-reload
systemctl enable olgm512
cat <<MSG
Installed OLGM 512 service files.
Next:
1) Edit /etc/olgm512/olgm512.env and set OLGM_ADMIN_PASSWORD.
2) systemctl start olgm512
3) Copy deploy/nginx-olgm.conf to /etc/nginx/sites-available/olgm.athena-30.com
4) Obtain TLS certificate with your normal ACME/Certbot flow, then enable the Nginx site.
5) Run scripts/smoke_test.py against https://olgm.athena-30.com
MSG
